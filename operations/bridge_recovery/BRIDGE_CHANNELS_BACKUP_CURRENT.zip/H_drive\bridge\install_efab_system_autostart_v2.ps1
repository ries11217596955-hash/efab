﻿$ErrorActionPreference = 'Stop'
$BridgeRoot = 'H:\bridge'
$SourceToken = 'C:\Users\Azerbaijan\.bridge\bridge_action_token.txt'
$MachineRoot = 'C:\ProgramData\EFAB'
$MachineToken = Join-Path $MachineRoot 'bridge_action_token.txt'
$TaskName = 'EFAB Bridge Boot SYSTEM'
$Log = Join-Path $BridgeRoot ('boot_task_logs\install_system_autostart_v2_' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.log')
New-Item -ItemType Directory -Force -Path (Split-Path $Log) | Out-Null
function Log([string]$m){ Add-Content -Encoding UTF8 -Path $Log -Value "$(Get-Date -Format o) $m" }
Log 'BEGIN'
if(-not (Test-Path $SourceToken)){ throw "SOURCE_TOKEN_MISSING: $SourceToken" }
New-Item -ItemType Directory -Force -Path $MachineRoot | Out-Null
Copy-Item -LiteralPath $SourceToken -Destination $MachineToken -Force
& icacls.exe $MachineRoot /inheritance:r /grant:r 'SYSTEM:(OI)(CI)F' 'Administrators:(OI)(CI)F' | Out-Null
& icacls.exe $MachineToken /inheritance:r /grant:r 'SYSTEM:F' 'Administrators:F' | Out-Null
$Action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument ('-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "H:\bridge\start_gpt_action_bridge_dev.ps1" -TokenPath "' + $MachineToken + '"') -WorkingDirectory $BridgeRoot
$Trigger = New-ScheduledTaskTrigger -AtStartup
$Trigger.Delay = 'PT30S'
$Settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
$Principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger $Trigger -Settings $Settings -Principal $Principal -Description 'Starts EFAB Bridge and ngrok at Windows boot before user logon' | Out-Null
$task = Get-ScheduledTask -TaskName $TaskName
$info = Get-ScheduledTaskInfo -TaskName $TaskName
Log ("TASK_CREATED state={0} user={1} logon={2}" -f $task.State,$task.Principal.UserId,$task.Principal.LogonType)
[pscustomobject]@{Status='INSTALL_OK';TaskName=$TaskName;State=$task.State;UserId=$task.Principal.UserId;LogonType=$task.Principal.LogonType;TokenPath=$MachineToken;LastTaskResult=$info.LastTaskResult;Log=$Log} | ConvertTo-Json -Depth 3 | Set-Content -Encoding UTF8 (Join-Path $MachineRoot 'install_result.json')
Log 'END'
