from __future__ import annotations

import difflib
from typing import Any

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field

from bridge_app.core.auth import AuthContext, require_auth
from bridge_app.operations.filesystem import (
    apply_replacements,
    checksum_file,
    find_paths,
    list_dir,
    read_range,
    resolve_path,
    search_text,
    stat_path,
    write_file,
)

router = APIRouter(prefix="/files", tags=["files"])


class PathRequest(BaseModel):
    path: str


class ReadRequest(PathRequest):
    offset: int = 0
    length: int = Field(default=65536, ge=1, le=1048576)


class WriteRequest(PathRequest):
    content: str
    expected_checksum: str | None = None


class PatchRequest(PathRequest):
    expected_checksum: str
    replacements: list[dict[str, str]]


class DiffRequest(PathRequest):
    content: str


class ListRequest(BaseModel):
    path: str = "."
    recursive: bool = False
    limit: int = Field(default=1000, ge=1, le=10000)


class SearchRequest(BaseModel):
    query: str
    path: str = "."
    glob: str = "*"
    limit: int = Field(default=200, ge=1, le=5000)


class FindRequest(BaseModel):
    pattern: str
    path: str = "."
    limit: int = Field(default=1000, ge=1, le=10000)


def _root(request: Request):
    return request.app.state.settings.root_dir


@router.post("/read-file")
def read_file(payload: ReadRequest, request: Request, auth: AuthContext = Depends(require_auth)) -> dict[str, Any]:
    _ = auth
    return {"ok": True, "result": read_range(_root(request), payload.path, payload.offset, payload.length)}


@router.post("/read-range")
def read_file_range(payload: ReadRequest, request: Request, auth: AuthContext = Depends(require_auth)) -> dict[str, Any]:
    _ = auth
    return {"ok": True, "result": read_range(_root(request), payload.path, payload.offset, payload.length)}


@router.post("/head")
def head(payload: ReadRequest, request: Request, auth: AuthContext = Depends(require_auth)) -> dict[str, Any]:
    _ = auth
    return {"ok": True, "result": read_range(_root(request), payload.path, 0, payload.length)}


@router.post("/tail")
def tail(payload: ReadRequest, request: Request, auth: AuthContext = Depends(require_auth)) -> dict[str, Any]:
    _ = auth
    path = resolve_path(_root(request), payload.path)
    size = path.stat().st_size
    return {"ok": True, "result": read_range(_root(request), payload.path, max(0, size - payload.length), payload.length)}


@router.post("/write-file")
def write(payload: WriteRequest, request: Request, auth: AuthContext = Depends(require_auth)) -> dict[str, Any]:
    _ = auth
    return {"ok": True, "result": write_file(_root(request), payload.path, payload.content, payload.expected_checksum)}


@router.post("/apply-patch")
def patch(payload: PatchRequest, request: Request, auth: AuthContext = Depends(require_auth)) -> dict[str, Any]:
    _ = auth
    return {"ok": True, "result": apply_replacements(_root(request), payload.path, payload.replacements, payload.expected_checksum)}


@router.post("/diff")
def diff(payload: DiffRequest, request: Request, auth: AuthContext = Depends(require_auth)) -> dict[str, Any]:
    _ = auth
    path = resolve_path(_root(request), payload.path)
    current = path.read_text(encoding="utf-8").splitlines(keepends=True) if path.exists() else []
    proposed = payload.content.splitlines(keepends=True)
    value = "".join(difflib.unified_diff(current, proposed, fromfile=payload.path, tofile=payload.path + ".proposed"))
    return {"ok": True, "result": {"path": str(path), "diff": value}}


@router.post("/stat")
def stat(payload: PathRequest, request: Request, auth: AuthContext = Depends(require_auth)) -> dict[str, Any]:
    _ = auth
    return {"ok": True, "result": stat_path(_root(request), payload.path)}


@router.post("/checksum")
def checksum(payload: PathRequest, request: Request, auth: AuthContext = Depends(require_auth)) -> dict[str, Any]:
    _ = auth
    path = resolve_path(_root(request), payload.path)
    return {"ok": True, "result": {"path": str(path), "sha256": checksum_file(path)}}


@router.post("/list-dir")
def listing(payload: ListRequest, request: Request, auth: AuthContext = Depends(require_auth)) -> dict[str, Any]:
    _ = auth
    return {"ok": True, "result": list_dir(_root(request), payload.path, payload.recursive, payload.limit)}


@router.post("/grep")
@router.post("/search")
def search(payload: SearchRequest, request: Request, auth: AuthContext = Depends(require_auth)) -> dict[str, Any]:
    _ = auth
    return {"ok": True, "result": search_text(_root(request), payload.query, payload.path, payload.glob, payload.limit)}


@router.post("/find")
def find(payload: FindRequest, request: Request, auth: AuthContext = Depends(require_auth)) -> dict[str, Any]:
    _ = auth
    return {"ok": True, "result": find_paths(_root(request), payload.pattern, payload.path, payload.limit)}
