﻿param(
  [Parameter(Mandatory=$true)]
  [ValidateSet('bridge.snapshot','git.status','github.status','codex.version','codex.status')]
  [string]$Operation,
  [string]$Repo = 'H:\bridge'
)
$ErrorActionPreference='Continue'
$userProfile='C:\Users\Azerbaijan'
$codex='C:\Users\Azerbaijan\Tools\nodejs\node-v24.13.1-win-x64\codex.cmd'
$codexHome=Join-Path $userProfile '.codex'
$ghConfig=Join-Path $userProfile 'AppData\Roaming\GitHub CLI'
function Invoke-CodexScoped([string[]]$CodexArgs){
  if(-not (Test-Path $codex)){ throw "CODEX_EXECUTABLE_MISSING: $codex" }
  $oldCH=$env:CODEX_HOME; $oldUP=$env:USERPROFILE; $oldH=$env:HOME
  try {
    $env:CODEX_HOME=$codexHome; $env:USERPROFILE=$userProfile; $env:HOME=$userProfile
    $text=(& $codex @CodexArgs 2>&1 | Out-String).Trim()
    [pscustomobject]@{exit_code=$LASTEXITCODE;output=$text}
  } finally { $env:CODEX_HOME=$oldCH; $env:USERPROFILE=$oldUP; $env:HOME=$oldH }
}
function Invoke-GhStatus {
  $gh=(Get-Command gh -ErrorAction SilentlyContinue).Source
  if(-not $gh){ return [pscustomobject]@{available=$false;status='GH_EXECUTABLE_MISSING'} }
  $old=$env:GH_CONFIG_DIR
  try {
    $env:GH_CONFIG_DIR=$ghConfig
    $text=(& $gh auth status 2>&1 | Out-String).Trim()
    $exit=$LASTEXITCODE
    $safe=($text -split "`r?`n" | Where-Object { $_ -notmatch '^\s*- Token:' }) -join "`n"
    [pscustomobject]@{available=$true;exit_code=$exit;config_root=$ghConfig;output=$safe}
  } finally { $env:GH_CONFIG_DIR=$old }
}switch($Operation){
  'git.status' {
    $top=(& git -C $Repo rev-parse --show-toplevel 2>&1 | Out-String).Trim(); $ec=$LASTEXITCODE
    if($ec -ne 0){ [pscustomobject]@{operation=$Operation;repo=$Repo;is_git_repo=$false;detail=$top} | ConvertTo-Json -Depth 5; exit 0 }
    $status=(& git -C $Repo status --short --branch 2>&1 | Out-String).Trim()
    [pscustomobject]@{operation=$Operation;repo=$Repo;is_git_repo=$true;top=$top;status=$status} | ConvertTo-Json -Depth 5
  }
  'github.status' { $g=Invoke-GhStatus; [pscustomobject]@{operation=$Operation;result=$g} | ConvertTo-Json -Depth 6 }
  'codex.version' { $c=Invoke-CodexScoped @('--version'); [pscustomobject]@{operation=$Operation;result=$c} | ConvertTo-Json -Depth 5 }
  'codex.status' { $c=Invoke-CodexScoped @('login','status'); [pscustomobject]@{operation=$Operation;result=$c} | ConvertTo-Json -Depth 5 }
  'bridge.snapshot' {
    $listeners=@(18787,18788,18789,18790 | ForEach-Object { $p=$_; $hit=Get-NetTCPConnection -State Listen -LocalPort $p -ErrorAction SilentlyContinue; [pscustomobject]@{port=$p;listening=[bool]$hit} })
    $c=Invoke-CodexScoped @('login','status'); $g=Invoke-GhStatus
    $gitTop=(& git -C $Repo rev-parse --show-toplevel 2>&1 | Out-String).Trim(); $gitEc=$LASTEXITCODE
    [pscustomobject]@{
      operation=$Operation; observed_at=(Get-Date).ToString('o'); execution_identity=(& whoami | Out-String).Trim(); expected_root='H:\bridge'; root_exists=(Test-Path 'H:\bridge'); listeners=$listeners;
      codex=[pscustomobject]@{executable_exists=(Test-Path $codex);home_exists=(Test-Path $codexHome);login_exit_code=$c.exit_code;login_status=$c.output};
      github=$g; git=[pscustomobject]@{repo=$Repo;is_git_repo=($gitEc -eq 0);detail=$gitTop}
    } | ConvertTo-Json -Depth 8
  }
}


