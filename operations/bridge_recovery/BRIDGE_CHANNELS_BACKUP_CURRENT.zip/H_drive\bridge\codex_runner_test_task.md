﻿Create exactly one file in repo root named CODEX_RUNNER_V0_DISPOSABLE_RESULT.txt.
Content exactly:
STATUS: CODEX_RUNNER_V0_DISPOSABLE_DONE
Do not edit anything else. Do not commit.
