﻿# Emergency Channel V1 — CANDIDATE

Independent path target:

Cloudflare Tunnel -> PowerShell/.NET HttpListener 127.0.0.1:18789 -> allowlisted recovery actions

Independence boundary:
- different tunnel provider from ngrok;
- different local runtime from Python Gateway/Primary;
- separate Machine token `BRIDGE_EMERGENCY_TOKEN`;
- separate SYSTEM startup task;
- no arbitrary terminal endpoint.

Endpoints:
- GET /health
- GET /status
- POST /action/recover-bridge
- POST /action/reboot with header `X-Recovery-Confirm: REBOOT` and exact JSON body.

Status: CODE_CANDIDATE / NOT_INSTALLED / NOT_STARTED / NOT_EXTERNALLY_ROUTED / NOT_PROVEN_LIVE.

Required before install:
1. Owner creates a separate Cloudflare Tunnel/hostname or token.
2. Owner adds a second GPT Action bound to that hostname.
3. Generate a new independent emergency token; never reuse or expose the Bridge token.
4. Export current scheduled tasks and create rollback checkpoint.
5. Local syntax/negative tests, then local process proof, then external proof.
6. Only after both channels are proven, run one-layer-at-a-time fault tests.
