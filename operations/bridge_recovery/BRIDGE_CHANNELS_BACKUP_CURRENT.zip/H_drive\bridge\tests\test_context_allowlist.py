from pathlib import Path

from bridge_app.core.config import BridgeSettings
from bridge_app.core.context_check import check_route_context
from bridge_app.core.models import ContextCheckRequest


def test_context_allowlist_accepts_configured_roots(tmp_path: Path) -> None:
    bridge = tmp_path / "bridge"
    efab = tmp_path / "efab"
    bridge.mkdir()
    efab.mkdir()
    settings = BridgeSettings(root_dir=bridge, allowed_roots=[bridge, efab])

    assert check_route_context(
        ContextCheckRequest(expected_root=str(bridge), cwd=str(bridge)), settings
    ).command_allowed is True
    assert check_route_context(
        ContextCheckRequest(expected_root=str(efab), cwd=str(efab)), settings
    ).command_allowed is True


def test_context_allowlist_blocks_unconfigured_root_before_execution(tmp_path: Path) -> None:
    bridge = tmp_path / "bridge"
    forbidden = tmp_path / "forbidden"
    bridge.mkdir()
    forbidden.mkdir()
    settings = BridgeSettings(root_dir=bridge, allowed_roots=[bridge])

    result = check_route_context(
        ContextCheckRequest(expected_root=str(forbidden), cwd=str(forbidden)), settings
    )

    assert result.command_allowed is False
    assert result.context_status == "CONTEXT_MISMATCH"
    assert "allow-list" in result.root_cause
    assert str(forbidden.resolve()) in result.next_actions[1]


def test_context_allowlist_defaults_to_primary_root(tmp_path: Path) -> None:
    bridge = tmp_path / "bridge"
    other = tmp_path / "other"
    bridge.mkdir()
    other.mkdir()
    settings = BridgeSettings(root_dir=bridge)

    assert check_route_context(
        ContextCheckRequest(expected_root=str(bridge), cwd=str(bridge)), settings
    ).command_allowed is True
    assert check_route_context(
        ContextCheckRequest(expected_root=str(other), cwd=str(other)), settings
    ).command_allowed is False
