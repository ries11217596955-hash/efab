﻿# GPT Action Bridge dev recovery

Use this only for the current dev route.

Start/recover route:

```powershell
cd H:\bridge
.\start_gpt_action_bridge_dev.ps1
```

Stop route:

```powershell
cd H:\bridge
.\stop_gpt_action_bridge_dev.ps1
```

GPT Action auth must be:

- Type: API key
- Subtype: Custom
- Header name: ngrok-skip-browser-warning
- Value: true

Do not put X-Bridge-Token into GPT Action. The local ngrok process injects it into upstream requests.

After start, copy the generated SchemaPath JSON into the GPT Action schema if the public URL changed.

Persistence proof is separate from route proof: after saving/updating the GPT, refresh the GPT editor and test getHealth again.
