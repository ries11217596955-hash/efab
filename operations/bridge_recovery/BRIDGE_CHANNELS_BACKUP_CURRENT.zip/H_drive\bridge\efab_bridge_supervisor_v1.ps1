﻿param(
  [string]$Root = "H:\bridge",
  [string]$StartReason = "MANUAL",
  [int]$Port = 18787,
  [string]$PublicUrl = "https://scabbed-corner-gap.ngrok-free.dev",
  [int]$NetworkWaitSeconds = 180,
  [switch]$Once,
  [switch]$NoStart
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Continue"

$RuntimeDir = Join-Path $Root "runtime"
$LogDir = Join-Path $Root "supervisor_logs"
$StatusPath = Join-Path $RuntimeDir "bridge_status.json"
$StartScript = Join-Path $Root "start_gpt_action_bridge_dev.ps1"
New-Item -ItemType Directory -Force -Path $RuntimeDir,$LogDir | Out-Null
$LogPath = Join-Path $LogDir ("efab_bridge_supervisor_v1-" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".log")

function Write-SupervisorLog([string]$Message) {
  $line = (Get-Date).ToString("o") + " " + $Message
  Add-Content -Path $LogPath -Value $line -Encoding UTF8
  Write-Host $line
}

function Test-NetworkReady {
  $targets = @(
    @{ host = "1.1.1.1"; port = 443; name = "cloudflare_ip" },
    @{ host = "google.com"; port = 443; name = "google_dns" }
  )
  foreach ($t in $targets) {
    try {
      $r = Test-NetConnection $t.host -Port $t.port -InformationLevel Quiet -WarningAction SilentlyContinue
      if ($r) { return [pscustomobject]@{ ok=$true; target=$t.name; error=$null } }
    } catch { }
  }
  return [pscustomobject]@{ ok=$false; target=$null; error="network targets unreachable" }
}

function Test-LocalBridge([int]$CheckPort) {
  try {
    $h = Invoke-RestMethod "http://127.0.0.1:$CheckPort/health" -TimeoutSec 5
    return [pscustomobject]@{ ok=([bool]$h.ok); status=$h.status; error=$null }
  } catch {
    return [pscustomobject]@{ ok=$false; status=$null; error=$_.Exception.Message }
  }
}

function Get-NgrokState([int]$CheckPort) {
  $proc = @(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^ngrok' -or $_.CommandLine -match 'ngrok.*127\.0\.0\.1' })
  $apiOk = $false
  $public = $null
  $addr = $null
  $tunnelOk = $false
  $error = $null
  try {
    $t = Invoke-RestMethod "http://127.0.0.1:4040/api/tunnels" -TimeoutSec 5
    $hit = $t.tunnels | Where-Object { $_.public_url -like "https://*" } | Select-Object -First 1
    if ($hit) {
      $apiOk = $true
      $public = $hit.public_url
      $addr = $hit.config.addr
      $tunnelOk = ($addr -eq "http://127.0.0.1:$CheckPort")
    }
  } catch { $error = $_.Exception.Message }
  return [pscustomobject]@{ process_count=@($proc).Count; api_ok=$apiOk; public_url=$public; addr=$addr; tunnel_ok=$tunnelOk; error=$error }
}

function Test-PublicRoute([string]$Url) {
  try {
    $r = Invoke-WebRequest "$Url/health" -Headers @{ "ngrok-skip-browser-warning"="true" } -UseBasicParsing -TimeoutSec 15
    return [pscustomobject]@{ ok=($r.StatusCode -eq 200 -and $r.Content -match "Local Bridge"); status_code=$r.StatusCode; error=$null }
  } catch {
    $code = $null
    if ($_.Exception.Response) { try { $code = [int]$_.Exception.Response.StatusCode } catch {} }
    return [pscustomobject]@{ ok=$false; status_code=$code; error=$_.Exception.Message }
  }
}

function Write-BridgeStatus($State) {
  $State | ConvertTo-Json -Depth 8 | Set-Content -Path $StatusPath -Encoding UTF8
}

function Get-BridgeState([string]$Phase, [string]$RecoveryReason = $null, [string]$LastAction = $null) {
  $network = Test-NetworkReady
  $local = Test-LocalBridge -CheckPort $Port
  $ngrok = Get-NgrokState -CheckPort $Port
  $public = Test-PublicRoute -Url $PublicUrl
  $routeOk = ($network.ok -and $local.ok -and $ngrok.tunnel_ok -and $public.ok)
  return [ordered]@{
    schema = "EFAB_BRIDGE_STATUS_V1"
    timestamp = (Get-Date).ToString("o")
    start_reason = $StartReason
    phase = $Phase
    route_ok = $routeOk
    network = $network
    local_bridge = $local
    ngrok = $ngrok
    public_route = $public
    recovery_reason = $RecoveryReason
    last_action = $LastAction
    root = $Root
    port = $Port
    public_url_expected = $PublicUrl
    status_path = $StatusPath
    log_path = $LogPath
    no_start = [bool]$NoStart
    once = [bool]$Once
  }
}

Write-SupervisorLog "SUPERVISOR_BEGIN version=V1 reason=$StartReason root=$Root port=$Port no_start=$NoStart once=$Once"

$deadline = (Get-Date).AddSeconds($NetworkWaitSeconds)
do {
  $network = Test-NetworkReady
  if ($network.ok) { break }
  $state = Get-BridgeState -Phase "WAIT_NETWORK" -RecoveryReason "NO_NETWORK" -LastAction "WAIT"
  Write-BridgeStatus $state
  Write-SupervisorLog "NETWORK_WAIT target=none remaining=$([int]($deadline-(Get-Date)).TotalSeconds)"
  Start-Sleep -Seconds 5
} while ((Get-Date) -lt $deadline)

$state = Get-BridgeState -Phase "OBSERVE"
Write-BridgeStatus $state
Write-SupervisorLog ("OBSERVE route_ok=" + $state.route_ok + " network=" + $state.network.ok + " local=" + $state.local_bridge.ok + " ngrok_tunnel=" + $state.ngrok.tunnel_ok + " public=" + $state.public_route.ok)

if (-not $state.route_ok) {
  $reason = if (-not $state.network.ok) { "NO_NETWORK" }
            elseif (-not $state.local_bridge.ok) { "LOCAL_HEALTH_FAIL" }
            elseif ($state.ngrok.process_count -eq 0) { "NGROK_MISSING" }
            elseif (-not $state.ngrok.tunnel_ok) { "NGROK_TUNNEL_BAD" }
            elseif (-not $state.public_route.ok) { "PUBLIC_ROUTE_FAIL" }
            else { "UNKNOWN_ROUTE_FAIL" }
  Write-SupervisorLog "RECOVERY_NEEDED reason=$reason"
  if ($NoStart) {
    $state = Get-BridgeState -Phase "RECOVERY_SKIPPED" -RecoveryReason $reason -LastAction "NO_START"
    Write-BridgeStatus $state
    Write-SupervisorLog "RECOVERY_SKIPPED no_start=true"
  } elseif (Test-Path $StartScript) {
    Write-SupervisorLog "RECOVERY_START_SCRIPT_BEGIN path=$StartScript"
    try {
      $p = Start-Process powershell -WindowStyle Hidden -ArgumentList "-NoProfile","-ExecutionPolicy","Bypass","-File",$StartScript,"-Root",$Root,"-Port",$Port -PassThru
      Write-SupervisorLog "RECOVERY_START_SCRIPT_LAUNCHED pid=$($p.Id)"
      Start-Sleep -Seconds 45
    } catch {
      Write-SupervisorLog "RECOVERY_START_SCRIPT_FAIL=$($_.Exception.Message)"
    }
    $state = Get-BridgeState -Phase "AFTER_RECOVERY" -RecoveryReason $reason -LastAction "START_SCRIPT"
    Write-BridgeStatus $state
    Write-SupervisorLog ("AFTER_RECOVERY route_ok=" + $state.route_ok + " network=" + $state.network.ok + " local=" + $state.local_bridge.ok + " ngrok_tunnel=" + $state.ngrok.tunnel_ok + " public=" + $state.public_route.ok)
  } else {
    $state = Get-BridgeState -Phase "RECOVERY_BLOCKED" -RecoveryReason $reason -LastAction "START_SCRIPT_MISSING"
    Write-BridgeStatus $state
    Write-SupervisorLog "RECOVERY_BLOCKED start_script_missing"
  }
}

Write-SupervisorLog "SUPERVISOR_END"
if ($state.route_ok) { exit 0 } else { exit 2 }
