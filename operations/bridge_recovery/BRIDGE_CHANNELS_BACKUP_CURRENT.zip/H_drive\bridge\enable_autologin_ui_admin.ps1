﻿$ErrorActionPreference = "Continue"
$Log = "H:\bridge\enable_autologin_ui_admin.log"
function Log([string]$m) { Add-Content -Encoding UTF8 -Path $Log -Value "$(Get-Date -Format o) $m" }
Log "BEGIN"
try {
  $reg = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\PasswordLess\Device"
  if (-not (Test-Path $reg)) { New-Item -Path $reg -Force | Out-Null }
  $before = (Get-ItemProperty -Path $reg -Name DevicePasswordLessBuildVersion -ErrorAction SilentlyContinue).DevicePasswordLessBuildVersion
  Set-ItemProperty -Path $reg -Name DevicePasswordLessBuildVersion -Type DWord -Value 0
  $after = (Get-ItemProperty -Path $reg -Name DevicePasswordLessBuildVersion).DevicePasswordLessBuildVersion
  Log "DevicePasswordLessBuildVersion before=$before after=$after"
  Start-Process -FilePath "netplwiz.exe"
  Log "NETPLWIZ_LAUNCHED"
  Start-Process "ms-settings:signinoptions"
  Log "SIGNIN_SETTINGS_LAUNCHED"
} catch {
  Log "ERROR=$($_.Exception.Message)"
}
Log "END"
