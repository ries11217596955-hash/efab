﻿$ErrorActionPreference='Stop'
$root='C:\ProgramData\EFAB-Rescue'
$proof=Join-Path $root 'drill_primary_restart_20260726.json'
$token=(Get-Content (Join-Path $root 'rescue_token.txt') -Raw).Trim()
$h=@{'X-Rescue-Token'=$token}
$start=Get-Date
$result=[ordered]@{started_at=$start.ToUniversalTime().ToString('o');before=$null;restart_response=$null;after=$null;status='NOT_PROVEN';errors=@()}
try{$result.before=Invoke-RestMethod -Uri 'http://127.0.0.1:18789/status' -Headers $h -TimeoutSec 10}catch{$result.errors+=('before:'+$_.Exception.Message)}
try{$result.restart_response=Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:18789/primary/restart' -Headers $h -TimeoutSec 20}catch{$result.errors+=('restart:'+$_.Exception.Message)}
$ok=$false
for($i=0;$i -lt 24;$i++){
  Start-Sleep 5
  try{
    $r=Invoke-RestMethod -Uri 'http://127.0.0.1:18789/status' -Headers $h -TimeoutSec 5
    if($r.result.primary.listening){$result.after=$r;$ok=$true;break}
  }catch{$result.errors+=('poll'+$i+':'+$_.Exception.Message)}
}
$result.finished_at=(Get-Date).ToUniversalTime().ToString('o')
$result.elapsed_seconds=[int]((Get-Date)-$start).TotalSeconds
$result.status=if($ok){'PROVEN_LIVE_PRIMARY_RESTART_VIA_RESCUE'}else{'FAIL'}
$result|ConvertTo-Json -Depth 10|Set-Content -Encoding UTF8 $proof
