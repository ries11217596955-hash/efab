﻿$ErrorActionPreference='Continue'
$Task='EFAB PC Control SYSTEM'
$TokenPath='C:\ProgramData\EFAB-Rescue\rescue_token.txt'
$Log='C:\ProgramData\EFAB-PC-Control\watchdog.jsonl'
$healthy=$false
if(Test-Path $TokenPath){
 $token=(Get-Content $TokenPath -Raw).Trim()
 try{$r=Invoke-RestMethod -Uri 'http://127.0.0.1:18790/health' -Headers @{'X-Rescue-Token'=$token} -TimeoutSec 5;$healthy=[bool]$r.ok}catch{}
}
if(-not$healthy){
 Stop-ScheduledTask -TaskName $Task -ErrorAction SilentlyContinue
 Start-Sleep 1
 Start-ScheduledTask -TaskName $Task -ErrorAction SilentlyContinue
 Start-Sleep 3
 try{$r=Invoke-RestMethod -Uri 'http://127.0.0.1:18790/health' -Headers @{'X-Rescue-Token'=$token} -TimeoutSec 5;$healthy=[bool]$r.ok}catch{}
}
([ordered]@{ts=(Get-Date).ToUniversalTime().ToString('o');healthy=$healthy}|ConvertTo-Json -Compress)|Add-Content $Log -Encoding UTF8
