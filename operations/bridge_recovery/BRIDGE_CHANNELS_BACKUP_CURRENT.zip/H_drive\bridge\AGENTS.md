# AGENTS.md — Local Bridge working contract for Codex

## Purpose

Build Local Bridge as a strong local execution/reporting tool for Owner/GPT.

Local Bridge connects GPT/Owner with:
- local terminal
- local repo state
- Codex task handoff
- reports/logs/artifacts
- OpenAPI/GPT Action surface

Bridge is a tool, not Builder brain, not policy brain, not route owner, not a generic automation platform.

## Product target

Full-capability Bridge target:

- API service
- terminal execution layer
- detached run lifecycle
- Codex handoff layer
- git/repo operations
- report/proof artifacts
- OpenAPI/GPT Action schema
- config/auth
- tests/docs
- future tunnel/deployment support

Build passes may be bounded, but code must belong to the final architecture.
Do not create throwaway prototypes.
Do not fake success for future capabilities.

## Current implementation target

Current task package: `codex_tasks/BUILD_PASS_01_FOUNDATION_20260624/`

Foundation pass means:
- final product skeleton exists
- main layers and contracts are visible
- core config/reports/OpenAPI/tests exist
- first working endpoints prove the skeleton

Foundation pass does not mean:
- toy implementation
- weak product
- fake endpoints
- arbitrary broad automation

## Recommended stack

Use Python + FastAPI + uvicorn + Pydantic + pytest unless repo evidence proves a better local reason.

Use ready infrastructure where possible:
- FastAPI for API/OpenAPI
- pytest for tests
- subprocess/PowerShell later for terminal adapter
- Codex CLI later through task files and command wrapper

Custom code should focus on:
- Bridge API contract
- local execution wrapper contracts
- Codex handoff wrapper contracts
- report schema/writer
- GPT Action compatible interface
- Owner-friendly output

## File/folder boundaries

Allowed to create/edit for Bridge tasks:
- `AGENTS.md`
- `README.md`
- `pyproject.toml`
- `src/`
- `tests/`
- `docs/`
- `reports/`
- `runs/`
- `schemas/`
- `codex_tasks/`

Do not touch unless explicitly requested:
- unrelated repos
- live runtime files
- accepted memory
- route locks
- secrets/env files
- external account config
- main branch commit/push surfaces
- unrelated large refactors

## Context and token saving rules

Codex must:
- inspect targeted files only
- avoid broad scans unless task requires it
- summarize large files instead of pasting them
- write long logs to files and return paths
- return concise reports
- show only relevant diffs
- avoid re-reading unchanged large files
- ask only necessary questions

Do not dump full logs into chat unless requested.

## Working style

For every task:
1. Read this AGENTS.md.
2. Read the task package files.
3. Restate task understanding briefly.
4. Inspect only necessary files.
5. Create a small execution plan before changes.
6. Implement within scope.
7. Run required validation commands.
8. Return the required structured report.

## Report format

Every Codex task must return:

STATUS
TASK_UNDERSTANDING
EXECUTION_PLAN
SUMMARY
FILES_CREATED
FILES_CHANGED
COMMANDS_RUN
TEST_RESULTS
OPENAPI_STATUS
REPORT_PATHS
KNOWN_LIMITATIONS
OUT_OF_SCOPE_NOT_IMPLEMENTED
RISKS
NEXT_RECOMMENDED_CONSTRUCTION_PASS

If incomplete, return:

STATUS: BLOCKED
STOP_REASON
WHAT_WAS_DONE
WHAT_IS_MISSING
SMALLEST_SAFE_NEXT_STEP

## Forbidden overreach

Do not:
- build a new brain/agent/policy engine
- build a generic automation platform
- implement everything in one giant task
- invent hidden requirements
- fake working endpoints
- return OK for unimplemented operations
- commit or push
- mutate external repos
- hide failed tests
- claim done without validation

## Evidence rule

Reports/logs/test output are evidence.
Acceptance is separate and decided by Owner/GPT after review.

## Semantic Invariants and Independent Audit Rule

Pytest PASS is not enough for acceptance.

For every serious implementation task, Codex must preserve semantic invariants defined by the task and acceptance files.

A Codex task is not complete until:
- implementation is done inside scope
- tests pass
- required reports/artifacts are written
- independent post-Codex audit passes
- no semantic blocker remains

If independent audit fails, stop next-pass work and repair the failed invariant first.

Forbidden:
- moving to the next construction pass after a failed audit
- treating green tests as acceptance when semantic audit failed
- hiding or minimizing failed edge cases
- calling an output complete because endpoints exist

When adding execution capabilities, exact evidence matters.

Terminal execution invariant:
- exit_code must preserve the exact child/native command exit code
- stdout and stderr must be captured separately
- timeout must not hang the API
- invalid cwd must fail before execution
- reports and run artifacts must be written for completed/failed/timeout runs

Example required proof:
- python --version returns exit_code 0
- python -c 'import sys; sys.exit(7)' returns exit_code 7
- stderr-producing command preserves stderr evidence
- timeout case returns timed_out true
- invalid cwd returns clear error

Codex output status remains CODEX_DRAFT until Owner/GPT reviews proof and accepts the pass.

## Cross-chat Bridge capability continuity

For every new GPT/remote-control session touching Bridge, do not reconstruct invocation details from chat history.

Mandatory read-only bootstrap:
1. `getHealth`.
2. `checkContext` with `H:\bridge`.
3. Read `docs/EF_BRIDGE_CONTINUITY_ENTRYPOINT.md` and `schemas/EF_BRIDGE_CAPABILITY_REGISTRY.v1.json`.
4. Use `src/invoke_ef_tool_v1.ps1 -Operation bridge.snapshot` for the fresh local capability snapshot.
5. Fresh runtime proof overrides notebook/history/configuration claims.

Primary Bridge runs as SYSTEM. User-tool credentials/profile must be accessed only through the canonical scoped wrapper; never infer GitHub/Codex auth from SYSTEM defaults and never print secret contents.
