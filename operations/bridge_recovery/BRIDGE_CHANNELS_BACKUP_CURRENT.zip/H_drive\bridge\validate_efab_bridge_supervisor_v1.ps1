﻿param(
  [string]$Root = "H:\bridge"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$Supervisor = Join-Path $Root "efab_bridge_supervisor_v1.ps1"
$StatusPath = Join-Path $Root "runtime\bridge_status.json"
$errors = New-Object System.Collections.Generic.List[string]

if (-not (Test-Path $Supervisor)) { $errors.Add("supervisor_missing") }
if (-not (Test-Path $StatusPath)) { $errors.Add("status_missing") }

$parseErrors = $null
$tokens = $null
[System.Management.Automation.Language.Parser]::ParseFile($Supervisor, [ref]$tokens, [ref]$parseErrors) | Out-Null
if ($parseErrors.Count -gt 0) { $errors.Add("supervisor_parse_errors=" + $parseErrors.Count) }

if (Test-Path $StatusPath) {
  try {
    $s = Get-Content $StatusPath -Raw | ConvertFrom-Json
    foreach ($field in @("schema","timestamp","route_ok","network","local_bridge","ngrok","public_route","phase")) {
      if (-not ($s.PSObject.Properties.Name -contains $field)) { $errors.Add("missing_status_field=$field") }
    }
    if ($s.schema -ne "EFAB_BRIDGE_STATUS_V1") { $errors.Add("bad_schema=" + $s.schema) }
  } catch { $errors.Add("status_json_parse_fail=" + $_.Exception.Message) }
}

if ($errors.Count -gt 0) {
  Write-Host "VALIDATION_FAIL=EFAB_BRIDGE_SUPERVISOR_V1"
  $errors | ForEach-Object { Write-Host $_ }
  exit 1
}
Write-Host "VALIDATION_PASS=EFAB_BRIDGE_SUPERVISOR_V1"
exit 0
