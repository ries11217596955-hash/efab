﻿param([int]$Port = 18787)
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
Stop-Process -Name ngrok -Force -ErrorAction SilentlyContinue
Get-NetTCPConnection -LocalPort $Port -ErrorAction SilentlyContinue |
  Select-Object -ExpandProperty OwningProcess -Unique |
  Where-Object { $_ -ne 0 } |
  ForEach-Object { Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue }
Write-Host "BRIDGE_GPT_ACTION_DEV_ROUTE_STOPPED"

