param(
    [int]$Port = 18790,
    [string]$Root = 'C:\ProgramData\EFAB-PC-Control',
    [string]$TokenPath = 'C:\ProgramData\EFAB-Rescue\rescue_token.txt'
)
$ErrorActionPreference='Stop'
$RunRoot = Join-Path $Root 'runs'
$LogPath = Join-Path $Root 'pc_control.jsonl'
$WorkerPath = Join-Path $Root 'pc_control_worker.ps1'
$Version = '1.0.0'
New-Item -ItemType Directory -Force -Path $Root,$RunRoot | Out-Null

function Log([string]$Event,[hashtable]$Data=@{}){
  $row=[ordered]@{ts=(Get-Date).ToUniversalTime().ToString('o');event=$Event;pid=$PID;version=$Version}
  foreach($k in $Data.Keys){$row[$k]=$Data[$k]}
  ($row|ConvertTo-Json -Compress -Depth 8)|Add-Content -LiteralPath $LogPath -Encoding UTF8
}
function Json($ctx,[int]$status,$obj){
  $j=$obj|ConvertTo-Json -Compress -Depth 12
  $b=[Text.Encoding]::UTF8.GetBytes($j)
  $ctx.Response.StatusCode=$status
  $ctx.Response.ContentType='application/json'
  $ctx.Response.ContentEncoding=[Text.Encoding]::UTF8
  $ctx.Response.ContentLength64=$b.Length
  $ctx.Response.OutputStream.Write($b,0,$b.Length)
  $ctx.Response.OutputStream.Close()
}
function ReadBody($req){
  $r=[IO.StreamReader]::new($req.InputStream,$req.ContentEncoding)
  try{$t=$r.ReadToEnd()}finally{$r.Dispose()}
  if([string]::IsNullOrWhiteSpace($t)){return [pscustomobject]@{}}
  return $t|ConvertFrom-Json
}
function SecureEq([string]$a,[string]$b){
  if($null -eq $a -or $null -eq $b){return $false}
  $ab=[Text.Encoding]::UTF8.GetBytes($a);$bb=[Text.Encoding]::UTF8.GetBytes($b)
  if($ab.Length -ne $bb.Length){return $false}
  $d=0;for($i=0;$i -lt $ab.Length;$i++){$d=$d -bor ($ab[$i]-bxor $bb[$i])}
  return $d -eq 0
}
function Authorized($req){
  if(-not(Test-Path -LiteralPath $TokenPath)){return $false}
  $expected=(Get-Content -LiteralPath $TokenPath -Raw).Trim()
  $custom=$req.Headers['X-Rescue-Token']
  $auth=$req.Headers['Authorization'];$bearer=$null
  if($auth -and $auth.StartsWith('Bearer ',[StringComparison]::OrdinalIgnoreCase)){$bearer=$auth.Substring(7).Trim()}
  return (SecureEq $custom $expected) -or (SecureEq $bearer $expected)
}
function ValidRunId([string]$id){ return $id -match '^pc_run-[0-9]{8}-[0-9]{6}-[a-f0-9]{8}$' }
function RunState([string]$id){
  if(-not(ValidRunId $id)){throw 'INVALID_RUN_ID'}
  $dir=Join-Path $RunRoot $id
  if(-not(Test-Path -LiteralPath $dir)){return [pscustomobject]@{found=$false;run_id=$id}}
  $req=Get-Content (Join-Path $dir 'request.json') -Raw|ConvertFrom-Json
  $resultPath=Join-Path $dir 'result.json'
  $metaPath=Join-Path $dir 'meta.json'
  $result=$null;$meta=$null
  if(Test-Path $resultPath){$result=Get-Content $resultPath -Raw|ConvertFrom-Json}
  if(Test-Path $metaPath){$meta=Get-Content $metaPath -Raw|ConvertFrom-Json}
  $alive=$false
  if($meta -and $meta.worker_pid){$alive=$null -ne (Get-Process -Id ([int]$meta.worker_pid) -ErrorAction SilentlyContinue)}
  $status=if($result -and $result.status -ne 'running'){[string]$result.status}elseif($alive){'running'}else{'starting'}
  return [pscustomobject]@{
    found=$true;run_id=$id;status=$status;shell=$req.shell;cwd=$req.cwd;
    requested_at=$req.requested_at;runtime_limit_seconds=$req.runtime_limit_seconds;
    worker_pid=if($meta){$meta.worker_pid}else{$null};process_alive=$alive;
    exit_code=if($result){$result.exit_code}else{$null};timed_out=if($result){$result.timed_out}else{$false};
    started_at=if($result){$result.started_at}elseif($meta){$meta.started_at}else{$null};
    finished_at=if($result){$result.finished_at}else{$null};
    stdout_path=(Join-Path $dir 'stdout.txt');stderr_path=(Join-Path $dir 'stderr.txt');result_path=$resultPath
  }
}
function Test-ManagedChannelState {
  $primary=$false;$rescue=$false;$ngrok=$false;$funnel=$false
  try{$h=Invoke-RestMethod 'http://127.0.0.1:18788/health' -TimeoutSec 5;$primary=[bool]$h.ok}catch{}
  try{$token=(Get-Content -LiteralPath $TokenPath -Raw).Trim();$h=Invoke-RestMethod 'http://127.0.0.1:18789/health' -Headers @{'X-Rescue-Token'=$token} -TimeoutSec 5;$rescue=[bool]$h.ok}catch{}
  try{$t=Invoke-RestMethod 'http://127.0.0.1:4040/api/tunnels' -TimeoutSec 5;$ngrok=(@($t.tunnels).Count -gt 0)}catch{}
  try{$s=(& tailscale funnel status 2>&1|Out-String);$funnel=($s -match '127\.0\.0\.1:18789' -and $s -match '127\.0\.0\.1:18790')}catch{}
  return [ordered]@{primary=$primary;rescue=$rescue;ngrok=$ngrok;tailscale_funnel=$funnel;checked_at=(Get-Date).ToUniversalTime().ToString('o')}
}
function Invoke-ReconcileAllChannels($Body){
  if([string]$Body.confirm -ne 'RECONCILE_ALL_CHANNELS'){throw 'CONFIRMATION_REQUIRED'}
  $before=Test-ManagedChannelState;$actions=@()
  if(-not $before.primary){Enable-ScheduledTask -TaskName 'EFAB Recovery Gateway SYSTEM' -ErrorAction SilentlyContinue|Out-Null;Start-ScheduledTask -TaskName 'EFAB Recovery Gateway SYSTEM' -ErrorAction Stop;Start-Sleep -Seconds 8;$ok=$false;try{$ok=[bool](Invoke-RestMethod 'http://127.0.0.1:18788/health' -TimeoutSec 5).ok}catch{};$actions+=[pscustomobject]@{component='primary';action='start_task';recovered=$ok}}
  if(-not $before.ngrok){Enable-ScheduledTask -TaskName 'EFAB Ngrok Watchdog SYSTEM' -ErrorAction SilentlyContinue|Out-Null;Start-ScheduledTask -TaskName 'EFAB Ngrok Primary SYSTEM' -ErrorAction Stop;Start-Sleep -Seconds 6;$ok=$false;try{$ok=(@((Invoke-RestMethod 'http://127.0.0.1:4040/api/tunnels' -TimeoutSec 5).tunnels).Count -gt 0)}catch{};$actions+=[pscustomobject]@{component='ngrok';action='start_task';recovered=$ok}}
  if(-not $before.rescue){Enable-ScheduledTask -TaskName 'EFAB Rescue Watchdog SYSTEM' -ErrorAction SilentlyContinue|Out-Null;Start-ScheduledTask -TaskName 'EFAB Rescue Control SYSTEM' -ErrorAction Stop;Start-Sleep -Seconds 6;$ok=$false;try{$token=(Get-Content -LiteralPath $TokenPath -Raw).Trim();$ok=[bool](Invoke-RestMethod 'http://127.0.0.1:18789/health' -Headers @{'X-Rescue-Token'=$token} -TimeoutSec 5).ok}catch{};$actions+=[pscustomobject]@{component='rescue';action='start_task';recovered=$ok}}
  if(-not $before.tailscale_funnel){& tailscale funnel --bg --yes --https=443 --set-path=/ http://127.0.0.1:18789|Out-Null;& tailscale funnel --bg --yes --https=443 --set-path=/pc-control http://127.0.0.1:18790|Out-Null;Start-Sleep -Seconds 3;$s=(& tailscale funnel status 2>&1|Out-String);$ok=($s -match '127\.0\.0\.1:18789' -and $s -match '127\.0\.0\.1:18790');$actions+=[pscustomobject]@{component='tailscale_funnel';action='ensure_routes';recovered=$ok}}
  foreach($n in @('EFAB Rescue Watchdog SYSTEM','EFAB Ngrok Watchdog SYSTEM')){Enable-ScheduledTask -TaskName $n -ErrorAction SilentlyContinue|Out-Null;Start-ScheduledTask -TaskName $n -ErrorAction SilentlyContinue}
  $after=Test-ManagedChannelState;$ok=([bool]$after.primary -and [bool]$after.rescue -and [bool]$after.ngrok -and [bool]$after.tailscale_funnel)
  return [pscustomobject]@{reconciled=$ok;before=$before;actions=@($actions);actions_count=@($actions).Count;after=$after;finished_at=(Get-Date).ToUniversalTime().ToString('o')}
}
$listener=[Net.HttpListener]::new()
$listener.Prefixes.Add("http://127.0.0.1:$Port/")
$listener.Start()
Log 'pc_control_started' @{port=$Port}
try{
 while($listener.IsListening){
  $ctx=$listener.GetContext()
  try{
   $path=$ctx.Request.Url.AbsolutePath.TrimEnd('/').ToLowerInvariant(); if($path -eq ''){$path='/'}
   $method=$ctx.Request.HttpMethod.ToUpperInvariant()
   if(-not(Authorized $ctx.Request)){Json $ctx 401 @{ok=$false;error=@{code='UNAUTHORIZED';message='Missing or invalid control token.'}};continue}
   if($method -eq 'GET' -and $path -eq '/health'){
    Json $ctx 200 @{ok=$true;service='EFAB PC Control';version=$Version;pid=$PID;port=$Port;root=$Root;shells=@('powershell','python');timestamp=(Get-Date).ToUniversalTime().ToString('o')};continue
   }
   if($method -eq 'POST' -and $path -eq '/runs/start'){
    $b=ReadBody $ctx.Request
    $shell=([string]$b.shell).ToLowerInvariant()
    if($shell -notin @('powershell','python')){throw 'INVALID_SHELL'}
    $command=[string]$b.command
    if([string]::IsNullOrWhiteSpace($command)){throw 'COMMAND_REQUIRED'}
    if($command.Length -gt 65536){throw 'COMMAND_TOO_LONG'}
    $cwd=[string]$b.cwd;if([string]::IsNullOrWhiteSpace($cwd)){$cwd='C:\'}
    if($cwd.StartsWith('\\')){throw 'UNC_CWD_FORBIDDEN'}
    $cwd=[IO.Path]::GetFullPath($cwd)
    if(-not(Test-Path -LiteralPath $cwd -PathType Container)){throw 'CWD_NOT_FOUND'}
    $limit=300
    if($null -ne $b.runtime_limit_seconds){$limit=[int]$b.runtime_limit_seconds}
    if($limit -lt 1 -or $limit -gt 3600){throw 'INVALID_RUNTIME_LIMIT'}
    $id='pc_run-{0}-{1}' -f (Get-Date).ToUniversalTime().ToString('yyyyMMdd-HHmmss'),([guid]::NewGuid().ToString('N').Substring(0,8))
    $dir=Join-Path $RunRoot $id;New-Item -ItemType Directory -Force -Path $dir|Out-Null
    $request=[ordered]@{run_id=$id;shell=$shell;command=$command;cwd=$cwd;runtime_limit_seconds=$limit;requested_at=(Get-Date).ToUniversalTime().ToString('o')}
    $request|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $dir 'request.json') -Encoding UTF8
    $w=Start-Process powershell.exe -ArgumentList @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',('"{0}"' -f $WorkerPath),'-RunDir',('"{0}"' -f $dir)) -WindowStyle Hidden -PassThru
    [ordered]@{worker_pid=$w.Id;started_at=(Get-Date).ToUniversalTime().ToString('o')}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $dir 'meta.json') -Encoding UTF8
    Log 'pc_run_started' @{run_id=$id;shell=$shell;cwd=$cwd;worker_pid=$w.Id}
    Json $ctx 202 @{ok=$true;result=(RunState $id)};continue
   }
   if($method -eq 'GET' -and $path -match '^/runs/([^/]+)$'){
    $id=[Uri]::UnescapeDataString($Matches[1]);$s=RunState $id;Json $ctx $(if($s.found){200}else{404}) @{ok=[bool]$s.found;result=$s};continue
   }
   if($method -eq 'GET' -and $path -match '^/runs/([^/]+)/logs$'){
    $id=[Uri]::UnescapeDataString($Matches[1]);$s=RunState $id
    if(-not$s.found){Json $ctx 404 @{ok=$false;error=@{code='RUN_NOT_FOUND'}};continue}
    $dir=Join-Path $RunRoot $id
    $outPath=Join-Path $dir 'stdout.txt';$errPath=Join-Path $dir 'stderr.txt'
    $out=if(Test-Path $outPath){[string](Get-Content -LiteralPath $outPath -Raw)}else{''}
    $err=if(Test-Path $errPath){[string](Get-Content -LiteralPath $errPath -Raw)}else{''}
    if($out.Length -gt 12000){$out=$out.Substring($out.Length-12000)}
    if($err.Length -gt 12000){$err=$err.Substring($err.Length-12000)}
    Json $ctx 200 @{ok=$true;result=@{run=$s;stdout_tail=$out;stderr_tail=$err}};continue
   }
   if($method -eq 'POST' -and $path -match '^/runs/([^/]+)/stop$'){
    $id=[Uri]::UnescapeDataString($Matches[1]);$s=RunState $id
    if(-not$s.found){Json $ctx 404 @{ok=$false;error=@{code='RUN_NOT_FOUND'}};continue}
    if($s.worker_pid -and $s.process_alive){& taskkill.exe /PID ([int]$s.worker_pid) /T /F | Out-Null}
    Log 'pc_run_stop_requested' @{run_id=$id}
    Json $ctx 200 @{ok=$true;result=(RunState $id)};continue
   }
   if($method -eq 'POST' -and $path -eq '/channels/reconcile-all'){
    $b=ReadBody $ctx.Request
    $r=Invoke-ReconcileAllChannels $b
    Log 'channels_reconcile_completed' @{reconciled=[bool]$r.reconciled;actions_count=[int]$r.actions_count}
    Json $ctx 200 @{ok=[bool]$r.reconciled;result=$r};continue
   }   Json $ctx 404 @{ok=$false;error=@{code='NOT_FOUND';message='Unknown PC-control route.'}}
  }catch{
   $m=$_.Exception.Message
   $code=if($m -match '^[A-Z0-9_]+$'){$m}else{'PC_CONTROL_ERROR'}
   Log 'request_error' @{path=$path;code=$code;error=$m}
   try{Json $ctx 400 @{ok=$false;error=@{code=$code;message=$m}}}catch{}
  }
 }
}finally{
 try{$listener.Stop()}catch{};try{$listener.Close()}catch{}
 Log 'pc_control_stopped' @{}
}
