﻿param(
    [switch]$Reboot,
    [int]$RebootDelaySeconds = 45
)

$ErrorActionPreference = "Stop"

$BridgeRoot = "H:\bridge"
$TargetRepo = "C:\Users\Azerbaijan\Downloads\e-factory-agent-builder"
$CodeCmd = "C:\Users\Azerbaijan\AppData\Local\Programs\Microsoft VS Code\bin\code.cmd"
$CodexAppId = "OpenAI.Codex_2p2nqsd0c76g0!App"
$StartupFolder = [Environment]::GetFolderPath("Startup")
$StartupScript = Join-Path $BridgeRoot "startup_after_login.ps1"
$StartupShortcut = Join-Path $StartupFolder "EFAB Bridge VSCode Codex Startup.lnk"
$LogDir = Join-Path $BridgeRoot "startup_logs"

New-Item -ItemType Directory -Force -Path $BridgeRoot, $LogDir | Out-Null

function Require-Path {
    param([string]$Path, [string]$Label)
    if (-not (Test-Path -LiteralPath $Path)) {
        throw "MISSING_$Label=$Path"
    }
}

Require-Path $BridgeRoot "BRIDGE_ROOT"
Require-Path (Join-Path $BridgeRoot "start_gpt_action_bridge_dev.ps1") "BRIDGE_START_SCRIPT"
Require-Path $TargetRepo "TARGET_REPO"
Require-Path $CodeCmd "VSCODE_CODE_CMD"

$startupBody = @"
`$ErrorActionPreference = "Continue"
`$BridgeRoot = "$BridgeRoot"
`$TargetRepo = "$TargetRepo"
`$CodeCmd = "$CodeCmd"
`$CodexAppId = "$CodexAppId"
`$LogDir = "$LogDir"
New-Item -ItemType Directory -Force -Path `$LogDir | Out-Null
`$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"
`$Log = Join-Path `$LogDir "startup_after_login-`$Stamp.log"

function Log([string]`$m) {
    `$line = "`$(Get-Date -Format o) `$m"
    Add-Content -Encoding UTF8 -Path `$Log -Value `$line
}

Log "STARTUP_BEGIN"
Log "BridgeRoot=`$BridgeRoot"
Log "TargetRepo=`$TargetRepo"

try {
    Log "START_BRIDGE"
    Start-Process -FilePath "powershell.exe" -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File", (Join-Path `$BridgeRoot "start_gpt_action_bridge_dev.ps1")) -WindowStyle Minimized
} catch { Log "START_BRIDGE_FAILED=`$($_.Exception.Message)" }

Start-Sleep -Seconds 8
try {
    Log "START_VSCODE"
    Start-Process -FilePath `$CodeCmd -ArgumentList @(`$TargetRepo) -WindowStyle Normal
} catch { Log "START_VSCODE_FAILED=`$($_.Exception.Message)" }

Start-Sleep -Seconds 8
try {
    Log "START_CODEX"
    Start-Process -FilePath "explorer.exe" -ArgumentList "shell:AppsFolder\`$CodexAppId"
} catch { Log "START_CODEX_FAILED=`$($_.Exception.Message)" }

Log "STARTUP_END"
"@

$startupBody | Set-Content -Encoding UTF8 -Path $StartupScript

$wsh = New-Object -ComObject WScript.Shell
$shortcut = $wsh.CreateShortcut($StartupShortcut)
$shortcut.TargetPath = "powershell.exe"
$shortcut.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Minimized -File `"$StartupScript`""
$shortcut.WorkingDirectory = $BridgeRoot
$shortcut.Description = "EFAB startup: Bridge + VS Code repo + Codex"
$shortcut.Save()

Write-Host "AUTOSTART_INSTALLED"
Write-Host "StartupScript=$StartupScript"
Write-Host "StartupShortcut=$StartupShortcut"
Write-Host "LogDir=$LogDir"
Write-Host "TargetRepo=$TargetRepo"
Write-Host "CodeCmd=$CodeCmd"
Write-Host "CodexAppId=$CodexAppId"
Write-Host "BridgeStartScript=$(Join-Path $BridgeRoot 'start_gpt_action_bridge_dev.ps1')"

Write-Host "--- Verify shortcut exists ---"
Get-Item -LiteralPath $StartupShortcut | Select-Object FullName,Length,LastWriteTime | Format-List

Write-Host "--- Current repo state before reboot ---"
Set-Location $TargetRepo
git status --short --branch

if ($Reboot) {
    Write-Host "SAFE_REBOOT_SCHEDULED_IN_SECONDS=$RebootDelaySeconds"
    Write-Host "No /f flag is used. Unsaved apps may block reboot. To cancel: shutdown /a"
    shutdown.exe /r /t $RebootDelaySeconds /c "EFAB safe reboot after installing startup for Bridge, VS Code, and Codex. Cancel with: shutdown /a"
} else {
    Write-Host "REBOOT_NOT_REQUESTED"
    Write-Host "To reboot safely now, run: powershell -ExecutionPolicy Bypass -File `"$Script`" -Reboot"
}


# NOTE: Current startup_after_login.ps1 has health-gated Bridge start to avoid duplicate SYSTEM/Startup port races. If regenerating this script, preserve BRIDGE_ALREADY_HEALTHY_SKIP_START behavior.

