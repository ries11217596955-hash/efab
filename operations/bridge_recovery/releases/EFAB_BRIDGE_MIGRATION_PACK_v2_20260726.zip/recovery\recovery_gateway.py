﻿from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from uuid import uuid4

VERSION = "1.0.0"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def json_bytes(data: Any) -> bytes:
    return (json.dumps(data, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")


def norm_path(value: str | None, fallback: str) -> str:
    raw = value or fallback
    return str(Path(raw).resolve())


def git_value(cwd: str, *args: str) -> str | None:
    try:
        completed = subprocess.run(
            ["git", "-C", cwd, *args],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except Exception:
        return None
    if completed.returncode != 0:
        return None
    value = completed.stdout.strip()
    return value or None


class GatewayState:
    def __init__(self, host: str, port: int, upstream: str, root: str, token: str, log_path: str) -> None:
        self.host = host
        self.port = port
        self.upstream = upstream.rstrip("/")
        self.root = str(Path(root).resolve())
        self.token = token
        self.log_path = Path(log_path)
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.Lock()

    def log(self, event: str, details: dict[str, Any]) -> None:
        record = {"timestamp": utc_now(), "event": event, **details}
        line = json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n"
        with self.lock:
            with self.log_path.open("a", encoding="utf-8") as handle:
                handle.write(line)


class RecoveryHandler(BaseHTTPRequestHandler):
    server_version = f"EFAB-Recovery-Gateway/{VERSION}"
    state: GatewayState

    def log_message(self, fmt: str, *args: Any) -> None:
        self.state.log("http", {"client": self.client_address[0], "message": fmt % args})

    def _read_body(self) -> bytes:
        length = int(self.headers.get("Content-Length", "0") or "0")
        if length < 0 or length > 10_000_000:
            raise ValueError("invalid content length")
        return self.rfile.read(length) if length else b""

    def _authorized(self) -> bool:
        supplied = self.headers.get("X-Bridge-Token", "")
        return bool(self.state.token) and supplied == self.state.token

    def _send(self, status: int, payload: Any, headers: dict[str, str] | None = None) -> None:
        body = payload if isinstance(payload, bytes) else json_bytes(payload)
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-EFAB-Recovery-Gateway", VERSION)
        for key, value in (headers or {}).items():
            if key.lower() not in {"content-length", "content-type", "transfer-encoding", "connection"}:
                self.send_header(key, value)
        self.end_headers()
        self.wfile.write(body)

    def _proxy(self, body: bytes) -> bool:
        url = self.state.upstream + self.path
        headers = {key: value for key, value in self.headers.items() if key.lower() != "host"}
        request = urllib.request.Request(url, data=body if self.command != "GET" else None, headers=headers, method=self.command)
        try:
            with urllib.request.urlopen(request, timeout=8) as response:
                payload = response.read()
                response_headers = {key: value for key, value in response.headers.items()}
                self._send(response.status, payload, response_headers)
                return True
        except urllib.error.HTTPError as exc:
            payload = exc.read()
            self._send(exc.code, payload, dict(exc.headers.items()))
            return True
        except Exception as exc:
            self.state.log("upstream_unavailable", {"path": self.path, "error": f"{type(exc).__name__}: {exc}"})
            return False

    def _fallback_health(self) -> None:
        self._send(200, {
            "ok": True,
            "service": "EFAB Recovery Gateway",
            "version": VERSION,
            "status": "recovery_mode",
            "timestamp": utc_now(),
            "capabilities": [
                {"name": "health", "status": "available", "description": "Recovery gateway health."},
                {"name": "repo_status", "status": "available", "description": "Fallback context inspection."},
                {"name": "reports", "status": "degraded", "description": "Primary Bridge unavailable."},
                {"name": "terminal_run", "status": "available", "description": "Direct audited fallback execution."},
                {"name": "managed_run_lifecycle", "status": "degraded", "description": "Synchronous fallback only."},
            ],
        })

    def _fallback_context(self, body: bytes) -> None:
        request = json.loads(body.decode("utf-8") or "{}")
        expected = norm_path(request.get("expected_root"), self.state.root)
        cwd = norm_path(request.get("cwd"), self.state.root)
        actual_root = self.state.root
        ready = os.path.normcase(expected) == os.path.normcase(actual_root)
        git_root = git_value(cwd, "rev-parse", "--show-toplevel")
        branch = git_value(cwd, "branch", "--show-current")
        head = git_value(cwd, "rev-parse", "--short", "HEAD")
        dirty_text = git_value(cwd, "status", "--porcelain") if git_root else None
        result = {
            "expected_root": expected,
            "actual_cwd": cwd,
            "actual_root": actual_root,
            "git_root": git_root,
            "branch": branch,
            "head": head,
            "dirty": bool(dirty_text) if git_root else None,
            "context_status": "READY" if ready else "CONTEXT_MISMATCH",
            "command_allowed": ready,
            "command_started": False,
            "action_taken": "checked_only",
            "root_cause": "Recovery gateway root matches expected_root." if ready else "Actual root does not match expected_root.",
            "owner_action": "No owner action required; recovery route is ready." if ready else "Open the expected root and retry.",
            "next_actions": ["Fallback command execution may proceed."] if ready else [f"Expected root: {expected}", f"Actual root: {actual_root}"],
        }
        self._send(200 if ready else 409, {"ok": ready, "result": result})

    def _fallback_terminal(self, body: bytes) -> None:
        request = json.loads(body.decode("utf-8") or "{}")
        expected = norm_path(request.get("expected_root"), self.state.root)
        cwd = norm_path(request.get("cwd"), self.state.root)
        if os.path.normcase(expected) != os.path.normcase(self.state.root):
            self._send(409, {"ok": False, "error": {"code": "CONTEXT_MISMATCH", "message": "Recovery root mismatch."}})
            return
        command = str(request.get("command") or "")
        shell = str(request.get("shell") or "powershell").lower()
        timeout = max(1, min(int(request.get("runtime_limit_seconds") or request.get("wait_timeout_seconds") or 30), 300))
        run_id = "recovery_run-" + datetime.now().strftime("%Y%m%d-%H%M%S-") + uuid4().hex[:8]
        started = time.monotonic()
        executable: list[str]
        if shell in {"cmd"}:
            executable = [r"C:\Windows\System32\cmd.exe", "/d", "/s", "/c", command]
        else:
            executable = [r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", command]
        self.state.log("fallback_terminal_start", {"run_id": run_id, "cwd": cwd, "shell": shell, "command": command})
        try:
            completed = subprocess.run(executable, cwd=cwd, capture_output=True, text=True, timeout=timeout, check=False)
            timed_out = False
            exit_code = completed.returncode
            stdout = completed.stdout
            stderr = completed.stderr
            status = "completed_success" if exit_code == 0 else "completed_failed"
        except subprocess.TimeoutExpired as exc:
            timed_out = True
            exit_code = None
            stdout = exc.stdout or ""
            stderr = exc.stderr or ""
            status = "timed_out"
        duration_ms = int((time.monotonic() - started) * 1000)
        result = {
            "run_id": run_id,
            "request_id": "recovery-" + uuid4().hex,
            "received_at": utc_now(),
            "validation_status": "validated_recovery",
            "auth_status": "authenticated",
            "authenticated": True,
            "status": status,
            "command": command,
            "cwd": cwd,
            "normalized_cwd": cwd,
            "shell": shell,
            "shell_executable": executable[0],
            "pid": None,
            "process_alive": False,
            "exit_code": exit_code,
            "timed_out": timed_out,
            "started_at": utc_now(),
            "last_seen_at": utc_now(),
            "checked_at": utc_now(),
            "finished_at": utc_now(),
            "duration_ms": duration_ms,
            "elapsed_ms": duration_ms,
            "waited_ms": duration_ms,
            "wait_elapsed_ms": duration_ms,
            "artifact_dir": None,
            "stdout_path": None,
            "stderr_path": None,
            "result_path": None,
            "report_path": str(self.state.log_path),
            "stdout_preview": stdout[-12000:],
            "stderr_preview": stderr[-12000:],
            "stdout_tail": stdout[-12000:],
            "stderr_tail": stderr[-12000:],
            "choices": ["recovery_gateway_log"],
        }
        self.state.log("fallback_terminal_finish", {"run_id": run_id, "status": status, "exit_code": exit_code, "duration_ms": duration_ms})
        self._send(200, {"ok": exit_code == 0 and not timed_out, "result": result})

    def _handle(self) -> None:
        if not self._authorized():
            self._send(401, {"ok": False, "error": {"code": "UNAUTHORIZED", "message": "Missing or invalid X-Bridge-Token."}})
            return
        try:
            body = self._read_body()
            if self._proxy(body):
                return
            if self.command == "GET" and self.path == "/health":
                self._fallback_health()
                return
            if self.command == "POST" and self.path == "/context/check":
                self._fallback_context(body)
                return
            if self.command == "POST" and self.path == "/terminal/run":
                self._fallback_terminal(body)
                return
            self._send(503, {"ok": False, "error": {"code": "PRIMARY_UNAVAILABLE", "message": "Primary Bridge unavailable and no fallback exists for this route."}})
        except Exception as exc:
            self.state.log("handler_error", {"path": self.path, "error": f"{type(exc).__name__}: {exc}"})
            self._send(500, {"ok": False, "error": {"code": "RECOVERY_HANDLER_ERROR", "message": str(exc)}})

    def do_GET(self) -> None:
        self._handle()

    def do_POST(self) -> None:
        self._handle()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=18789)
    parser.add_argument("--upstream", default="http://127.0.0.1:18787")
    parser.add_argument("--root", default=r"H:\bridge")
    parser.add_argument("--token-file", required=True)
    parser.add_argument("--log", default=r"H:\bridge\recovery_gateway_v1\recovery_gateway.jsonl")
    args = parser.parse_args()
    token = Path(args.token_file).read_text(encoding="utf-8").strip()
    if not token:
        raise SystemExit("TOKEN_EMPTY")
    state = GatewayState(args.host, args.port, args.upstream, args.root, token, args.log)
    RecoveryHandler.state = state
    server = ThreadingHTTPServer((args.host, args.port), RecoveryHandler)
    state.log("gateway_started", {"host": args.host, "port": args.port, "upstream": args.upstream, "root": state.root, "pid": os.getpid(), "version": VERSION})
    print(f"RECOVERY_GATEWAY_READY host={args.host} port={args.port} upstream={args.upstream} root={state.root}", flush=True)
    server.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
