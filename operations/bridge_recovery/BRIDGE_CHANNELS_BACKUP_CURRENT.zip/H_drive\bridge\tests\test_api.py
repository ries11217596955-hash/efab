from __future__ import annotations

import hashlib
import time
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from bridge_app.core.config import BridgeSettings
from bridge_app.core.errors import NotImplementedCapabilityError
from bridge_app.core.lifecycle import DetachedRunLifecycle
from bridge_app.core.models import CodexHandoffRequest
from bridge_app.main import create_app
from bridge_app.operations.codex import codex_handoff


@pytest.fixture
def client(tmp_path):
    settings = BridgeSettings(
        root_dir=tmp_path,
        reports_dir=tmp_path / "reports",
        runs_dir=tmp_path / "runs",
        schemas_dir=tmp_path / "schemas",
        auth_token="test-token",
    )
    app = create_app(settings)
    return TestClient(app)


@pytest.fixture
def auth_headers():
    return {"X-Bridge-Token": "test-token"}


@pytest.fixture
def bearer_headers():
    return {"Authorization": "Bearer test-token"}


def test_health_returns_structured_success(client):
    response = client.get("/health")

    assert response.status_code == 200
    body = response.json()
    assert body["ok"] is True
    assert body["service"] == "Local Bridge"
    assert body["status"] == "ok"
    capabilities = {item["name"]: item["status"] for item in body["capabilities"]}
    descriptions = {item["name"]: item["description"] for item in body["capabilities"]}
    assert capabilities["terminal_run"] == "available"
    assert "managed-run wrapper" in descriptions["terminal_run"]
    assert capabilities["managed_run_lifecycle"] == "available"
    assert "start, status, wait, logs, stop, and kill" in descriptions["managed_run_lifecycle"]
    assert capabilities["codex_handoff"] == "not_implemented"
    assert "detached_runs" not in capabilities
    assert capabilities["progress_events"] == "not_implemented"


def test_protected_endpoints_reject_missing_auth(client):
    terminal_response = client.post(
        "/terminal/run",
        json={
            "command": "python --version",
            "shell": "powershell",
            "timeout_seconds": 10,
        },
    )

    assert client.get("/repo/status").status_code == 401
    assert client.get("/reports/latest").status_code == 401
    assert terminal_response.status_code == 401
    assert client.post("/runs/start", json={"command": "python --version"}).status_code == 401
    assert client.post("/context/check", json={"expected_root": str(client.app.state.settings.root_dir)}).status_code == 401


def test_protected_endpoints_reject_bad_auth(client):
    headers = {"X-Bridge-Token": "wrong-token"}
    terminal_response = client.post(
        "/terminal/run",
        headers=headers,
        json={
            "command": "python --version",
            "shell": "powershell",
            "timeout_seconds": 10,
        },
    )

    assert client.get("/repo/status", headers=headers).status_code == 403
    assert client.get("/reports/latest", headers=headers).status_code == 403
    assert terminal_response.status_code == 403


def test_repo_status_returns_non_repo_status_for_plain_directory(client, auth_headers):
    response = client.get("/repo/status", headers=auth_headers)

    assert response.status_code == 200
    body = response.json()
    assert body["ok"] is True
    assert body["repo"]["is_git_repo"] is False
    assert body["repo"]["status"] in {"not_a_git_repo", "git_unavailable"}


def test_authorization_bearer_token_is_accepted(client, bearer_headers):
    response = client.get("/repo/status", headers=bearer_headers)

    assert response.status_code == 200


def test_reports_latest_and_by_run_id(client, auth_headers):
    latest_response = client.get("/reports/latest", headers=auth_headers)

    assert latest_response.status_code == 200
    latest = latest_response.json()["report"]
    assert latest["run_id"]

    by_id_response = client.get(f"/reports/{latest['run_id']}", headers=auth_headers)

    assert by_id_response.status_code == 200
    assert by_id_response.json()["report"]["run_id"] == latest["run_id"]


def test_report_writer_creates_report_file(client, auth_headers):
    record = client.app.state.report_store.write_report(
        report_type="test_report",
        status="ok",
        summary="Test report created by pytest.",
        details={"source": "test"},
    )

    response = client.get(f"/reports/{record.run_id}", headers=auth_headers)

    assert response.status_code == 200
    assert response.json()["report"]["run_id"] == record.run_id
    assert (client.app.state.settings.reports_dir / f"{record.run_id}.json").exists()


def test_openapi_schema_is_available(client):
    response = client.get("/openapi.json")

    assert response.status_code == 200
    schema = response.json()
    assert schema["info"]["title"] == "Local Bridge"
    assert "/health" in schema["paths"]
    assert "/context/check" in schema["paths"]
    assert "/repo/status" in schema["paths"]
    assert "/reports/latest" in schema["paths"]
    assert "/terminal/run" in schema["paths"]
    assert "/runs/start" in schema["paths"]
    assert "/runs/{run_id}/status" in schema["paths"]
    assert "/runs/{run_id}/wait" in schema["paths"]
    assert "/runs/{run_id}/logs" in schema["paths"]
    assert "/runs/{run_id}/stop" in schema["paths"]
    assert "/runs/{run_id}/kill" in schema["paths"]


def test_context_check_ready_and_mismatch_diagnostic(client, auth_headers, tmp_path):
    ready_response = client.post(
        "/context/check",
        headers=auth_headers,
        json={"expected_root": str(client.app.state.settings.root_dir)},
    )

    assert ready_response.status_code == 200
    ready = ready_response.json()["result"]
    assert ready["context_status"] == "READY"
    assert ready["command_allowed"] is True
    assert ready["command_started"] is False
    assert ready["actual_cwd"] == str(client.app.state.settings.root_dir)

    wrong_root = tmp_path / "wrong-root"
    mismatch_response = client.post(
        "/context/check",
        headers=auth_headers,
        json={"expected_root": str(wrong_root)},
    )

    assert mismatch_response.status_code == 200
    mismatch = mismatch_response.json()["result"]
    assert mismatch["context_status"] == "CONTEXT_MISMATCH"
    assert mismatch["command_allowed"] is False
    assert mismatch["command_started"] is False
    assert mismatch["expected_root"] == str(wrong_root)
    assert mismatch["actual_root"] or mismatch["actual_cwd"]
    assert "actual root does not match expected_root" in mismatch["root_cause"].lower()
    assert str(wrong_root) in mismatch["owner_action"]
    assert mismatch["next_actions"]


def test_terminal_run_expected_root_ready_executes(client, auth_headers):
    response = client.post(
        "/terminal/run",
        headers=auth_headers,
        json={
            "command": "python --version",
            "shell": "powershell",
            "expected_root": str(client.app.state.settings.root_dir),
            "wait_timeout_seconds": 10,
        },
    )

    assert response.status_code == 200
    result = response.json()["result"]
    assert result["status"] == "completed_success"
    assert result["exit_code"] == 0


def test_terminal_run_wrong_expected_root_returns_diagnostic_without_start(
    client,
    auth_headers,
    tmp_path,
):
    marker_path = tmp_path / "terminal_wrong_root_marker.txt"
    wrong_root = tmp_path / "wrong-root"
    command = (
        "python -c \"import pathlib; "
        f"pathlib.Path(r'{marker_path.as_posix()}').write_text('started', encoding='utf-8')\""
    )

    response = client.post(
        "/terminal/run",
        headers=auth_headers,
        json={
            "command": command,
            "shell": "powershell",
            "expected_root": str(wrong_root),
            "wait_timeout_seconds": 10,
        },
    )

    assert response.status_code == 409
    body = response.json()
    assert body["ok"] is False
    assert body["command_allowed"] is False
    assert body["command_started"] is False
    assert body["error"]["code"] == "CONTEXT_MISMATCH"
    assert "root_cause" in body["error"]
    assert body["error"]["expected_root"] == str(wrong_root)
    assert body["error"]["actual_root"] or body["error"]["actual_cwd"]
    assert body["error"]["owner_action"]
    assert body["error"]["next_actions"]
    assert not marker_path.exists()


def test_runs_start_wrong_expected_root_returns_diagnostic_without_start(
    client,
    auth_headers,
    tmp_path,
):
    marker_path = tmp_path / "runs_start_wrong_root_marker.txt"
    wrong_root = tmp_path / "wrong-root"
    command = (
        "python -c \"import pathlib; "
        f"pathlib.Path(r'{marker_path.as_posix()}').write_text('started', encoding='utf-8')\""
    )

    response = client.post(
        "/runs/start",
        headers=auth_headers,
        json={
            "command": command,
            "shell": "powershell",
            "expected_root": str(wrong_root),
        },
    )

    assert response.status_code == 409
    body = response.json()
    assert body["ok"] is False
    assert body["command_allowed"] is False
    assert body["command_started"] is False
    assert body["error"]["code"] == "CONTEXT_MISMATCH"
    assert body["error"]["root_cause"]
    assert body["error"]["expected_root"] == str(wrong_root)
    assert body["error"]["actual_root"] or body["error"]["actual_cwd"]
    assert body["error"]["owner_action"]
    assert body["error"]["next_actions"]
    assert not marker_path.exists()


def test_terminal_run_success_writes_artifacts_report_and_request_control(client, auth_headers):
    command = "Write-Output \"hello terminal\""
    response = client.post(
        "/terminal/run",
        headers=auth_headers,
        json={
            "command": command,
            "shell": "powershell",
            "timeout_seconds": 10,
        },
    )

    assert response.status_code == 200
    body = response.json()
    result = body["result"]
    assert body["ok"] is True
    assert result["status"] == "completed_success"
    assert result["exit_code"] == 0
    assert result["command"] == command
    assert "hello terminal" in result["stdout_preview"]
    assert Path(result["stdout_path"]).read_text(encoding="utf-8").strip() == "hello terminal"
    assert Path(result["stderr_path"]).exists()
    assert Path(result["artifact_dir"]).is_dir()
    assert result["request_id"]
    assert result["command_sha256"] == hashlib.sha256(command.encode("utf-8")).hexdigest()
    assert result["validation_status"] == "validated"
    assert result["authenticated"] is True
    assert result["request_control"]["request_id"] == result["request_id"]
    assert result["request_control"]["normalized_cwd"] == result["cwd"]
    assert result["request_control"]["shell"] == "powershell"
    assert result["request_control"]["timeout_seconds"] == 10
    assert result["process_alive"] is False

    artifact_result = Path(result["result_path"]).read_text(encoding="utf-8")
    assert '"request_control"' in artifact_result

    report_response = client.get(f"/reports/{result['run_id']}", headers=auth_headers)

    assert report_response.status_code == 200
    report = report_response.json()["report"]
    assert report["report_type"] == "terminal_run"
    assert report["details"]["terminal_run"]["run_id"] == result["run_id"]
    assert report["details"]["terminal_run"]["request_control"]["request_id"] == result["request_id"]
    assert report["details"]["request_control"]["command_sha256"] == result["command_sha256"]

    latest_response = client.get("/reports/latest", headers=auth_headers)
    latest = latest_response.json()["report"]
    assert latest["details"]["terminal_run"]["request_control"]["request_id"] == result["request_id"]


def test_terminal_run_native_python_exit_code_is_exact(client, auth_headers):
    response = client.post(
        "/terminal/run",
        headers=auth_headers,
        json={
            "command": "python -c \"import sys; sys.exit(7)\"",
            "shell": "powershell",
            "timeout_seconds": 10,
        },
    )

    assert response.status_code == 200
    result = response.json()["result"]
    assert result["status"] == "completed_failed"
    assert result["exit_code"] == 7


def test_terminal_run_native_stderr_and_exit_code_are_exact(client, auth_headers):
    response = client.post(
        "/terminal/run",
        headers=auth_headers,
        json={
            "command": "python -c \"import sys; sys.stderr.write('ERR7\\n'); sys.exit(7)\"",
            "shell": "powershell",
            "timeout_seconds": 10,
        },
    )

    assert response.status_code == 200
    result = response.json()["result"]
    stderr_text = Path(result["stderr_path"]).read_text(encoding="utf-8")
    assert result["status"] == "completed_failed"
    assert result["exit_code"] == 7
    assert "ERR7" in result["stderr_preview"]
    assert "ERR7" in stderr_text


def test_terminal_run_wait_expiry_is_still_running_and_kill_is_verified(client, auth_headers, tmp_path):
    marker_path = (tmp_path / "after_marker.txt").as_posix()
    command = (
        "python -c \"import pathlib,time; "
        "time.sleep(5); "
        f"pathlib.Path(r'{marker_path}').write_text('done', encoding='utf-8')\""
    )
    response = client.post(
        "/terminal/run",
        headers=auth_headers,
        json={
            "command": command,
            "shell": "powershell",
            "wait_timeout_seconds": 1,
        },
    )

    assert response.status_code == 200
    result = response.json()["result"]
    assert result["status"] == "wait_expired_still_running"
    assert result["process_alive"] is True
    assert result["timed_out"] is False
    assert result["exit_code"] is None
    assert result["wait_elapsed_ms"] <= 2500
    assert result["run_id"]
    assert "kill" in result["choices"]
    assert Path(result["stdout_path"]).exists()
    assert Path(result["stderr_path"]).exists()

    status_response = client.get(f"/runs/{result['run_id']}/status", headers=auth_headers)
    assert status_response.status_code == 200
    status_result = status_response.json()["result"]
    assert status_result["status"] == "running"
    assert status_result["process_alive"] is True
    assert status_result["request_control"]["request_id"] == result["request_id"]

    wait_response = client.post(
        f"/runs/{result['run_id']}/wait",
        headers=auth_headers,
        json={"wait_seconds": 1},
    )
    assert wait_response.status_code == 200
    wait_result = wait_response.json()["result"]
    assert wait_result["status"] in {"running", "wait_expired_still_running"}
    assert wait_result["process_alive"] is True
    assert wait_result["wait_elapsed_ms"] <= 2500

    logs_response = client.get(f"/runs/{result['run_id']}/logs", headers=auth_headers)
    assert logs_response.status_code == 200
    logs = logs_response.json()
    assert logs["process_alive"] is True
    assert logs["stdout_path"] == result["stdout_path"]

    kill_response = client.post(f"/runs/{result['run_id']}/kill", headers=auth_headers)
    assert kill_response.status_code == 200
    kill_result = kill_response.json()["result"]
    assert kill_result["status"] == "killed_verified"
    assert kill_result["process_alive"] is False

    time.sleep(5.5)
    assert not Path(marker_path).exists()

    latest_response = client.get("/reports/latest", headers=auth_headers)
    latest = latest_response.json()["report"]
    assert latest["details"]["terminal_run"]["request_control"]["request_id"] == result["request_id"]


def test_runs_start_target_can_be_killed_before_marker_write(client, auth_headers, tmp_path):
    marker_path = (tmp_path / "runs_start_after_marker.txt").as_posix()
    command = (
        "python -c \"import pathlib,time; "
        "time.sleep(5); "
        f"pathlib.Path(r'{marker_path}').write_text('done', encoding='utf-8')\""
    )
    start_response = client.post(
        "/runs/start",
        headers=auth_headers,
        json={
            "command": command,
            "shell": "powershell",
            "wait_timeout_seconds": 1,
        },
    )

    assert start_response.status_code == 200
    start_result = start_response.json()["result"]
    assert start_result["status"] == "running"
    assert start_result["process_alive"] is True

    kill_response = client.post(f"/runs/{start_result['run_id']}/kill", headers=auth_headers)
    assert kill_response.status_code == 200
    kill_result = kill_response.json()["result"]
    assert kill_result["status"] == "killed_verified"
    assert kill_result["process_alive"] is False

    status_response = client.get(f"/runs/{start_result['run_id']}/status", headers=auth_headers)
    assert status_response.status_code == 200
    status_result = status_response.json()["result"]
    assert status_result["process_alive"] is False

    time.sleep(5.5)
    assert not Path(marker_path).exists()


def test_terminal_run_invalid_cwd_fails_clearly(client, auth_headers):
    missing_cwd = client.app.state.settings.root_dir / "missing"

    response = client.post(
        "/terminal/run",
        headers=auth_headers,
        json={
            "command": "Write-Output \"should not run\"",
            "shell": "powershell",
            "cwd": str(missing_cwd),
            "timeout_seconds": 10,
        },
    )

    assert response.status_code == 400
    body = response.json()
    assert body["ok"] is False
    assert body["error"]["code"] == "INVALID_CWD"
    assert body["error"]["details"]["cwd"] == str(missing_cwd)


def test_future_codex_handoff_is_not_implemented():
    with pytest.raises(NotImplementedCapabilityError) as exc_info:
        codex_handoff(CodexHandoffRequest(task_path="codex_tasks/example.md"))

    assert exc_info.value.code == "NOT_IMPLEMENTED"


def test_future_detached_runs_are_not_implemented():
    with pytest.raises(NotImplementedCapabilityError) as exc_info:
        DetachedRunLifecycle().start("Write-Output later")

    assert exc_info.value.code == "NOT_IMPLEMENTED"
