from __future__ import annotations

from pathlib import Path
import json
import subprocess

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from bridge_app.core.auth import AuthContext, require_auth


router = APIRouter(prefix="/codex", tags=["codex"])


class CodexRunnerV01Request(BaseModel):
    repo_root: str = Field(min_length=1)
    allowed_output: list[str] = Field(min_length=1)
    task_text: str | None = Field(default=None, min_length=1)
    task_file: str | None = Field(default=None, min_length=1)
    mode: str = Field(default="bypass", pattern="^(workspace-write|read-only|bypass)$")
    timeout_sec: int = Field(default=180, ge=1, le=86400)
    wait_timeout_seconds: int = Field(default=30, ge=0, le=300)
    runtime_limit_seconds: int | None = Field(default=None, ge=1, le=86400)
    require_clean_allowed_outputs: bool = False
    request_id: str | None = None


@router.post("/runner/v0_1")
def run_codex_runner_v0_1(
    request_body: CodexRunnerV01Request,
    request: Request,
    auth_context: AuthContext = Depends(require_auth),
) -> dict:
    bridge_root = _bridge_root()
    task = _resolve_task_text(request_body)
    handoff = bridge_root / "codex_handoff_v1.ps1"
    if not handoff.is_file():
        raise HTTPException(status_code=503, detail={"status": "CODEX_HANDOFF_MISSING", "path": str(handoff)})
    repo_root = Path(request_body.repo_root).resolve()
    if not repo_root.is_dir():
        raise HTTPException(status_code=400, detail={"status": "INVALID_REPO_ROOT", "path": str(repo_root)})
    cmd = ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", str(handoff), "-RepoRoot", str(repo_root), "-TaskText", task, "-RuntimeLimitSeconds", str(request_body.runtime_limit_seconds or 21600)]
    for rel in request_body.allowed_output:
        cmd += ["-AllowedOutput", rel]
    proc = subprocess.run(cmd, cwd=str(bridge_root), capture_output=True, text=True, timeout=8, check=False)
    if proc.returncode != 0:
        raise HTTPException(status_code=500, detail={"status": "CODEX_HANDOFF_START_FAILED", "exit_code": proc.returncode, "stderr": proc.stderr[-2000:]})
    try:
        launch = json.loads(proc.stdout.strip().splitlines()[-1])
    except Exception as exc:
        raise HTTPException(status_code=500, detail={"status": "CODEX_HANDOFF_BAD_RESPONSE", "stdout": proc.stdout[-2000:]}) from exc
    return {"ok": True, "status": "STARTED", "run_id": launch["run_id"], "report_path": launch["report_path"], "run_dir": launch["run_dir"], "repo_root": launch["repo_root"]}


def _bridge_root() -> Path:
    # H:\bridge\src\bridge_app\api\routes\codex.py -> H:\bridge
    return Path(__file__).resolve().parents[4]


def _resolve_task_text(request_body: CodexRunnerV01Request) -> str:
    if bool(request_body.task_text) == bool(request_body.task_file):
        raise HTTPException(status_code=400, detail="Provide exactly one of task_text or task_file.")
    if request_body.task_file:
        task_path = Path(request_body.task_file).resolve()
        if not task_path.is_file():
            raise HTTPException(status_code=400, detail={"status": "INVALID_TASK_FILE", "path": str(task_path)})
        return task_path.read_text(encoding="utf-8")
    return request_body.task_text or ""

