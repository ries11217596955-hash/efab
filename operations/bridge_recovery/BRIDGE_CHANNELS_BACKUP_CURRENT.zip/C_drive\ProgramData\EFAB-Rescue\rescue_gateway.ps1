param(
    [int]$Port = 18789
)

$ErrorActionPreference = 'Stop'
$Root = 'C:\ProgramData\EFAB-Rescue'
$TokenPath = Join-Path $Root 'rescue_token.txt'
$LogPath = Join-Path $Root 'rescue.log'
$ProofRoot = Join-Path $Root 'proofs'
$RequestRoot = Join-Path $Root 'requests'
$PrimaryTask = 'EFAB Bridge Boot SYSTEM'
$PrimaryPort = 18788
$RecoveryPort = 18787
$RescuePort = $Port
$PrimaryTokenPath = 'H:\bridge\recovery_gateway_v1\bridge_token.txt'
$RestartWorker = Join-Path $Root 'primary_restart_worker.ps1'
$Version = '2.1.0'

New-Item -ItemType Directory -Force -Path $Root, $ProofRoot, $RequestRoot | Out-Null

function Write-RescueLog {
    param([string]$Event, [hashtable]$Data = @{})
    $row = [ordered]@{
        ts = (Get-Date).ToUniversalTime().ToString('o')
        event = $Event
        data = $Data
    }
    Add-Content -LiteralPath $LogPath -Value ($row | ConvertTo-Json -Compress -Depth 8) -Encoding UTF8
}

function Write-Json {
    param($Context, [int]$Status, $Object)
    $json = $Object | ConvertTo-Json -Compress -Depth 16
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $Context.Response.StatusCode = $Status
    $Context.Response.ContentType = 'application/json'
    $Context.Response.ContentEncoding = [Text.Encoding]::UTF8
    $Context.Response.ContentLength64 = $bytes.Length
    $Context.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $Context.Response.Close()
}

function Read-JsonBody {
    param($Request)
    $reader = [IO.StreamReader]::new($Request.InputStream, $Request.ContentEncoding)
    try {
        $text = $reader.ReadToEnd()
    }
    finally {
        $reader.Dispose()
    }
    if ([string]::IsNullOrWhiteSpace($text)) {
        return [pscustomobject]@{}
    }
    return ($text | ConvertFrom-Json)
}

function Test-SecureEquals {
    param([string]$A, [string]$B)
    if ($null -eq $A -or $null -eq $B) { return $false }
    $ab = [Text.Encoding]::UTF8.GetBytes($A)
    $bb = [Text.Encoding]::UTF8.GetBytes($B)
    if ($ab.Length -ne $bb.Length) { return $false }
    $diff = 0
    for ($i = 0; $i -lt $ab.Length; $i++) {
        $diff = $diff -bor ($ab[$i] -bxor $bb[$i])
    }
    return ($diff -eq 0)
}

function Test-Authorized {
    param($Request)
    if (-not (Test-Path -LiteralPath $TokenPath)) { return $false }
    $expected = (Get-Content -LiteralPath $TokenPath -Raw).Trim()
    $custom = $Request.Headers['X-Rescue-Token']
    $authorization = $Request.Headers['Authorization']
    $bearer = $null
    if ($authorization -and $authorization.StartsWith('Bearer ', [StringComparison]::OrdinalIgnoreCase)) {
        $bearer = $authorization.Substring(7).Trim()
    }
    return (Test-SecureEquals $expected $custom) -or (Test-SecureEquals $expected $bearer)
}

function Get-ProcessRecord {
    param([int]$ProcessId)
    if ($ProcessId -le 0) { return $null }
    $p = Get-CimInstance Win32_Process -Filter "ProcessId=$ProcessId" -ErrorAction SilentlyContinue
    if (-not $p) { return $null }
    return [ordered]@{
        pid = [int]$p.ProcessId
        parent_pid = [int]$p.ParentProcessId
        name = [string]$p.Name
        command_line = [string]$p.CommandLine
        creation_date = if ($p.CreationDate) { ([datetime]$p.CreationDate).ToUniversalTime().ToString('o') } else { $null }
    }
}

function Get-ListenerRecord {
    param([int]$LocalPort)
    $listener = Get-NetTCPConnection -State Listen -LocalPort $LocalPort -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $listener) {
        return [ordered]@{ listening = $false; port = $LocalPort; pid = $null; process = $null }
    }
    return [ordered]@{
        listening = $true
        port = $LocalPort
        pid = [int]$listener.OwningProcess
        process = (Get-ProcessRecord -ProcessId ([int]$listener.OwningProcess))
    }
}

function Get-TaskRecord {
    param([string]$TaskName)
    $task = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    $info = if ($task) { $task | Get-ScheduledTaskInfo } else { $null }
    return [ordered]@{
        exists = [bool]$task
        state = if ($task) { [string]$task.State } else { $null }
        last_run = if ($info -and $info.LastRunTime.Year -gt 2000) { $info.LastRunTime.ToUniversalTime().ToString('o') } else { $null }
        last_result = if ($info) { [int64]$info.LastTaskResult } else { $null }
        next_run = if ($info -and $info.NextRunTime.Year -gt 2000) { $info.NextRunTime.ToUniversalTime().ToString('o') } else { $null }
        actions = if ($task) { @($task.Actions | ForEach-Object { [ordered]@{ execute = $_.Execute; arguments = $_.Arguments; working_directory = $_.WorkingDirectory } }) } else { @() }
    }
}

function Invoke-PrimaryRequest {
    param(
        [string]$Path,
        [ValidateSet('GET','POST')][string]$Method = 'GET',
        $Body = $null,
        [int]$TimeoutSeconds = 6
    )
    $headers = @{}
    if (Test-Path -LiteralPath $PrimaryTokenPath) {
        $token = (Get-Content -LiteralPath $PrimaryTokenPath -Raw).Trim()
        if ($token) { $headers['X-Bridge-Token'] = $token }
    }
    $uri = "http://127.0.0.1:$PrimaryPort$Path"
    try {
        if ($Method -eq 'POST') {
            $payload = if ($null -eq $Body) { '{}' } else { $Body | ConvertTo-Json -Compress -Depth 8 }
            $response = Invoke-RestMethod -Uri $uri -Method Post -Headers $headers -ContentType 'application/json' -Body $payload -TimeoutSec $TimeoutSeconds
        }
        else {
            $response = Invoke-RestMethod -Uri $uri -Headers $headers -TimeoutSec $TimeoutSeconds
        }
        return [ordered]@{ ok = $true; uri = $uri; response = $response; error = $null }
    }
    catch {
        $status = $null
        try { $status = [int]$_.Exception.Response.StatusCode } catch {}
        $bodyText = $null
        try {
            $stream = $_.Exception.Response.GetResponseStream()
            if ($stream) {
                $reader = [IO.StreamReader]::new($stream)
                try { $bodyText = $reader.ReadToEnd() } finally { $reader.Dispose() }
            }
        }
        catch {}
        return [ordered]@{
            ok = $false
            uri = $uri
            status_code = $status
            error = $_.Exception.Message
            response_body = $bodyText
        }
    }
}

function Get-PrimaryInspection {
    $listener = Get-ListenerRecord -LocalPort $PrimaryPort
    $parent = $null
    $children = @()
    if ($listener.listening -and $listener.process) {
        $parent = Get-ProcessRecord -ProcessId ([int]$listener.process.parent_pid)
        $children = @(Get-CimInstance Win32_Process -Filter "ParentProcessId=$($listener.pid)" -ErrorAction SilentlyContinue | ForEach-Object {
            Get-ProcessRecord -ProcessId ([int]$_.ProcessId)
        })
    }
    $health = Invoke-PrimaryRequest -Path '/health' -Method GET -TimeoutSeconds 5
    return [ordered]@{
        listener = $listener
        parent = $parent
        children = $children
        task = (Get-TaskRecord -TaskName $PrimaryTask)
        direct_health = $health
        ready = [bool]($listener.listening -and $health.ok)
        timestamp = (Get-Date).ToUniversalTime().ToString('o')
    }
}

function Get-BridgePorts {
    $ports = @(18787, 18788, 18789, 4040)
    return @($ports | ForEach-Object { Get-ListenerRecord -LocalPort $_ })
}

function Get-StoreRoots {
    return @(
        'H:\bridge\runs',
        'H:\bridge\reports',
        'H:\bridge\logs',
        'H:\bridge\.runtime',
        'C:\ProgramData\EFAB-Primary'
    )
}

function Read-BoundedTail {
    param([string]$Path, [int]$MaxBytes = 8192)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return '' }
    $stream = $null
    try {
        $stream = [IO.File]::Open($Path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
        $count = [Math]::Min([int64]$MaxBytes, $stream.Length)
        if ($count -le 0) { return '' }
        $null = $stream.Seek(-$count, [IO.SeekOrigin]::End)
        $buffer = New-Object byte[] $count
        $read = $stream.Read($buffer, 0, $count)
        return [Text.Encoding]::UTF8.GetString($buffer, 0, $read)
    }
    catch {
        return ''
    }
    finally {
        if ($stream) { $stream.Dispose() }
    }
}

function Redact-Text {
    param([string]$Text)
    if ($null -eq $Text) { return '' }
    $value = $Text
    $value = [regex]::Replace($value, '(?i)(Authorization\s*:\s*Bearer\s+)[A-Za-z0-9._~+/=-]+', '$1[REDACTED]')
    $value = [regex]::Replace($value, '(?i)(X-(?:Bridge|Rescue)-Token["'']?\s*[:=]\s*)[^,\s}"'']+', '$1[REDACTED]')
    return $value
}

function Get-RunStoreSummary {
    $rows = @()
    foreach ($rootPath in Get-StoreRoots) {
        $exists = Test-Path -LiteralPath $rootPath -PathType Container
        $readable = $false
        $count = 0
        $truncated = $false
        $latest = @()
        if ($exists) {
            try {
                $files = @(Get-ChildItem -LiteralPath $rootPath -Recurse -File -ErrorAction Stop | Select-Object -First 1001)
                $readable = $true
                $truncated = ($files.Count -gt 1000)
                $count = [Math]::Min($files.Count, 1000)
                $latest = @($files | Sort-Object LastWriteTime -Descending | Select-Object -First 8 | ForEach-Object {
                    [ordered]@{
                        path = $_.FullName
                        size = [int64]$_.Length
                        last_write = $_.LastWriteTimeUtc.ToString('o')
                    }
                })
            }
            catch {
                $readable = $false
            }
        }
        $rows += [ordered]@{
            path = $rootPath
            exists = $exists
            readable = $readable
            sampled_file_count = $count
            truncated_at_1000 = $truncated
            latest = $latest
        }
    }
    return $rows
}

function Assert-RunId {
    param([string]$RunId)
    if ([string]::IsNullOrWhiteSpace($RunId) -or $RunId -notmatch '^[A-Za-z0-9._-]{1,160}$') {
        throw 'INVALID_RUN_ID'
    }
}

function Inspect-ManagedRun {
    param([string]$RunId)
    Assert-RunId -RunId $RunId
    $files = @()
    foreach ($rootPath in Get-StoreRoots) {
        if (-not (Test-Path -LiteralPath $rootPath -PathType Container)) { continue }
        try {
            $files += @(Get-ChildItem -LiteralPath $rootPath -Recurse -File -Filter "*$RunId*" -ErrorAction SilentlyContinue | Select-Object -First 100)
        }
        catch {}
    }
    $files = @($files | Sort-Object FullName -Unique | Select-Object -First 100)
    $fileEvidence = @($files | ForEach-Object {
        $tail = Redact-Text -Text (Read-BoundedTail -Path $_.FullName -MaxBytes 8192)
        [ordered]@{
            path = $_.FullName
            size = [int64]$_.Length
            last_write = $_.LastWriteTimeUtc.ToString('o')
            tail = $tail
        }
    })
    $processes = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
        ([string]$_.CommandLine).Contains($RunId)
    } | ForEach-Object { Get-ProcessRecord -ProcessId ([int]$_.ProcessId) })

    $combined = ($fileEvidence | ForEach-Object { $_.tail }) -join "`n"
    $state = 'unknown'
    if ($processes.Count -gt 0) {
        $state = 'running'
    }
    elseif ($combined -match '(?i)completed_success|"status"\s*:\s*"completed"|exit_code"\s*:\s*0') {
        $state = 'completed'
    }
    elseif ($combined -match '(?i)completed_failed|"status"\s*:\s*"failed"|exit_code"\s*:\s*[1-9]') {
        $state = 'failed'
    }
    elseif ($fileEvidence.Count -gt 0) {
        $newest = ($files | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1).LastWriteTimeUtc
        if ($newest -and ((Get-Date).ToUniversalTime() - $newest).TotalSeconds -gt 120) {
            $state = 'orphaned_candidate'
        }
    }

    $recoveryAction = switch ($state) {
        'running' { 'Do not start a duplicate run. Observe process and logs.' }
        'completed' { 'Preserve proof and reconcile Primary registry response.' }
        'failed' { 'Read bounded logs and preserve failure proof before retry.' }
        'orphaned_candidate' { 'Treat as orphan candidate; inspect registry/logs before controlled Primary restart.' }
        default { 'Run evidence is incomplete; inspect store and Primary logs.' }
    }

    return [ordered]@{
        run_id = $RunId
        derived_state = $state
        process_alive = ($processes.Count -gt 0)
        processes = $processes
        files = $fileEvidence
        file_count = $fileEvidence.Count
        recovery_action = $recoveryAction
        timestamp = (Get-Date).ToUniversalTime().ToString('o')
    }
}

function Get-PrimaryLogs {
    param([string]$RunId = '', [int]$Tail = 100)
    if ($Tail -lt 1) { $Tail = 1 }
    if ($Tail -gt 300) { $Tail = 300 }
    if ($RunId) { Assert-RunId -RunId $RunId }

    $roots = @(
        'C:\ProgramData\EFAB-Primary',
        'H:\bridge\logs',
        'H:\bridge\recovery_gateway_v1\logs',
        'H:\bridge\runs',
        'H:\bridge\reports'
    )
    $all = @()
    foreach ($rootPath in $roots) {
        if (-not (Test-Path -LiteralPath $rootPath -PathType Container)) { continue }
        try {
            $all += @(Get-ChildItem -LiteralPath $rootPath -Recurse -File -ErrorAction SilentlyContinue |
                Where-Object { $_.Extension -in @('.log','.json','.jsonl','.txt','.out','.err') } |
                Sort-Object LastWriteTime -Descending |
                Select-Object -First 80)
        }
        catch {}
    }
    $all = @($all | Sort-Object FullName -Unique | Sort-Object LastWriteTime -Descending | Select-Object -First 120)
    if ($RunId) {
        $all = @($all | Where-Object {
            $_.FullName -like "*$RunId*" -or (Read-BoundedTail -Path $_.FullName -MaxBytes 32768) -like "*$RunId*"
        } | Select-Object -First 30)
    }
    else {
        $all = @($all | Select-Object -First 20)
    }

    return @($all | ForEach-Object {
        $lines = @(Get-Content -LiteralPath $_.FullName -Tail $Tail -ErrorAction SilentlyContinue)
        [ordered]@{
            path = $_.FullName
            size = [int64]$_.Length
            last_write = $_.LastWriteTimeUtc.ToString('o')
            lines = @($lines | ForEach-Object { Redact-Text -Text ([string]$_) })
        }
    })
}


function Invoke-BoundedTextRepair {
    param($Body)

    if ([string]$Body.confirm -ne 'BOUNDED_REPAIR') { throw 'REPAIR_CONFIRMATION_REQUIRED' }
    $target = [string]$Body.target_path
    $expectedHash = ([string]$Body.expected_sha256).ToUpperInvariant()
    $anchor = [string]$Body.anchor
    $replacement = [string]$Body.replacement
    $validator = [string]$Body.validator
    if ([string]::IsNullOrWhiteSpace($validator)) { $validator = 'none' }

    if ([string]::IsNullOrWhiteSpace($target)) { throw 'REPAIR_TARGET_REQUIRED' }
    if ($expectedHash -notmatch '^[A-F0-9]{64}$') { throw 'REPAIR_HASH_REQUIRED' }
    if ([string]::IsNullOrEmpty($anchor)) { throw 'REPAIR_ANCHOR_REQUIRED' }
    if ($anchor.Length -gt 65536 -or $replacement.Length -gt 65536) { throw 'REPAIR_PAYLOAD_TOO_LARGE' }
    if ($validator -notin @('none','json','powershell')) { throw 'REPAIR_VALIDATOR_INVALID' }

    $full = [IO.Path]::GetFullPath($target)
    $allowed = @(
        ([IO.Path]::GetFullPath('H:\bridge') + [IO.Path]::DirectorySeparatorChar)
        ([IO.Path]::GetFullPath('C:\ProgramData\EFAB-Rescue') + [IO.Path]::DirectorySeparatorChar)
    )
    $inside = $false
    foreach ($prefix in $allowed) {
        if ($full.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { $inside = $true; break }
    }
    if (-not $inside) { throw 'REPAIR_TARGET_OUTSIDE_ALLOWLIST' }
    if (-not (Test-Path -LiteralPath $full -PathType Leaf)) { throw 'REPAIR_TARGET_MISSING' }

    $item = Get-Item -LiteralPath $full
    if ($item.Length -gt 2MB) { throw 'REPAIR_FILE_TOO_LARGE' }
    $actualHash = (Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash.ToUpperInvariant()
    if ($actualHash -ne $expectedHash) { throw 'REPAIR_HASH_MISMATCH' }

    $text = Get-Content -LiteralPath $full -Raw
    $count = ([regex]::Matches($text, [regex]::Escape($anchor))).Count
    if ($count -ne 1) { throw "REPAIR_ANCHOR_COUNT_$count" }

    $operationId = 'bounded_repair_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '_' + ([guid]::NewGuid().ToString('N').Substring(0,8))
    $backupRoot = Join-Path $Root 'backups\bounded_repair'
    New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
    $backup = Join-Path $backupRoot ($operationId + '_' + [IO.Path]::GetFileName($full) + '.bak')
    $temp = $full + '.repair_tmp_' + $operationId
    Copy-Item -LiteralPath $full -Destination $backup -Force

    $proof = [ordered]@{
        schema = 'bounded_text_repair_v1'
        operation_id = $operationId
        status = 'STARTED'
        target_path = $full
        validator = $validator
        hash_before = $actualHash
        backup_path = $backup
        started_at = (Get-Date).ToUniversalTime().ToString('o')
    }
    $proofPath = Join-Path $ProofRoot ($operationId + '.json')
    $proof | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $proofPath -Encoding UTF8

    try {
        $newText = $text.Replace($anchor, $replacement)
        [IO.File]::WriteAllText($temp, $newText, [Text.UTF8Encoding]::new($false))

        if ($validator -eq 'json') {
            Get-Content -LiteralPath $temp -Raw | ConvertFrom-Json | Out-Null
        }
        elseif ($validator -eq 'powershell') {
            $tokens = $null; $errors = $null
            [System.Management.Automation.Language.Parser]::ParseFile($temp, [ref]$tokens, [ref]$errors) | Out-Null
            if ($errors.Count -gt 0) { throw ('REPAIR_VALIDATOR_FAILED: ' + (($errors | ForEach-Object Message) -join '; ')) }
        }

        Move-Item -LiteralPath $temp -Destination $full -Force
        $hashAfter = (Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash.ToUpperInvariant()
        $proof.status = 'PROVEN_LIVE_BOUNDED_REPAIR'
        $proof.hash_after = $hashAfter
        $proof.finished_at = (Get-Date).ToUniversalTime().ToString('o')
        $proof | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $proofPath -Encoding UTF8
        Write-RescueLog -Event 'bounded_repair_completed' -Data @{ operation_id = $operationId; target_path = $full; validator = $validator }
        return [pscustomobject]@{ operation_id=$operationId; status=$proof.status; target_path=$full; hash_before=$actualHash; hash_after=$hashAfter; backup_path=$backup; proof_path=$proofPath }
    }
    catch {
        if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue }
        Copy-Item -LiteralPath $backup -Destination $full -Force
        $proof.status = 'ROLLED_BACK'
        $proof.error = $_.Exception.Message
        $proof.finished_at = (Get-Date).ToUniversalTime().ToString('o')
        $proof | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $proofPath -Encoding UTF8
        throw
    }
}

function Invoke-ControlledComponentRecovery {
    param($Body)
    $confirm = [string]$Body.confirm
    $component = ([string]$Body.component).ToLowerInvariant()
    if ($confirm -ne 'RECOVER_COMPONENT') { throw 'CONFIRMATION_REQUIRED' }
    $allowed = @('pc_control','ngrok','tailscale_funnel')
    if ($component -notin $allowed) { throw 'INVALID_COMPONENT' }
    $before = [ordered]@{ component=$component; checked_at=(Get-Date).ToUniversalTime().ToString('o') }
    switch ($component) {
        'pc_control' {
            $task='EFAB PC Control SYSTEM'; $before.task=[string](Get-ScheduledTask -TaskName $task -ErrorAction Stop).State
            Start-ScheduledTask -TaskName $task; Start-Sleep -Seconds 4
            $tok=(Get-Content -LiteralPath $TokenPath -Raw).Trim()
            $h=Invoke-RestMethod 'http://127.0.0.1:18790/health' -Headers @{'X-Rescue-Token'=$tok} -TimeoutSec 5
            return [pscustomobject]@{component=$component;recovered=[bool]$h.ok;task=[string](Get-ScheduledTask -TaskName $task).State;health=$h;before=$before}
        }
        'ngrok' {
            $task='EFAB Ngrok Primary SYSTEM'; $before.task=[string](Get-ScheduledTask -TaskName $task -ErrorAction Stop).State
            Start-ScheduledTask -TaskName $task; Start-Sleep -Seconds 6
            $t=Invoke-RestMethod 'http://127.0.0.1:4040/api/tunnels' -TimeoutSec 5
            return [pscustomobject]@{component=$component;recovered=(@($t.tunnels).Count -gt 0);task=[string](Get-ScheduledTask -TaskName $task).State;tunnel_count=@($t.tunnels).Count;before=$before}
        }
        'tailscale_funnel' {
            $before.status=(& tailscale funnel status 2>&1 | Out-String)
            & tailscale funnel --bg --https=443 --set-path=/ http://127.0.0.1:18789 | Out-Null
            & tailscale funnel --bg --https=443 --set-path=/pc-control http://127.0.0.1:18790 | Out-Null
            $after=(& tailscale funnel status 2>&1 | Out-String)
            $ok=($after -match '127\.0\.0\.1:18789' -and $after -match '127\.0\.0\.1:18790')
            return [pscustomobject]@{component=$component;recovered=$ok;status=$after;before=$before}
        }
    }
}
function Test-ChannelRecoveryState {
    $token=(Get-Content -LiteralPath $TokenPath -Raw).Trim()
    $primary=$false; $pc=$false; $ngrok=$false; $funnel=$false
    try { $h=Invoke-RestMethod 'http://127.0.0.1:18788/health' -TimeoutSec 5; $primary=[bool]$h.ok } catch {}
    try { $h=Invoke-RestMethod 'http://127.0.0.1:18790/health' -Headers @{'X-Rescue-Token'=$token} -TimeoutSec 5; $pc=[bool]$h.ok } catch {}
    try { $t=Invoke-RestMethod 'http://127.0.0.1:4040/api/tunnels' -TimeoutSec 5; $ngrok=(@($t.tunnels).Count -gt 0) } catch {}
    try { $s=(& tailscale funnel status 2>&1 | Out-String); $funnel=($s -match '127\.0\.0\.1:18789' -and $s -match '127\.0\.0\.1:18790') } catch { $s=$_.Exception.Message }
    return [ordered]@{primary=$primary;pc_control=$pc;ngrok=$ngrok;tailscale_funnel=$funnel;checked_at=(Get-Date).ToUniversalTime().ToString('o')}
}

function Invoke-ReconcileAllChannels {
    param($Body)
    if ([string]$Body.confirm -ne 'RECONCILE_ALL_CHANNELS') { throw 'CONFIRMATION_REQUIRED' }
    $before=Test-ChannelRecoveryState
    $actions=@()
    if (-not $before.primary) {
        $task='EFAB Recovery Gateway SYSTEM'
        Start-ScheduledTask -TaskName $task -ErrorAction Stop; Start-Sleep -Seconds 8
        $h=Invoke-RestMethod 'http://127.0.0.1:18788/health' -TimeoutSec 5
        $actions += [pscustomobject]@{component='primary';action='start_task';recovered=[bool]$h.ok;task=[string](Get-ScheduledTask -TaskName $task).State}
    }
    if (-not $before.pc_control) { $r=Invoke-ControlledComponentRecovery -Body ([pscustomobject]@{confirm='RECOVER_COMPONENT';component='pc_control'}); $actions += $r }
    if (-not $before.ngrok) { $r=Invoke-ControlledComponentRecovery -Body ([pscustomobject]@{confirm='RECOVER_COMPONENT';component='ngrok'}); $actions += $r }
    if (-not $before.tailscale_funnel) { $r=Invoke-ControlledComponentRecovery -Body ([pscustomobject]@{confirm='RECOVER_COMPONENT';component='tailscale_funnel'}); $actions += $r }
    $after=Test-ChannelRecoveryState
    $ok=([bool]$after.primary -and [bool]$after.pc_control -and [bool]$after.ngrok -and [bool]$after.tailscale_funnel)
    return [pscustomobject]@{reconciled=$ok;before=$before;actions=@($actions);actions_count=@($actions).Count;after=$after;finished_at=(Get-Date).ToUniversalTime().ToString('o')}
}
function Start-ControlledPrimaryRestart {
    param($Body)
    $confirm = [string]$Body.confirm
    $reason = [string]$Body.reason
    if ($confirm -ne 'RESTART_PRIMARY') {
        throw 'CONFIRMATION_REQUIRED'
    }
    if ([string]::IsNullOrWhiteSpace($reason)) {
        throw 'REASON_REQUIRED'
    }
    if ($reason.Length -gt 240) {
        throw 'REASON_TOO_LONG'
    }
    if (-not (Test-Path -LiteralPath $RestartWorker -PathType Leaf)) {
        throw 'RESTART_WORKER_MISSING'
    }
    $active = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
        ([string]$_.CommandLine) -like '*primary_restart_worker.ps1*'
    })
    if ($active.Count -gt 0) {
        throw 'RESTART_ALREADY_RUNNING'
    }

    $operationId = 'rescue_restart_{0}_{1}' -f (Get-Date).ToUniversalTime().ToString('yyyyMMdd_HHmmss'), ([guid]::NewGuid().ToString('N').Substring(0,8))
    $requestPath = Join-Path $RequestRoot "$operationId.json"
    $request = [ordered]@{
        operation_id = $operationId
        confirm = $confirm
        reason = $reason
        requested_at = (Get-Date).ToUniversalTime().ToString('o')
    }
    $request | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $requestPath -Encoding UTF8

    $worker = Start-Process powershell.exe -ArgumentList @(
        '-NoProfile',
        '-NonInteractive',
        '-ExecutionPolicy', 'Bypass',
        '-File', ('"{0}"' -f $RestartWorker),
        '-OperationId', $operationId
    ) -WindowStyle Hidden -PassThru

    Write-RescueLog -Event 'controlled_primary_restart_accepted' -Data @{
        operation_id = $operationId
        worker_pid = $worker.Id
        reason = $reason
    }

    return [ordered]@{
        accepted = $true
        operation_id = $operationId
        worker_pid = [int]$worker.Id
        proof_route = "/proofs/$operationId"
    }
}

function Get-RecoveryProof {
    param([string]$OperationId)
    if ($OperationId -notmatch '^(rescue_restart|bounded_repair)_[A-Za-z0-9_]{10,100}$') {
        throw 'INVALID_OPERATION_ID'
    }
    $proofPath = Join-Path $ProofRoot "$OperationId.json"
    $requestPath = Join-Path $RequestRoot "$OperationId.json"
    if (Test-Path -LiteralPath $proofPath) {
        return [ordered]@{ found = $true; state = 'proof'; proof = (Get-Content -LiteralPath $proofPath -Raw | ConvertFrom-Json) }
    }
    if (Test-Path -LiteralPath $requestPath) {
        return [ordered]@{ found = $true; state = 'pending'; request = (Get-Content -LiteralPath $requestPath -Raw | ConvertFrom-Json) }
    }
    return [ordered]@{ found = $false; state = 'not_found' }
}

function Get-LatestRecoveryProof {
    $file = Get-ChildItem -LiteralPath $ProofRoot -File -Filter '*.json' -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (-not $file) { return [ordered]@{ found = $false } }
    return [ordered]@{
        found = $true
        path = $file.FullName
        proof = (Get-Content -LiteralPath $file.FullName -Raw | ConvertFrom-Json)
    }
}

$listener = [Net.HttpListener]::new()
$listener.Prefixes.Add("http://127.0.0.1:$Port/")
$listener.Start()
Write-RescueLog -Event 'rescue_started' -Data @{ port = $Port; pid = $PID; version = $Version }

try {
    while ($listener.IsListening) {
        $ctx = $listener.GetContext()
        $path = $ctx.Request.Url.AbsolutePath
        $method = $ctx.Request.HttpMethod.ToUpperInvariant()
        try {
            if (-not (Test-Authorized -Request $ctx.Request)) {
                Write-RescueLog -Event 'unauthorized' -Data @{ path = $path; remote = [string]$ctx.Request.RemoteEndPoint }
                Write-Json -Context $ctx -Status 401 -Object @{ ok = $false; error = @{ code = 'UNAUTHORIZED'; message = 'Missing or invalid X-Rescue-Token.' } }
                continue
            }

            if ($method -eq 'GET' -and $path -eq '/health') {
                $primary = Get-PrimaryInspection
                $storeRoots = @(Get-StoreRoots | Where-Object { Test-Path -LiteralPath $_ -PathType Container })
                $grade = if ($primary.ready) { 'READY' } elseif ($primary.listener.listening) { 'DEGRADED' } else { 'PRIMARY_DOWN' }
                Write-Json -Context $ctx -Status 200 -Object @{
                    ok = $true
                    result = @{
                        service = 'efab-rescue'
                        version = $Version
                        pid = $PID
                        port = $Port
                        machine = $env:COMPUTERNAME
                        rescue_ready = $true
                        primary_grade = $grade
                        primary_listener = [bool]$primary.listener.listening
                        primary_http_health = [bool]$primary.direct_health.ok
                        primary_task_exists = [bool]$primary.task.exists
                        managed_run_store_roots_found = $storeRoots.Count
                        proof_store_exists = (Test-Path -LiteralPath $ProofRoot -PathType Container)
                        timestamp = (Get-Date).ToUniversalTime().ToString('o')
                    }
                }
                continue
            }

            if ($method -eq 'GET' -and $path -eq '/status') {
                Write-Json -Context $ctx -Status 200 -Object @{
                    ok = $true
                    result = @{
                        rescue = @{ pid = $PID; port = $Port; root = $Root; version = $Version; task = 'EFAB Rescue Control SYSTEM' }
                        primary = Get-PrimaryInspection
                        ports = (Get-BridgePorts)
                        tailscale = Get-Service Tailscale -ErrorAction SilentlyContinue | Select-Object Name, Status, StartType
                        uptime_seconds = [int]((Get-Date) - (Get-CimInstance Win32_OperatingSystem).LastBootUpTime).TotalSeconds
                    }
                }
                continue
            }

            if ($method -eq 'GET' -and $path -eq '/primary/inspect') {
                Write-Json -Context $ctx -Status 200 -Object @{ ok = $true; result = (Get-PrimaryInspection) }
                continue
            }

            if ($method -eq 'GET' -and $path -eq '/primary/ports') {
                Write-Json -Context $ctx -Status 200 -Object @{ ok = $true; result = @{ ports = (Get-BridgePorts) } }
                continue
            }

            if ($method -eq 'GET' -and $path -eq '/primary/run-store') {
                Write-Json -Context $ctx -Status 200 -Object @{ ok = $true; result = @{ roots = (Get-RunStoreSummary) } }
                continue
            }

            if ($method -eq 'GET' -and $path -match '^/primary/managed-runs/([^/]+)$') {
                $runId = [Uri]::UnescapeDataString($Matches[1])
                Write-Json -Context $ctx -Status 200 -Object @{ ok = $true; result = (Inspect-ManagedRun -RunId $runId) }
                continue
            }

            if ($method -eq 'GET' -and $path -eq '/primary/logs') {
                $runId = [string]$ctx.Request.QueryString['run_id']
                $tailValue = [string]$ctx.Request.QueryString['tail']
                $tail = 100
                if ($tailValue -match '^\d+$') { $tail = [int]$tailValue }
                Write-Json -Context $ctx -Status 200 -Object @{
                    ok = $true
                    result = @{ run_id = $runId; files = Get-PrimaryLogs -RunId $runId -Tail $tail }
                }
                continue
            }

            if ($method -eq 'POST' -and $path -eq '/primary/lifecycle/probe') {
                $body = Read-JsonBody -Request $ctx.Request
                $runId = [string]$body.run_id
                $result = [ordered]@{
                    health = Invoke-PrimaryRequest -Path '/health' -Method GET -TimeoutSeconds 5
                    context_bridge = Invoke-PrimaryRequest -Path '/context/check' -Method POST -Body @{ expected_root = 'H:\bridge'; cwd = 'H:\bridge' } -TimeoutSeconds 7
                    context_efab = Invoke-PrimaryRequest -Path '/context/check' -Method POST -Body @{ expected_root = 'H:\efab'; cwd = 'H:\efab' } -TimeoutSeconds 7
                }
                if ($runId) {
                    Assert-RunId -RunId $runId
                    $result.run_status = Invoke-PrimaryRequest -Path "/runs/$runId/status" -Method GET -TimeoutSeconds 7
                }
                Write-Json -Context $ctx -Status 200 -Object @{ ok = $true; result = $result }
                continue
            }


            if ($method -eq 'POST' -and $path -eq '/repair/text-replace') {
                $body = Read-JsonBody -Request $ctx.Request
                $result = Invoke-BoundedTextRepair -Body $body
                Write-Json -Context $ctx -Status 200 -Object @{ ok = $true; result = $result }
                continue
            }

            if ($method -eq 'POST' -and $path -eq '/primary/restart-controlled') {
                $body = Read-JsonBody -Request $ctx.Request
                $result = (Start-ControlledPrimaryRestart -Body $body)
                Write-Json -Context $ctx -Status 202 -Object @{ ok = $true; result = $result }
                continue
            }
            if ($method -eq 'POST' -and $path -eq '/components/recover') {
                $body = Read-JsonBody -Request $ctx.Request
                $result = Invoke-ControlledComponentRecovery -Body $body
                Write-RescueLog -Event 'component_recovery_completed' -Data @{ component=[string]$body.component; recovered=[bool]$result.recovered }
                Write-Json -Context $ctx -Status 200 -Object @{ ok = [bool]$result.recovered; result = $result }
                continue
            }
            if ($method -eq 'POST' -and $path -eq '/channels/reconcile-all') {
                $body = Read-JsonBody -Request $ctx.Request
                $result = Invoke-ReconcileAllChannels -Body $body
                Write-RescueLog -Event 'channels_reconcile_completed' -Data @{ reconciled=[bool]$result.reconciled; actions_count=[int]$result.actions_count }
                Write-Json -Context $ctx -Status 200 -Object @{ ok = [bool]$result.reconciled; result = $result }
                continue
            }



            if ($method -eq 'GET' -and $path -match '^/proofs/([^/]+)$') {
                $operationId = [Uri]::UnescapeDataString($Matches[1])
                $result = Get-RecoveryProof -OperationId $operationId
                $status = if ($result.found) { 200 } else { 404 }
                Write-Json -Context $ctx -Status $status -Object @{ ok = [bool]$result.found; result = $result }
                continue
            }

            if ($method -eq 'GET' -and $path -eq '/proofs/latest') {
                Write-Json -Context $ctx -Status 200 -Object @{ ok = $true; result = (Get-LatestRecoveryProof) }
                continue
            }

            if ($method -eq 'GET' -and $path -eq '/logs/tail') {
                $lines = if (Test-Path -LiteralPath $LogPath) { @(Get-Content -LiteralPath $LogPath -Tail 100) } else { @() }
                Write-Json -Context $ctx -Status 200 -Object @{ ok = $true; result = @{ lines = @($lines | ForEach-Object { Redact-Text -Text ([string]$_) }) } }
                continue
            }

            if ($method -eq 'POST' -and $path -eq '/machine/reboot') {
                $body = Read-JsonBody -Request $ctx.Request
                if ([string]$body.confirm -ne 'REBOOT_EFAB_PC') {
                    Write-Json -Context $ctx -Status 409 -Object @{ ok = $false; error = @{ code = 'CONFIRMATION_REQUIRED'; message = 'Set confirm to REBOOT_EFAB_PC.' } }
                }
                else {
                    Write-RescueLog -Event 'machine_reboot_requested' -Data @{}
                    Write-Json -Context $ctx -Status 202 -Object @{ ok = $true; result = @{ accepted = $true; action = 'reboot' } }
                    Start-Process shutdown.exe -ArgumentList '/r','/t','5','/f' -WindowStyle Hidden
                }
                continue
            }

            Write-Json -Context $ctx -Status 404 -Object @{ ok = $false; error = @{ code = 'NOT_FOUND'; message = 'Unknown rescue route.' } }
        }
        catch {
            $message = $_.Exception.Message
            $code = switch -Regex ($message) {
                '^INVALID_RUN_ID$' { 'INVALID_RUN_ID'; break }
                '^INVALID_OPERATION_ID$' { 'INVALID_OPERATION_ID'; break }
                '^CONFIRMATION_REQUIRED$' { 'CONFIRMATION_REQUIRED'; break }
                '^REASON_REQUIRED$' { 'REASON_REQUIRED'; break }
                '^REASON_TOO_LONG$' { 'REASON_TOO_LONG'; break }
                '^RESTART_WORKER_MISSING$' { 'RESTART_WORKER_MISSING'; break }
                '^RESTART_ALREADY_RUNNING$' { 'RESTART_ALREADY_RUNNING'; break }
                default { 'RESCUE_ERROR' }
            }
            $status = if ($code -in @('CONFIRMATION_REQUIRED','REASON_REQUIRED','REASON_TOO_LONG','RESTART_ALREADY_RUNNING')) { 409 } elseif ($code -in @('INVALID_RUN_ID','INVALID_OPERATION_ID')) { 400 } else { 500 }
            Write-RescueLog -Event 'request_error' -Data @{ path = $path; code = $code; error = $message }
            try {
                Write-Json -Context $ctx -Status $status -Object @{
                    ok = $false
                    error = @{
                        code = $code
                        message = $message
                        recovery_action = 'Use read-only inspect routes or retrieve the latest recovery proof.'
                    }
                }
            }
            catch {}
        }
    }
}
finally {
    try { $listener.Stop() } catch {}
    try { $listener.Close() } catch {}
    Write-RescueLog -Event 'rescue_stopped' -Data @{ pid = $PID; version = $Version }
}
