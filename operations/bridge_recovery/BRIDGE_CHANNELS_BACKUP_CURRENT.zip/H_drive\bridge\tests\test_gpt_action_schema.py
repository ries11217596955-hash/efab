from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCHEMA_PATH = ROOT / "docs" / "gpt_action" / "bridge_action.openapi.json"


def load_schema() -> dict:
    return json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))


def request_body_schema(schema: dict, path: str) -> dict:
    return schema["paths"][path]["post"]["requestBody"]["content"]["application/json"]["schema"]


def test_gpt_action_schema_has_required_server_auth_and_operations():
    schema = load_schema()

    assert schema["openapi"].startswith("3.")
    assert schema["servers"] == [{"url": "https://REPLACE_WITH_PUBLIC_BRIDGE_URL"}]

    bridge_token = schema["components"]["securitySchemes"]["BridgeToken"]
    assert bridge_token == {
        "type": "apiKey",
        "in": "header",
        "name": "X-Bridge-Token",
        "description": "Bridge API key. Configure the token outside the repository and never commit it.",
    }

    operations = {
        path: {
            method: details["operationId"]
            for method, details in path_item.items()
            if method in {"get", "post"}
        }
        for path, path_item in schema["paths"].items()
    }
    assert operations == {
        "/health": {"get": "getHealth"},
        "/channels/reconcile-all": {"post": "reconcileAllChannelsViaPrimary"},
        "/codex/runner/v0_1": {"post": "runCodexBounded"},
        "/context/check": {"post": "checkContext"},
        "/terminal/run": {"post": "runTerminal"},
        "/runs/start": {"post": "startRun"},
        "/runs/{run_id}/status": {"get": "getRunStatus"},
        "/runs/{run_id}/wait": {"post": "waitRun"},
        "/runs/{run_id}/logs": {"get": "getRunLogs"},
        "/runs/{run_id}/kill": {"post": "killRun"},
    }


def test_gpt_action_schema_auth_and_expected_root_requirements():
    schema = load_schema()

    assert schema["paths"]["/health"]["get"]["security"] == []
    protected_operations = [
        schema["paths"]["/channels/reconcile-all"]["post"],
        schema["paths"]["/codex/runner/v0_1"]["post"],
        schema["paths"]["/context/check"]["post"],
        schema["paths"]["/terminal/run"]["post"],
        schema["paths"]["/runs/start"]["post"],
        schema["paths"]["/runs/{run_id}/status"]["get"],
        schema["paths"]["/runs/{run_id}/wait"]["post"],
        schema["paths"]["/runs/{run_id}/logs"]["get"],
        schema["paths"]["/runs/{run_id}/kill"]["post"],
    ]
    assert all(operation["security"] == [{"BridgeToken": []}] for operation in protected_operations)

    assert "expected_root" in schema["components"]["schemas"]["ContextCheckRequest"]["required"]
    assert "expected_root" in schema["components"]["schemas"]["TerminalRunActionRequest"]["required"]

    context_request = request_body_schema(schema, "/context/check")
    terminal_request = request_body_schema(schema, "/terminal/run")
    runs_start_request = request_body_schema(schema, "/runs/start")

    assert "expected_root" in context_request["required"]
    assert "expected_root" in terminal_request["required"]
    assert "expected_root" in runs_start_request["required"]
    assert context_request["type"] == "object"
    assert terminal_request["type"] == "object"
    assert runs_start_request["type"] == "object"
    assert "$ref" not in context_request
    assert "$ref" not in terminal_request
    assert "$ref" not in runs_start_request
    assert "allOf" not in context_request
    assert "allOf" not in terminal_request
    assert "allOf" not in runs_start_request

    wait_request = request_body_schema(schema, "/runs/{run_id}/wait")
    assert wait_request["type"] == "object"
    assert "$ref" not in wait_request
    assert "allOf" not in wait_request

    for path, method in [
        ("/runs/{run_id}/status", "get"),
        ("/runs/{run_id}/wait", "post"),
        ("/runs/{run_id}/logs", "get"),
        ("/runs/{run_id}/kill", "post"),
    ]:
        parameter = schema["paths"][path][method]["parameters"][0]
        assert parameter["name"] == "run_id"
        assert parameter["in"] == "path"
        assert parameter["required"] is True
        assert "$ref" not in parameter


def test_gpt_action_schema_exposes_diagnostic_fields():
    schema = load_schema()

    context_result = schema["components"]["schemas"]["ContextCheckResult"]["properties"]
    assert {"context_status", "command_allowed", "command_started"}.issubset(context_result)

    terminal_result = schema["components"]["schemas"]["TerminalRunResult"]["properties"]
    assert {"status", "run_id", "request_control"}.issubset(terminal_result)

    request_control = schema["components"]["schemas"]["RequestControlBundle"]["properties"]
    assert {
        "request_id",
        "received_at",
        "command_sha256",
        "validation_status",
        "auth_status",
        "authenticated",
        "normalized_cwd",
        "shell",
        "timeout_seconds",
    }.issubset(request_control)

    diagnostic_response = schema["components"]["schemas"]["DiagnosticErrorResponse"]["properties"]
    assert {"ok", "status", "run_id", "context_status", "command_allowed", "command_started", "error"}.issubset(
        diagnostic_response
    )

    diagnostic_error = schema["components"]["schemas"]["DiagnosticError"]["properties"]
    assert {
        "code",
        "root_cause",
        "expected_root",
        "actual_root",
        "actual_cwd",
        "owner_action",
        "next_actions",
    }.issubset(diagnostic_error)


def test_primary_reconcile_all_action_contract():
    schema = load_schema()
    operation = schema["paths"]["/channels/reconcile-all"]["post"]
    assert operation["operationId"] == "reconcileAllChannelsViaPrimary"
    assert operation["security"] == [{"BridgeToken": []}]
    request = request_body_schema(schema, "/channels/reconcile-all")
    assert request["type"] == "object"
    assert request["required"] == ["confirm"]
    assert request["properties"]["confirm"]["enum"] == ["RECONCILE_ALL_CHANNELS"]
    assert request["additionalProperties"] is False


def test_capability_first_descriptions_and_codex_contract():
    schema = load_schema()
    assert schema["info"]["version"] == "0.8.0"
    for path, method in [
        ("/health", "get"),
        ("/context/check", "post"),
        ("/terminal/run", "post"),
        ("/runs/start", "post"),
        ("/channels/reconcile-all", "post"),
        ("/codex/runner/v0_1", "post"),
    ]:
        operation = schema["paths"][path][method]
        assert len(operation.get("summary", "")) >= 12
        assert len(operation.get("description", "")) >= 40

    operation = schema["paths"]["/codex/runner/v0_1"]["post"]
    assert operation["operationId"] == "runCodexBounded"
    assert operation["security"] == [{"BridgeToken": []}]
    request = request_body_schema(schema, "/codex/runner/v0_1")
    assert request["type"] == "object"
    assert request["additionalProperties"] is False
    assert set(request["required"]) == {
        "repo_root",
        "allowed_output",
        "task_text",
        "mode",
        "require_clean_allowed_outputs",
    }
    assert request["properties"]["mode"]["enum"] == ["bypass"]
    assert request["properties"]["require_clean_allowed_outputs"]["enum"] == [True]
    assert "task_file" not in request["properties"]
    assert "workspace-write" not in request["properties"]["mode"]["enum"]

