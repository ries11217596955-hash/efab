﻿# EFAB RESCUE CONTROL PLANE V1

Status: PROVEN_LIVE_FOR_HEALTH_AND_EXTERNAL_REACHABILITY
Date: 2026-07-26

## Installed body

- Root: `C:\ProgramData\EFAB-Rescue`
- Main task: `EFAB Rescue Control SYSTEM`
- Watchdog task: `EFAB Rescue Watchdog SYSTEM`
- Listener: `127.0.0.1:18789`
- External route: Tailscale Funnel
- Primary Bridge remains separate on `127.0.0.1:18788` through ngrok/recovery path.
- Legacy task `EFAB Emergency Channel SYSTEM` is disabled.

## Rescue API

- `GET /health`
- `GET /status`
- `POST /primary/start`
- `POST /primary/stop`
- `POST /primary/restart`
- `GET /logs/tail`
- `POST /machine/reboot` with exact confirmation `REBOOT_EFAB_PC`

Authentication uses `X-Rescue-Token`. The token is stored only at `C:\ProgramData\EFAB-Rescue\rescue_token.txt` with restricted ACL and is deliberately excluded from this archive.

## Proven

- PowerShell syntax parse PASS.
- Staging health/status PASS.
- Invalid token returns HTTP 401.
- Live local health PASS.
- Live external Tailscale health/status PASS.
- Rescue task runs as SYSTEM from outside `H:\bridge`.
- Watchdog task is enabled and external health remained PASS after installation.

## Not yet proven

- Actual remote reboot and post-boot return.
- Actual primary Bridge kill/restart through Rescue.
- Tailscale recovery if the Tailscale Windows service itself fails.
- Independence from total Windows/host/power/network failure.

## Acceptance drills remaining

1. Kill primary Bridge and restore it through Rescue.
2. Reboot PC through Rescue and prove Rescue returns first.
3. Verify primary Bridge returns after boot.
4. Add this OpenAPI as a second GPT Action using the separate Rescue token.
5. Add an off-machine heartbeat/alert for the Rescue URL.
