$ErrorActionPreference = 'SilentlyContinue'
$Root = 'C:\ProgramData\EFAB-Rescue'
$Task = 'EFAB Rescue Control SYSTEM'
$TokenPath = Join-Path $Root 'rescue_token.txt'
$Log = Join-Path $Root 'watchdog.log'

function Write-WatchdogLog {
    param([string]$Event, [hashtable]$Data = @{})
    $row = [ordered]@{
        ts = (Get-Date).ToUniversalTime().ToString('o')
        event = $Event
        data = $Data
    }
    Add-Content -LiteralPath $Log -Value ($row | ConvertTo-Json -Compress -Depth 6) -Encoding UTF8
}

$healthy = $false
if (Test-Path -LiteralPath $TokenPath) {
    $token = (Get-Content -LiteralPath $TokenPath -Raw).Trim()
    try {
        $response = Invoke-RestMethod -Uri 'http://127.0.0.1:18789/health' -Headers @{ 'X-Rescue-Token' = $token } -TimeoutSec 7
        $healthy = [bool]($response.ok -and $response.result.rescue_ready)
    }
    catch {
        Write-WatchdogLog -Event 'health_failed' -Data @{ error = $_.Exception.Message }
    }
}

if (-not $healthy) {
    Stop-ScheduledTask -TaskName $Task -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 1

    $listener = Get-NetTCPConnection -State Listen -LocalPort 18789 -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($listener) {
        Stop-Process -Id ([int]$listener.OwningProcess) -Force -ErrorAction SilentlyContinue
    }

    Start-ScheduledTask -TaskName $Task -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 4
    try {
        $response = Invoke-RestMethod -Uri 'http://127.0.0.1:18789/health' -Headers @{ 'X-Rescue-Token' = $token } -TimeoutSec 7
        Write-WatchdogLog -Event 'restart_result' -Data @{ ok = [bool]$response.ok; version = $response.result.version }
    }
    catch {
        Write-WatchdogLog -Event 'restart_result' -Data @{ ok = $false; error = $_.Exception.Message }
    }
}

$funnelStatus = ''
$funnelHealthy = $false
try {
    $funnelStatus = (& tailscale funnel status 2>&1 | Out-String)
    $funnelHealthy = ($funnelStatus -match '127\.0\.0\.1:18789' -and $funnelStatus -match '127\.0\.0\.1:18790')
}
catch {
    Write-WatchdogLog -Event 'funnel_status_failed' -Data @{ error = $_.Exception.Message }
}

if (-not $funnelHealthy) {
    & tailscale funnel --bg --https=443 --set-path=/ http://127.0.0.1:18789 | Out-Null
    & tailscale funnel --bg --https=443 --set-path=/pc-control http://127.0.0.1:18790 | Out-Null
    Start-Sleep -Seconds 2
    $after = (& tailscale funnel status 2>&1 | Out-String)
    $restored = ($after -match '127\.0\.0\.1:18789' -and $after -match '127\.0\.0\.1:18790')
    Write-WatchdogLog -Event 'funnel_reconcile_result' -Data @{ ok = $restored; status = $after.Trim() }
}