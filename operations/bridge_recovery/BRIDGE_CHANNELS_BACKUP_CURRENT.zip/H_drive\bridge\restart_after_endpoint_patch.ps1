﻿Start-Sleep -Seconds 3
Set-Location 'H:\bridge'
try {
  powershell -NoProfile -ExecutionPolicy Bypass -File '.\start_gpt_action_bridge_dev.ps1' *> 'H:\bridge\restart_after_endpoint_patch.log'
} catch {
  $_ | Out-String | Set-Content -Encoding UTF8 'H:\bridge\restart_after_endpoint_patch.error.log'
}
