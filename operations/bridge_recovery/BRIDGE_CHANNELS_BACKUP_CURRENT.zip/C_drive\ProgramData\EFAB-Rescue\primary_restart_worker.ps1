param(
    [Parameter(Mandatory = $true)]
    [string]$OperationId
)

$ErrorActionPreference = 'Stop'
$Root = 'C:\ProgramData\EFAB-Rescue'
$RequestPath = Join-Path (Join-Path $Root 'requests') "$OperationId.json"
$ProofRoot = Join-Path $Root 'proofs'
$ProofPath = Join-Path $ProofRoot "$OperationId.json"
$PrimaryTask = 'EFAB Bridge Boot SYSTEM'
$PrimaryPort = 18788
$RescuePort = 18789
$MutexName = 'Global\EFAB_Rescue_Primary_Restart_V2'

New-Item -ItemType Directory -Force -Path $ProofRoot | Out-Null

function Get-ListenerPid {
    param([int]$Port)
    $listener = Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($listener) { return [int]$listener.OwningProcess }
    return $null
}

function Get-ProcessSnapshot {
    param([int]$ProcessId)
    if (-not $ProcessId) { return $null }
    $p = Get-CimInstance Win32_Process -Filter "ProcessId=$ProcessId" -ErrorAction SilentlyContinue
    if (-not $p) { return $null }
    return [ordered]@{
        pid = [int]$p.ProcessId
        parent_pid = [int]$p.ParentProcessId
        name = [string]$p.Name
        command_line = [string]$p.CommandLine
    }
}

function Get-TaskSnapshot {
    $task = Get-ScheduledTask -TaskName $PrimaryTask -ErrorAction SilentlyContinue
    $info = if ($task) { $task | Get-ScheduledTaskInfo } else { $null }
    return [ordered]@{
        exists = [bool]$task
        state = if ($task) { [string]$task.State } else { $null }
        last_run = if ($info -and $info.LastRunTime.Year -gt 2000) { $info.LastRunTime.ToUniversalTime().ToString('o') } else { $null }
        last_result = if ($info) { [int64]$info.LastTaskResult } else { $null }
    }
}

function Test-PrimaryHealth {
    try {
        $response = Invoke-RestMethod -Uri "http://127.0.0.1:$PrimaryPort/health" -TimeoutSec 5
        return [bool]$response.ok
    }
    catch {
        return $false
    }
}

function Get-State {
    $pidValue = Get-ListenerPid -Port $PrimaryPort
    return [ordered]@{
        listener_pid = $pidValue
        listener = [bool]$pidValue
        process = if ($pidValue) { Get-ProcessSnapshot -Pid $pidValue } else { $null }
        task = Get-TaskSnapshot
        health = Test-PrimaryHealth
        timestamp = (Get-Date).ToUniversalTime().ToString('o')
    }
}

function Save-Proof {
    param($Proof)
    $Proof.updated_at = (Get-Date).ToUniversalTime().ToString('o')
    $Proof | ConvertTo-Json -Depth 16 | Set-Content -LiteralPath $ProofPath -Encoding UTF8
}

function Stop-ProcessTree {
    param([int]$RootPid)
    if (-not $RootPid) { return @() }
    $all = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue)
    $toStop = New-Object System.Collections.Generic.List[int]
    function Add-Children([int]$ParentPid) {
        foreach ($child in @($all | Where-Object { [int]$_.ParentProcessId -eq $ParentPid })) {
            Add-Children -ParentPid ([int]$child.ProcessId)
            if (-not $toStop.Contains([int]$child.ProcessId)) { $toStop.Add([int]$child.ProcessId) }
        }
    }
    Add-Children -ParentPid $RootPid
    if (-not $toStop.Contains($RootPid)) { $toStop.Add($RootPid) }
    $stopped = @()
    foreach ($pidValue in $toStop) {
        try {
            Stop-Process -Id $pidValue -Force -ErrorAction Stop
            $stopped += $pidValue
        }
        catch {}
    }
    return $stopped
}

$proof = [ordered]@{
    operation_id = $OperationId
    status = 'NOT_PROVEN'
    started_at = (Get-Date).ToUniversalTime().ToString('o')
    request = $null
    preflight = [ordered]@{}
    action = [ordered]@{}
    recovery = [ordered]@{ attempted = $false; success = $false }
    errors = @()
}

$mutex = $null
$hasMutex = $false

try {
    if ($OperationId -notmatch '^rescue_restart_[A-Za-z0-9_]{10,80}$') { throw 'INVALID_OPERATION_ID' }
    if (-not (Test-Path -LiteralPath $RequestPath -PathType Leaf)) { throw 'REQUEST_MISSING' }
    $proof.request = Get-Content -LiteralPath $RequestPath -Raw | ConvertFrom-Json
    if ([string]$proof.request.confirm -ne 'RESTART_PRIMARY') { throw 'CONFIRMATION_INVALID' }

    $createdNew = $false
    $mutex = [Threading.Mutex]::new($true, $MutexName, [ref]$createdNew)
    $hasMutex = $createdNew
    if (-not $createdNew) { throw 'RESTART_ALREADY_RUNNING' }

    $proof.preflight.rescue_listener_pid = Get-ListenerPid -Port $RescuePort
    $proof.preflight.primary_before = Get-State
    $proof.preflight.task_exists = [bool]$proof.preflight.primary_before.task.exists
    $proof.preflight.rescue_independent = [bool]($proof.preflight.rescue_listener_pid -and $proof.preflight.rescue_listener_pid -ne $proof.preflight.primary_before.listener_pid)
    if (-not $proof.preflight.task_exists) { throw 'PRIMARY_TASK_MISSING' }
    if (-not $proof.preflight.rescue_independent) { throw 'RESCUE_INDEPENDENCE_FAIL' }

    $proof.preflight.status = 'PREFLIGHT_PASS'
    Save-Proof -Proof $proof

    $oldPid = $proof.preflight.primary_before.listener_pid
    Stop-ScheduledTask -TaskName $PrimaryTask -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
    $proof.action.stopped_pids = if ($oldPid) { @(Stop-ProcessTree -RootPid ([int]$oldPid)) } else { @() }

    $portDown = $false
    for ($i = 0; $i -lt 20; $i++) {
        if (-not (Get-ListenerPid -Port $PrimaryPort)) { $portDown = $true; break }
        Start-Sleep -Seconds 1
    }
    $proof.action.port_down_proven = $portDown
    if (-not $portDown) { throw 'PRIMARY_PORT_DID_NOT_CLOSE' }

    Start-ScheduledTask -TaskName $PrimaryTask -ErrorAction Stop
    $ready = $false
    $newPid = $null
    for ($i = 0; $i -lt 90; $i++) {
        Start-Sleep -Seconds 1
        $newPid = Get-ListenerPid -Port $PrimaryPort
        if ($newPid -and (Test-PrimaryHealth)) { $ready = $true; break }
    }

    $proof.action.primary_after = Get-State
    $proof.action.new_pid = $newPid
    $proof.action.pid_changed = if ($oldPid -and $newPid) { ([int]$oldPid -ne [int]$newPid) } else { [bool]$newPid }
    $proof.action.health_ready = $ready
    $proof.action.rescue_still_listening = [bool](Get-ListenerPid -Port $RescuePort)

    if (-not $ready) { throw 'PRIMARY_DID_NOT_BECOME_READY' }
    if (-not $proof.action.pid_changed) { throw 'PRIMARY_PID_DID_NOT_CHANGE' }
    if (-not $proof.action.rescue_still_listening) { throw 'RESCUE_LOST_DURING_RESTART' }

    $proof.status = 'PROVEN_LIVE_PRIMARY_RESTART_VIA_RESCUE_V2'
}
catch {
    $proof.errors += $_.Exception.Message
    $proof.recovery.attempted = $true
    try {
        if (-not (Get-ListenerPid -Port $PrimaryPort)) {
            Start-ScheduledTask -TaskName $PrimaryTask -ErrorAction SilentlyContinue
        }
        $restored = $false
        for ($i = 0; $i -lt 60; $i++) {
            Start-Sleep -Seconds 1
            if ((Get-ListenerPid -Port $PrimaryPort) -and (Test-PrimaryHealth)) {
                $restored = $true
                break
            }
        }
        $proof.recovery.success = $restored
        $proof.recovery.state = Get-State
        $proof.status = if ($restored) { 'RESTART_FAILED_RECOVERY_PROVEN' } else { 'RESTART_FAILED_RECOVERY_FAILED' }
    }
    catch {
        $proof.recovery.error = $_.Exception.Message
        $proof.status = 'RESTART_FAILED_RECOVERY_FAILED'
    }
}
finally {
    $proof.finished_at = (Get-Date).ToUniversalTime().ToString('o')
    Save-Proof -Proof $proof
    if ($hasMutex -and $mutex) {
        try { $mutex.ReleaseMutex() } catch {}
    }
    if ($mutex) { $mutex.Dispose() }
}
