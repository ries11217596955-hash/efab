$ErrorActionPreference='Stop'
$f='C:\ProgramData\EFAB-PC-Control\pc_control_gateway.ps1'
$expected='C1B06B0169316A6DAED4288F2B2B9FE4B4F004441F1A8399B3DE59E9DFA09524'
$actual=(Get-FileHash $f -Algorithm SHA256).Hash
if($actual -ne $expected){throw "HASH_MISMATCH expected=$expected actual=$actual"}
$text=[IO.File]::ReadAllText($f)
$functionAnchor='$listener=[Net.HttpListener]::new()'
$routeAnchor="   Json `$ctx 404 @{ok=`$false;error=@{code='NOT_FOUND';message='Unknown PC-control route.'}}"
if(([regex]::Matches($text,[regex]::Escape($functionAnchor))).Count -ne 1){throw 'FUNCTION_ANCHOR_COUNT_NOT_ONE'}
if(([regex]::Matches($text,[regex]::Escape($routeAnchor))).Count -ne 1){throw 'ROUTE_ANCHOR_COUNT_NOT_ONE'}
$functions=@"
function Test-ManagedChannelState {
  `$primary=`$false;`$rescue=`$false;`$ngrok=`$false;`$funnel=`$false
  try{`$h=Invoke-RestMethod 'http://127.0.0.1:18788/health' -TimeoutSec 5;`$primary=[bool]`$h.ok}catch{}
  try{`$token=(Get-Content -LiteralPath `$TokenPath -Raw).Trim();`$h=Invoke-RestMethod 'http://127.0.0.1:18789/health' -Headers @{'X-Rescue-Token'=`$token} -TimeoutSec 5;`$rescue=[bool]`$h.ok}catch{}
  try{`$t=Invoke-RestMethod 'http://127.0.0.1:4040/api/tunnels' -TimeoutSec 5;`$ngrok=(@(`$t.tunnels).Count -gt 0)}catch{}
  try{`$s=(& tailscale funnel status 2>&1|Out-String);`$funnel=(`$s -match '127\.0\.0\.1:18789' -and `$s -match '127\.0\.0\.1:18790')}catch{}
  return [ordered]@{primary=`$primary;rescue=`$rescue;ngrok=`$ngrok;tailscale_funnel=`$funnel;checked_at=(Get-Date).ToUniversalTime().ToString('o')}
}
function Invoke-ReconcileAllChannels(`$Body){
  if([string]`$Body.confirm -ne 'RECONCILE_ALL_CHANNELS'){throw 'CONFIRMATION_REQUIRED'}
  `$before=Test-ManagedChannelState;`$actions=@()
  if(-not `$before.primary){Enable-ScheduledTask -TaskName 'EFAB Recovery Gateway SYSTEM' -ErrorAction SilentlyContinue|Out-Null;Start-ScheduledTask -TaskName 'EFAB Recovery Gateway SYSTEM' -ErrorAction Stop;Start-Sleep -Seconds 8;`$ok=`$false;try{`$ok=[bool](Invoke-RestMethod 'http://127.0.0.1:18788/health' -TimeoutSec 5).ok}catch{};`$actions+=[pscustomobject]@{component='primary';action='start_task';recovered=`$ok}}
  if(-not `$before.ngrok){Enable-ScheduledTask -TaskName 'EFAB Ngrok Watchdog SYSTEM' -ErrorAction SilentlyContinue|Out-Null;Start-ScheduledTask -TaskName 'EFAB Ngrok Primary SYSTEM' -ErrorAction Stop;Start-Sleep -Seconds 6;`$ok=`$false;try{`$ok=(@((Invoke-RestMethod 'http://127.0.0.1:4040/api/tunnels' -TimeoutSec 5).tunnels).Count -gt 0)}catch{};`$actions+=[pscustomobject]@{component='ngrok';action='start_task';recovered=`$ok}}
  if(-not `$before.rescue){Enable-ScheduledTask -TaskName 'EFAB Rescue Watchdog SYSTEM' -ErrorAction SilentlyContinue|Out-Null;Start-ScheduledTask -TaskName 'EFAB Rescue Control SYSTEM' -ErrorAction Stop;Start-Sleep -Seconds 6;`$ok=`$false;try{`$token=(Get-Content -LiteralPath `$TokenPath -Raw).Trim();`$ok=[bool](Invoke-RestMethod 'http://127.0.0.1:18789/health' -Headers @{'X-Rescue-Token'=`$token} -TimeoutSec 5).ok}catch{};`$actions+=[pscustomobject]@{component='rescue';action='start_task';recovered=`$ok}}
  if(-not `$before.tailscale_funnel){& tailscale funnel --bg --yes --https=443 --set-path=/ http://127.0.0.1:18789|Out-Null;& tailscale funnel --bg --yes --https=443 --set-path=/pc-control http://127.0.0.1:18790|Out-Null;Start-Sleep -Seconds 3;`$s=(& tailscale funnel status 2>&1|Out-String);`$ok=(`$s -match '127\.0\.0\.1:18789' -and `$s -match '127\.0\.0\.1:18790');`$actions+=[pscustomobject]@{component='tailscale_funnel';action='ensure_routes';recovered=`$ok}}
  foreach(`$n in @('EFAB Rescue Watchdog SYSTEM','EFAB Ngrok Watchdog SYSTEM')){Enable-ScheduledTask -TaskName `$n -ErrorAction SilentlyContinue|Out-Null;Start-ScheduledTask -TaskName `$n -ErrorAction SilentlyContinue}
  `$after=Test-ManagedChannelState;`$ok=([bool]`$after.primary -and [bool]`$after.rescue -and [bool]`$after.ngrok -and [bool]`$after.tailscale_funnel)
  return [pscustomobject]@{reconciled=`$ok;before=`$before;actions=@(`$actions);actions_count=@(`$actions).Count;after=`$after;finished_at=(Get-Date).ToUniversalTime().ToString('o')}
}

"@ -replace "`n","`r`n"
$route=@"
   if(`$method -eq 'POST' -and `$path -eq '/channels/reconcile-all'){
    `$b=ReadBody `$ctx.Request
    `$r=Invoke-ReconcileAllChannels `$b
    Log 'channels_reconcile_completed' @{reconciled=[bool]`$r.reconciled;actions_count=[int]`$r.actions_count}
    Json `$ctx 200 @{ok=[bool]`$r.reconciled;result=`$r};continue
   }
"@ -replace "`n","`r`n"
$stamp=(Get-Date).ToUniversalTime().ToString('yyyyMMdd-HHmmss');$bak="$f.bak-$stamp";Copy-Item $f $bak -Force
$patched=$text.Replace($functionAnchor,$functions+$functionAnchor).Replace($routeAnchor,$route+$routeAnchor)
[IO.File]::WriteAllText($f,$patched,[Text.UTF8Encoding]::new($false))
$tokens=$null;$errors=$null;[System.Management.Automation.Language.Parser]::ParseFile($f,[ref]$tokens,[ref]$errors)|Out-Null
if($errors.Count -gt 0){Copy-Item $bak $f -Force;throw ('PARSER_FAIL_ROLLED_BACK: '+(($errors|ForEach-Object{$_.Message}) -join '; '))}
Stop-ScheduledTask -TaskName 'EFAB PC Control SYSTEM' -ErrorAction Stop;Start-Sleep -Seconds 2;Start-ScheduledTask -TaskName 'EFAB PC Control SYSTEM' -ErrorAction Stop;Start-Sleep -Seconds 6
$token=(Get-Content 'C:\ProgramData\EFAB-Rescue\rescue_token.txt' -Raw).Trim();$headers=@{'X-Rescue-Token'=$token}
$health=Invoke-RestMethod 'http://127.0.0.1:18790/health' -Headers $headers -TimeoutSec 8
$rec=Invoke-RestMethod 'http://127.0.0.1:18790/channels/reconcile-all' -Method Post -Headers $headers -ContentType 'application/json' -Body (@{confirm='RECONCILE_ALL_CHANNELS'}|ConvertTo-Json) -TimeoutSec 30
[pscustomobject]@{status='PASS';backup=$bak;before_sha256=$actual;after_sha256=(Get-FileHash $f -Algorithm SHA256).Hash;parser='PASS';pc_control_ok=[bool]$health.ok;reconcile=$rec;finished_at=(Get-Date).ToUniversalTime().ToString('o')}|ConvertTo-Json -Depth 12|Set-Content -LiteralPath 'C:\ProgramData\EFAB-PC-Control\patches\reconcile_all_20260728_2020\result.json' -Encoding UTF8