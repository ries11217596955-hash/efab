$ErrorActionPreference='Stop'
$Root='C:\ProgramData\EFAB-Primary'
$Log=Join-Path $Root 'primary_boot.log'
$Python='C:\Users\Azerbaijan\AppData\Local\Programs\Python\Python314\python.exe'
$BridgeRoot='H:\bridge'
function Log($event,$data){$row=[ordered]@{ts=(Get-Date).ToUniversalTime().ToString('o');event=$event;data=$data};Add-Content -Path $Log -Value ($row|ConvertTo-Json -Compress -Depth 5) -Encoding UTF8}
function Healthy(){try{$token=(Get-Content 'H:\bridge\recovery_gateway_v1\bridge_token.txt' -Raw).Trim();$r=Invoke-RestMethod 'http://127.0.0.1:18788/health' -Headers @{'X-Bridge-Token'=$token} -TimeoutSec 3;return [bool]$r.ok}catch{return $false}}
if(Healthy){Log 'already_healthy' @{};exit 0}
if(-not(Test-Path $Python)){Log 'python_missing' @{path=$Python};exit 11}
if(-not(Test-Path (Join-Path $BridgeRoot 'src\bridge_app\main.py'))){Log 'bridge_missing' @{root=$BridgeRoot};exit 12}
$env:PYTHONPATH=Join-Path $BridgeRoot 'src'
$env:BRIDGE_ALLOWED_ROOTS='H:\bridge;H:\efab'
$p=Start-Process -FilePath $Python -ArgumentList '-m','uvicorn','bridge_app.main:app','--host','127.0.0.1','--port','18788' -WorkingDirectory $BridgeRoot -WindowStyle Hidden -PassThru
Log 'started' @{pid=$p.Id}
for($i=0;$i -lt 30;$i++){Start-Sleep 2;if(Healthy){Log 'healthy' @{pid=$p.Id;elapsed_seconds=(($i+1)*2)};exit 0}}
Log 'health_timeout' @{pid=$p.Id};exit 13
