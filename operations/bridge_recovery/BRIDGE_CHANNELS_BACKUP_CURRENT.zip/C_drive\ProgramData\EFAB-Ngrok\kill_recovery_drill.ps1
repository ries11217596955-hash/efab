﻿$ErrorActionPreference='SilentlyContinue'
$root='C:\ProgramData\EFAB-Ngrok'
$proof=Join-Path $root 'kill_recovery_drill_20260726.json'
$start=Get-Date
$old=(Get-Process ngrok -ErrorAction SilentlyContinue|Select-Object -First 1)
$result=[ordered]@{started_at=$start.ToUniversalTime().ToString('o');old_pid=if($old){$old.Id}else{$null};new_pid=$null;public_restored=$false;elapsed_seconds=$null;status='NOT_PROVEN'}
if($old){Stop-Process -Id $old.Id -Force}
for($i=0;$i -lt 30;$i++){
  Start-Sleep 2
  $p=Get-Process ngrok -ErrorAction SilentlyContinue|Select-Object -First 1
  if($p -and $p.Id -ne $result.old_pid){
    $result.new_pid=$p.Id
    try{$r=Invoke-WebRequest -Uri 'https://scabbed-corner-gap.ngrok-free.dev/health' -UseBasicParsing -TimeoutSec 5;if($r.StatusCode -eq 200){$result.public_restored=$true;break}}catch{}
  }
}
$result.elapsed_seconds=[int]((Get-Date)-$start).TotalSeconds
$result.status=if($result.public_restored){'PROVEN_LIVE_NGROK_AUTO_RECOVERY'}else{'FAIL'}
$result|ConvertTo-Json -Depth 5|Set-Content -Encoding UTF8 $proof
