param(
  [Parameter(Mandatory=$true)][string]$RepoRoot,
  [string]$TaskText,
  [string]$TaskFile,
  [string[]]$AllowedOutput=@(),
  [int]$RuntimeLimitSeconds=3600,
  [string]$RunId,
  [switch]$Worker
)

$ErrorActionPreference='Stop'
$CodexCmd='C:\Users\Azerbaijan\Tools\nodejs\node-v24.13.1-win-x64\codex.cmd'
$CodexHome='C:\Users\Azerbaijan\.codex'
$RunsRoot='H:\bridge\codex_handoff_runs'

function Write-JsonFile([string]$Path,[object]$Object){
  $json=$Object | ConvertTo-Json -Depth 10
  [IO.File]::WriteAllText($Path,$json,(New-Object Text.UTF8Encoding($false)))
}
function Get-TaskText {
  if([bool]$TaskText -eq [bool]$TaskFile){ throw 'Provide exactly one of TaskText or TaskFile.' }
  if($TaskFile){ return [IO.File]::ReadAllText((Resolve-Path -LiteralPath $TaskFile)) }
  return $TaskText
}
function Snapshot-Files([string]$Root){
  $map=@{}
  Get-ChildItem -LiteralPath $Root -Recurse -Force -File -ErrorAction SilentlyContinue | ForEach-Object {
    $rel=$_.FullName.Substring($Root.Length).TrimStart('\\').Replace('\\','/')
    $map[$rel]=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash
  }
  return $map
}

$RepoRoot=(Resolve-Path -LiteralPath $RepoRoot).Path
if(-not (Test-Path -LiteralPath $RepoRoot -PathType Container)){ throw 'RepoRoot must be an existing directory.' }
if(-not (Test-Path -LiteralPath $CodexCmd -PathType Leaf)){ throw 'Codex CLI missing.' }
New-Item -ItemType Directory -Force -Path $RunsRoot | Out-Null

if(-not $Worker){
  if(-not $RunId){ $RunId='codex_handoff_'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'_'+([guid]::NewGuid().ToString('N').Substring(0,8)) }
  $runDir=Join-Path $RunsRoot $RunId
  New-Item -ItemType Directory -Force -Path $runDir | Out-Null
  $task=Get-TaskText
  $taskPath=Join-Path $runDir 'task.txt'
  [IO.File]::WriteAllText($taskPath,$task,(New-Object Text.UTF8Encoding($false)))
  $allowedPath=Join-Path $runDir 'allowed.json'
  Write-JsonFile $allowedPath @($AllowedOutput)
  $reportPath=Join-Path $runDir 'report.json'
  $initial=[ordered]@{run_id=$RunId;status='STARTED';repo_root=$RepoRoot;report_path=$reportPath;started_at=(Get-Date).ToUniversalTime().ToString('o');finished_at=$null;exit_code=$null;allowed_output=@($AllowedOutput);validation=$null}
  Write-JsonFile $reportPath $initial
  $args=@('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',$PSCommandPath,'-RepoRoot',$RepoRoot,'-TaskFile',$taskPath,'-RuntimeLimitSeconds',[string]$RuntimeLimitSeconds,'-RunId',$RunId,'-Worker')
  Start-Process -FilePath 'powershell.exe' -ArgumentList $args -WindowStyle Hidden | Out-Null
  [pscustomobject]@{ok=$true;status='STARTED';run_id=$RunId;report_path=$reportPath;run_dir=$runDir;repo_root=$RepoRoot} | ConvertTo-Json -Compress
  exit 0
}

$runDir=Join-Path $RunsRoot $RunId
$reportPath=Join-Path $runDir 'report.json'
$stdout=Join-Path $runDir 'stdout.txt'
$stderr=Join-Path $runDir 'stderr.txt'
$last=Join-Path $runDir 'last_message.txt'
$allowedPath=Join-Path $runDir 'allowed.json'
$allowed=@()
if(Test-Path $allowedPath){ $allowed=@(Get-Content -Raw $allowedPath | ConvertFrom-Json) }
$task=Get-TaskText
$before=Snapshot-Files $RepoRoot
$boundary="`n`nGOVERNED OUTPUT BOUNDARY: modify/create only these repo-relative paths: "+($allowed -join ', ')+". Do not modify, create, delete, rename, commit, or push anything else. At the end write a concise completion summary."
$prompt=$task+$boundary
$env:CODEX_HOME=$CodexHome
$env:USERPROFILE='C:\Users\Azerbaijan'
$env:HOME=$env:USERPROFILE
$skipGit=@()
if(-not (Test-Path (Join-Path $RepoRoot '.git'))){ $skipGit=@('--skip-git-repo-check') }
$promptPath=Join-Path $runDir 'prompt.txt'
[IO.File]::WriteAllText($promptPath,$prompt,(New-Object Text.UTF8Encoding($false)))
$skipGitText=if($skipGit.Count){' --skip-git-repo-check'}else{''}
$cmdLine="exec$skipGitText --dangerously-bypass-approvals-and-sandbox -C `"$RepoRoot`" --output-last-message `"$last`" -"
$proc=Start-Process -FilePath 'cmd.exe' -ArgumentList @('/d','/s','/c',"type `"$promptPath`" | `"$CodexCmd`" $cmdLine") -PassThru -RedirectStandardOutput $stdout -RedirectStandardError $stderr
$timedOut=$false
try {
  Wait-Process -Id $proc.Id -Timeout $RuntimeLimitSeconds -ErrorAction Stop
} catch {
  $timedOut=$true
  try { taskkill /PID $proc.Id /T /F | Out-Null } catch {}
}
if(-not $timedOut){ $proc.WaitForExit(); $proc.Refresh() }
$exit=if($timedOut){124}else{[int]$proc.ExitCode}
$after=Snapshot-Files $RepoRoot
$changed=@($after.Keys | Where-Object { -not $before.ContainsKey($_) -or $before[$_] -ne $after[$_] }) + @($before.Keys | Where-Object { -not $after.ContainsKey($_) })
$changed=@($changed | Sort-Object -Unique)
$allowedNormalized=@($allowed | ForEach-Object { ([string]$_).Replace('\','/').TrimStart('/') })
$unexpected=@($changed | Where-Object { $_.Replace('\','/').TrimStart('/') -notin $allowedNormalized })
$validation=[ordered]@{changed=$changed;unexpected=$unexpected;boundary_pass=($unexpected.Count -eq 0)}
$status=if($timedOut){'TIMED_OUT'}elseif($exit -eq 0 -and $validation.boundary_pass){'COMPLETED_SUCCESS'}elseif($exit -eq 0){'COMPLETED_WITH_BOUNDARY_VIOLATION'}else{'COMPLETED_FAILED'}
$report=[ordered]@{run_id=$RunId;status=$status;repo_root=$RepoRoot;report_path=$reportPath;started_at=(Get-Item $reportPath).CreationTimeUtc.ToString('o');finished_at=(Get-Date).ToUniversalTime().ToString('o');exit_code=$exit;allowed_output=$allowed;validation=$validation;stdout_path=$stdout;stderr_path=$stderr;last_message_path=$last}
Write-JsonFile $reportPath $report
exit 0
