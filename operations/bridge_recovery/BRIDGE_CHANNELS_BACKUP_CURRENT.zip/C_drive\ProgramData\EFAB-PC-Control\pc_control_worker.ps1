param([Parameter(Mandatory=$true)][string]$RunDir)
$ErrorActionPreference='Stop'
$req=Get-Content (Join-Path $RunDir 'request.json') -Raw|ConvertFrom-Json
$stdout=Join-Path $RunDir 'stdout.txt';$stderr=Join-Path $RunDir 'stderr.txt';$resultPath=Join-Path $RunDir 'result.json'
$started=(Get-Date).ToUniversalTime()
$result=[ordered]@{run_id=$req.run_id;status='running';shell=$req.shell;cwd=$req.cwd;started_at=$started.ToString('o');finished_at=$null;exit_code=$null;timed_out=$false;error=$null}
$result|ConvertTo-Json -Depth 6|Set-Content $resultPath -Encoding UTF8
try{
 if($req.shell -eq 'powershell'){
   $encoded=[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes([string]$req.command))
   $exe='powershell.exe';$args=@('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-EncodedCommand',$encoded)
 }elseif($req.shell -eq 'python'){
   $candidates=@('C:\Users\Azerbaijan\AppData\Local\Programs\Python\Python314\python.exe','C:\Windows\py.exe')
   $exe=$candidates|Where-Object{Test-Path $_}|Select-Object -First 1
   if(-not$exe){throw 'PYTHON_NOT_FOUND'}
   $codePath=Join-Path $RunDir 'command.py'
   [IO.File]::WriteAllText($codePath,[string]$req.command,[Text.UTF8Encoding]::new($false))
   $args=@($codePath)
 }else{throw 'INVALID_SHELL'}
 $p=Start-Process $exe -ArgumentList $args -WorkingDirectory ([string]$req.cwd) -RedirectStandardOutput $stdout -RedirectStandardError $stderr -PassThru -WindowStyle Hidden
 [ordered]@{worker_pid=$PID;child_pid=$p.Id;started_at=$started.ToString('o')}|ConvertTo-Json|Set-Content (Join-Path $RunDir 'meta.json') -Encoding UTF8
 $deadline=(Get-Date).AddSeconds([int]$req.runtime_limit_seconds)
 while(-not$p.HasExited -and (Get-Date)-lt$deadline){Start-Sleep -Milliseconds 500;$p.Refresh()}
 if(-not$p.HasExited){
   & taskkill.exe /PID $p.Id /T /F | Out-Null
   $result.status='timed_out';$result.timed_out=$true
 }else{
   $p.WaitForExit()
   $p.Refresh()
   $exitCode=[int]$p.ExitCode
   $result.exit_code=$exitCode
   $result.status=if($exitCode -eq 0){'completed_success'}else{'completed_error'}
 }
}catch{
 $result.status='worker_error';$result.error=$_.Exception.Message
}
$result.finished_at=(Get-Date).ToUniversalTime().ToString('o')
$result|ConvertTo-Json -Depth 6|Set-Content $resultPath -Encoding UTF8
