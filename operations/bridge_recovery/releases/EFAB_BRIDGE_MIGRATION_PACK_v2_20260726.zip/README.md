﻿# EFAB BRIDGE MIGRATION PACK V2

Status: CURRENT_CONFIG_ARTIFACT / NEW-PC_INSTALL_NOT_PROVEN
Date: 2026-07-26

## Architecture

Channel A — Primary Work Bridge
- Primary API: 127.0.0.1:18788
- Recovery Gateway: 127.0.0.1:18787
- Public route: ngrok
- ngrok runs under SYSTEM with singleton launcher and watchdog
- Primary boot is idempotent and health-checked

Channel B — Independent Rescue Control Plane
- Local API: 127.0.0.1:18789
- Public route: Tailscale Funnel
- Separate token and SYSTEM lifecycle
- Can inspect/restart Primary Bridge and request machine reboot

## Proven on source PC

- Primary Bridge health PASS
- Recovery Gateway health PASS
- Rescue local/external health PASS
- ngrok kill/recovery drill PASS in 7 seconds
- full Windows reboot recovery PASS in 19 seconds
- post-reboot listeners: 18787, 18788, 18789, 4040

## Excluded

No tokens, credentials, ngrok authtoken, Tailscale identity, runtime logs, reports, or active runtime state are included.

## Required on target PC

- Python and package installation
- fresh Primary token
- fresh Rescue token
- ngrok authentication/config
- Tailscale login and Funnel enablement
- target path mapping if drives differ from H:\bridge and H:\efab
- task import/adaptation
- full validator and reboot drill

## Boundary

This archive captures the current working body and task definitions. It is not yet proof of one-command installation on a clean PC.
