﻿$ErrorActionPreference = "Continue"
$BridgeRoot = "H:\bridge"
$StartScript = Join-Path $BridgeRoot "start_gpt_action_bridge_dev.ps1"
$LogDir = Join-Path $BridgeRoot "public_watchdog_logs"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$Log = Join-Path $LogDir "efab_public_route_watchdog-$Stamp.log"
$LocalHealthUrl = "http://127.0.0.1:18787/health"
$PublicHealthUrl = "https://scabbed-corner-gap.ngrok-free.dev/health"
$NgrokApiUrl = "http://127.0.0.1:4040/api/tunnels"
$FailureCount = 0
$RestartCount = 0
$SleepSeconds = 60
$MinRestartGapSeconds = 300
$LastRestartUtc = [datetime]::MinValue

function Log([string]$m) {
    $line = "$(Get-Date -Format o) $m"
    Add-Content -Encoding UTF8 -Path $Log -Value $line
}

function Test-LocalHealth {
    try {
        $r = Invoke-RestMethod -Uri $LocalHealthUrl -TimeoutSec 8
        return ($r.ok -eq $true -and $r.status -eq "ok")
    } catch {
        Log "LOCAL_HEALTH_FAIL=$($_.Exception.Message)"
        return $false
    }
}

function Test-PublicHealth {
    try {
        $r = Invoke-WebRequest -Uri $PublicHealthUrl -Headers @{"ngrok-skip-browser-warning"="true"} -UseBasicParsing -TimeoutSec 20
        return ($r.StatusCode -eq 200 -and $r.Content -match '"ok"\s*:\s*true')
    } catch {
        Log "PUBLIC_HEALTH_FAIL=$($_.Exception.Message)"
        return $false
    }
}

function Test-NgrokProcess {
    try {
        $p = @(Get-CimInstance Win32_Process | Where-Object { $_.Name -eq "ngrok.exe" })
        if ($p.Count -lt 1) { Log "NGROK_PROCESS_MISSING"; return $false }
        return $true
    } catch {
        Log "NGROK_PROCESS_CHECK_FAIL=$($_.Exception.Message)"
        return $false
    }
}

function Test-NgrokTunnelConfig {
    try {
        $t = Invoke-RestMethod -Uri $NgrokApiUrl -TimeoutSec 5
        $addr = @($t.tunnels | ForEach-Object { $_.config.addr }) -join ","
        if ($addr -match "127.0.0.1:18787") { return $true }
        Log "NGROK_TUNNEL_ADDR_MISMATCH=$addr"
        return $false
    } catch {
        Log "NGROK_API_FAIL=$($_.Exception.Message)"
        return $false
    }
}

function Restart-BridgeRoute([string]$reason) {
    $now = (Get-Date).ToUniversalTime()
    if (($now - $LastRestartUtc).TotalSeconds -lt $MinRestartGapSeconds) {
        Log "RESTART_SKIPPED_COOLDOWN reason=$reason"
        return
    }
    if (-not (Test-Path -LiteralPath $StartScript)) {
        Log "START_SCRIPT_MISSING=$StartScript"
        return
    }
    $scriptOwners = @(Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match [regex]::Escape($StartScript) })
    if ($scriptOwners.Count -gt 0) {
        Log "RESTART_SKIPPED_START_SCRIPT_ALREADY_RUNNING count=$($scriptOwners.Count) reason=$reason"
        return
    }
    $LastRestartUtc = $now
    $RestartCount += 1
    Log "RESTART_BEGIN count=$RestartCount reason=$reason"
    try {
        Start-Process -FilePath "powershell.exe" -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File",$StartScript) -WindowStyle Minimized
        Log "RESTART_LAUNCHED"
    } catch {
        Log "RESTART_FAILED=$($_.Exception.Message)"
    }
}

Log "PUBLIC_WATCHDOG_BEGIN pid=$PID identity=$([Security.Principal.WindowsIdentity]::GetCurrent().Name)"
while ($true) {
    $localOk = Test-LocalHealth
    $ngrokProcOk = Test-NgrokProcess
    $tunnelOk = Test-NgrokTunnelConfig
    $publicOk = $false
    if ($localOk -and $ngrokProcOk -and $tunnelOk) {
        $publicOk = Test-PublicHealth
    }
    if ($localOk -and $ngrokProcOk -and $tunnelOk -and $publicOk) {
        if ($FailureCount -gt 0) { Log "ROUTE_RECOVERED previous_failures=$FailureCount" }
        $FailureCount = 0
        Log "ROUTE_OK local=$localOk ngrok=$ngrokProcOk tunnel=$tunnelOk public=$publicOk"
    } else {
        $FailureCount += 1
        Log "ROUTE_FAIL count=$FailureCount local=$localOk ngrok=$ngrokProcOk tunnel=$tunnelOk public=$publicOk"
        if ($FailureCount -ge 3) {
            Restart-BridgeRoute "route_fail local=$localOk ngrok=$ngrokProcOk tunnel=$tunnelOk public=$publicOk"
            $FailureCount = 0
        }
    }
    Start-Sleep -Seconds $SleepSeconds
}
