﻿# EF Bridge continuity entrypoint

Purpose: a new E-Factory Control GPT chat must not reconstruct tool invocation from conversation history.

## Required start sequence

1. Use GPT Action `getHealth`.
2. Use `checkContext` with `expected_root = H:\bridge`.
3. Run the read-only canonical snapshot:
   `powershell -NoProfile -ExecutionPolicy Bypass -File H:\bridge\src\invoke_ef_tool_v1.ps1 -Operation bridge.snapshot`
4. Read `H:\bridge\schemas\EF_BRIDGE_CAPABILITY_REGISTRY.v1.json` for invocation contracts.
5. Treat registry data as configuration, not runtime proof. Fresh probe wins over notebook/history.

## Critical execution-context rule

Primary/Recovery/Rescue/PC-Control scheduled infrastructure runs as SYSTEM. SYSTEM does not naturally inherit the interactive user's GitHub CLI or Codex profile. Never diagnose user credentials by relying on SYSTEM defaults.

Canonical user-tool binding:
- user profile: `C:\Users\Azerbaijan`
- Codex executable: `C:\Users\Azerbaijan\Tools\nodejs\node-v24.13.1-win-x64\codex.cmd`
- CODEX_HOME: `C:\Users\Azerbaijan\.codex`
- GitHub CLI config root: `C:\Users\Azerbaijan\AppData\Roaming\GitHub CLI`

Use the wrapper instead of reconstructing environment variables ad hoc.

## Security

Never print token-file contents, auth.json contents, X-Bridge-Token or X-Rescue-Token. Existence/status checks are allowed; secret disclosure is not.

## Current capability maturity boundary

`codex.status` and `codex.version` have a deterministic wrapper. `codex.run/resume/cancel/report` are not yet canonical Bridge capabilities and must not be claimed as implemented until built and validated.

## Repo separation

Canonical Bridge is `H:\bridge` and is local-only. Agent Builder is `H:\efab` / `e-factory-agent-builder`. Do not store canonical Bridge recovery implementation in Agent Builder repo.
