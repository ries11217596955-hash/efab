﻿$ErrorActionPreference='SilentlyContinue'
$Root='H:\bridge'
$Out=Join-Path $Root ('resilience_state\fault_ngrok_' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.json')
$start=Get-Date
$before=@(Get-Process ngrok -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id)
Start-Sleep 5
Get-Process ngrok -ErrorAction SilentlyContinue | Stop-Process -Force
$recovered=$false;$local=$false;$public=$false;$new=@()
for($i=0;$i -lt 36;$i++){
  Start-Sleep 5
  try{$h=Invoke-RestMethod 'http://127.0.0.1:18787/health' -TimeoutSec 4;$local=($h.ok -eq $true)}catch{$local=$false}
  try{$r=Invoke-WebRequest 'https://scabbed-corner-gap.ngrok-free.dev/health' -Headers @{'ngrok-skip-browser-warning'='true'} -UseBasicParsing -TimeoutSec 6;$public=($r.StatusCode -eq 200 -and $r.Content -match '"ok"\s*:\s*true')}catch{$public=$false}
  $new=@(Get-Process ngrok -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Id)
  if($local -and $public -and $new.Count -gt 0){$recovered=$true;break}
}
[ordered]@{test='kill_ngrok';started=$start.ToString('o');finished=(Get-Date).ToString('o');before_pids=$before;after_pids=$new;local=$local;public=$public;recovered=$recovered;elapsed_seconds=[math]::Round(((Get-Date)-$start).TotalSeconds,1)} | ConvertTo-Json -Depth 5 | Set-Content $Out -Encoding UTF8
