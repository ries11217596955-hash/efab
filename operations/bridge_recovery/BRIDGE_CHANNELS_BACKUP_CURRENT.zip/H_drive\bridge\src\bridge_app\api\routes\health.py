﻿from __future__ import annotations

import json
import socket
from datetime import datetime, timezone

from fastapi import APIRouter, Request

from bridge_app.core.models import CapabilityStatus, HealthResponse
from bridge_app.core.time import utc_now_iso

router = APIRouter(tags=["health"])


@router.get("/health", response_model=HealthResponse)
def get_health(request: Request) -> HealthResponse:
    settings = request.app.state.settings
    return HealthResponse(
        service=settings.service_name,
        version=settings.version,
        status="ok",
        timestamp=utc_now_iso(),
        capabilities=[
            CapabilityStatus(
                name="health",
                status="available",
                description="API health endpoint is implemented.",
            ),
            CapabilityStatus(
                name="repo_status",
                status="available",
                description="Read-only repository status detection is implemented.",
            ),
            CapabilityStatus(
                name="reports",
                status="available",
                description="JSON report writing and retrieval are implemented.",
            ),
            CapabilityStatus(
                name="terminal_run",
                status="available",
                description="Terminal execution is implemented as a managed-run wrapper.",
            ),
            CapabilityStatus(
                name="managed_run_lifecycle",
                status="available",
                description="Managed run start, status, wait, logs, stop, and kill endpoints are implemented.",
            ),
            CapabilityStatus(
                name="codex_handoff",
                status="not_implemented",
                description="Codex handoff is reserved for a later pass.",
            ),
            CapabilityStatus(
                name="progress_events",
                status="not_implemented",
                description="Long-running progress or event streaming is not implemented.",
            ),
        ],
    )



def _probe_writable(path):
    path.mkdir(parents=True, exist_ok=True)
    probe = path / ".deep_health_probe"
    try:
        probe.write_text("ok", encoding="utf-8")
        return probe.read_text(encoding="utf-8") == "ok"
    finally:
        try:
            probe.unlink()
        except FileNotFoundError:
            pass


def _port_open(host: str, port: int, timeout: float = 0.5) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


@router.get("/health/deep")
def get_deep_health(request: Request) -> dict:
    settings = request.app.state.settings
    reports_dir = settings.reports_dir
    runs_dir = settings.runs_dir
    checks = {}

    for name, path in (("reports_writable", reports_dir), ("runs_writable", runs_dir)):
        try:
            checks[name] = {"ok": _probe_writable(path), "path": str(path)}
        except OSError as exc:
            checks[name] = {"ok": False, "path": str(path), "error": type(exc).__name__}

    index_path = reports_dir / "index.json"
    index_size = index_path.stat().st_size if index_path.exists() else 0
    index_ok = True
    index_state = "missing" if not index_path.exists() else "compact"
    if index_path.exists() and index_size <= 5 * 1024 * 1024:
        try:
            json.loads(index_path.read_text(encoding="utf-8-sig"))
        except (OSError, json.JSONDecodeError):
            index_ok = False
            index_state = "invalid"
    elif index_size > 5 * 1024 * 1024:
        index_ok = False
        index_state = "oversized_guarded"
    checks["report_index"] = {"ok": index_ok, "state": index_state, "size_bytes": index_size}

    latest = None
    for result_path in runs_dir.glob("managed_run-*/result.json"):
        try:
            if latest is None or result_path.stat().st_mtime > latest.stat().st_mtime:
                latest = result_path
        except OSError:
            continue
    latest_info = {"ok": False, "state": "none"}
    if latest is not None:
        try:
            data = json.loads(latest.read_text(encoding="utf-8-sig"))
            age = max(0.0, (datetime.now(timezone.utc).timestamp() - latest.stat().st_mtime))
            latest_info = {"ok": data.get("status") == "completed_success", "run_id": data.get("run_id"), "status": data.get("status"), "age_seconds": round(age, 1)}
        except (OSError, json.JSONDecodeError):
            latest_info = {"ok": False, "state": "invalid"}
    checks["latest_managed_run"] = latest_info
    checks["recovery_gateway"] = {"ok": _port_open("127.0.0.1", 18787), "host": "127.0.0.1", "port": 18787}

    required = ("reports_writable", "runs_writable", "report_index", "recovery_gateway")
    ready = all(checks[name]["ok"] for name in required)
    return {"ok": ready, "service": settings.service_name, "version": settings.version, "grade": "READY" if ready else "DEGRADED", "timestamp": utc_now_iso(), "checks": checks}
