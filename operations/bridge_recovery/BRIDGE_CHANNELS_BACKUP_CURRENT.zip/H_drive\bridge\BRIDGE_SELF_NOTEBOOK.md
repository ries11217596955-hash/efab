﻿# BRIDGE_SELF_NOTEBOOK

Status: CURRENT_FIRST_READ
Updated: 2026-07-26 18:05 +04:00
Root: H:\bridge
Scope: Bridge Recovery only. Do not route to Agent Builder.

## Architecture

ngrok -> Recovery Gateway 127.0.0.1:18787 -> Primary Bridge 127.0.0.1:18788 -> terminal executor -> H:\bridge\reports

Gateway has local /health, /context/check and /terminal/run fallback handlers.

## Fresh proof

PROVEN_LIVE on 2026-07-26:
- health returned ok;
- checkContext returned actual_root=H:\bridge and command_allowed=true;
- read-only terminal commands completed;
- listeners: 18787 PID 11748, 18788 PID 4108;
- Machine BRIDGE_AUTH_TOKEN is present; value was not read;
- `EFAB Recovery Gateway SYSTEM` runs as SYSTEM about every minute, LastTaskResult=0;
- supervisor repeatedly logged primary=True gateway=True ngrok=1;
- at 14:02:21Z Primary /terminal/run timed out and Gateway fallback completed the command successfully;
- fresh git rev-parse/status show H:\bridge is not a Git repository;
- recovery scripts, proof and rollback backups exist.

NOT_PROVEN:
- reboot recovery;
- public URL recovery for every failure mode;
- no race or duplicate runtime;
- automatic reports/index.json repair;
- dependency-loss recovery;
- token rotation without outage;
- fully unattended recovery and no single point of failure.

## Current node map

| Node | Launch | Health/retry | Recovery owner | Logs | Current status |
|---|---|---|---|---|---|
| ngrok | recovery_supervisor.ps1 StartNgrok | process match; periodic task | SYSTEM supervisor | logs/ngrok*, supervisor.log | process count=1; external route not independently probed |
| Gateway :18787 | StartGateway | authenticated /health, 4s; periodic restart | SYSTEM supervisor | logs/gateway.jsonl + stdout/stderr | listener proven; fallback terminal proven |
| Primary :18788 | StartPrimary | authenticated /health, 4s; periodic restart | SYSTEM supervisor | primary stdout/stderr + reports | listener proven; one terminal timeout observed |
| terminal executor | Primary then Gateway fallback | request result | Primary/Gateway | reports + gateway.jsonl | normal and fallback read-only execution observed |
| reports/index.json | Bridge writer | JSON parsing | Primary | H:\bridge\reports | historical repair known; automatic repair not proven |

## Scheduled tasks

- EFAB Recovery Gateway SYSTEM: periodic `recovery_supervisor.ps1 -Once`, SYSTEM, last result 0.
- EFAB Bridge Boot SYSTEM: start_gpt_action_bridge_dev.ps1 at boot mechanism; last successful run 2026-07-20, reboot acceptance not proven.

## Existing assets

recovery_gateway.py; recovery_supervisor.ps1; install_task.ps1; switch_live.ps1; rollback.ps1; RECOVERY_CHANNEL_PROOF_20260725_060544.json; pre-switch process snapshot; two supervisor .bak files.

`recovery_gateway_v1\bridge_token.txt` exists. It is a protected credential surface. Never print or copy its value.

## Known incidents

- reports/index.json grew to ~146 MB with concatenated JSON; JSONDecodeError: Extra data. Historical repair preserved 6902 reports; trailing offset 145307994.
- ngrok errors: ERR_NGROK_6030, ERR_NGROK_3004, ERR_NGROK_3200.
- switch_live.ps1 previously broke access until manual recovery_supervisor.ps1 -Once.
- SYSTEM Python lacked typing_extensions.
- AUTH_NOT_CONFIGURED was resolved after Machine BRIDGE_AUTH_TOKEN was set.
- token may have appeared in process command line. Rotation is deferred by Owner.

## Protected surfaces

Active Gateway/Primary/ngrok processes; both scheduled tasks; Machine token and bridge_token.txt; reports/index.json; working recovery scripts/logs/proofs/backups.

Do not run switch_live.ps1, rotate token, stop all three layers, alter tasks, clean reports/runtime, delete recovery assets or start duplicate processes without explicit safe authority and rollback.

## Single points of failure found

1. Windows Task Scheduler/SYSTEM is the main recovery owner.
2. Primary and Gateway depend on one local Python/runtime environment.
3. External route depends on one ngrok config/account/path.
4. Shared token distribution spans env/file/process launch surfaces.
5. reports/index.json has no proven automatic integrity recovery.
6. Supervisor uses process-pattern/port-owner termination without proven ownership guard.
7. ngrok health is inferred from process presence, not external authenticated probe.

## Latest accepted point

Read-only audit captured current operation and a real Gateway fallback event without stopping live services.

## Next safe task

Complete read-only duplicate-process/task-overlap audit and reports/index.json parser/hash/count baseline. No destructive fault injection.

## 2026-08-07 — Cross-chat capability contract slice

STATUS: PARTIAL_ACCEPTED_SLICE

PROVEN:
- canonical Bridge root is H:\bridge and remains local-only;
- Primary Bridge terminal executes as NT AUTHORITY\SYSTEM;
- SYSTEM profile mismatch is the reason user-scoped Codex/GitHub defaults cannot be trusted;
- deterministic capability registry: H:\bridge\schemas\EF_BRIDGE_CAPABILITY_REGISTRY.v1.json;
- continuity entrypoint: H:\bridge\docs\EF_BRIDGE_CONTINUITY_ENTRYPOINT.md;
- canonical read-only helper: H:\bridge\src\invoke_ef_tool_v1.ps1;
- codex.status PASS when helper binds C:\Users\Azerbaijan\.codex and user profile explicitly;
- codex.version = codex-cli 0.142.5;
- Bridge listeners 18787/18788/18789/18790 were fresh-proven alive during this slice;
- local gh config is found at C:\Users\Azerbaijan\AppData\Roaming\GitHub CLI but current stored token is invalid.

NOT_PROVEN / NOT_IMPLEMENTED:
- codex.run/resume/cancel/report are not yet canonical Bridge capabilities;
- local gh authentication is not repaired yet;
- IRON_RECOVERY_PASS is not claimed.

NEW-CHAT RULE:
Do not reconstruct commands from chat memory. Run getHealth -> checkContext H:\bridge -> read AGENTS.md + docs/EF_BRIDGE_CONTINUITY_ENTRYPOINT.md -> use schemas/EF_BRIDGE_CAPABILITY_REGISTRY.v1.json and src/invoke_ef_tool_v1.ps1 for fresh proof.

SECURITY:
Never print bridge/rescue tokens, token files, or Codex auth.json contents.

## 2026-08-07 — GitHub auth repair + Codex run micro-trial

STATUS: PARTIAL_ACCEPTED_SLICE

PROVEN:
- Local gh authentication repaired for ries11217596955-hash; canonical github.status wrapper returns exit_code 0 and suppresses Token line.
- Independent GitHub API identity matched ries11217596955-hash.
- Existing live route /codex/runner/v0_1 and H:\bridge\codex_runner_v0_1.ps1 were reused; no second runner was created.
- Runner SYSTEM profile bug fixed: canonical Codex executable/profile are explicitly bound.
- workspace-write micro-trial: PREFLIGHT_PASS, but Codex sandbox child PowerShell failed with 0xC0000142 and apply_patch could not write; validator FAIL_NO_ALLOWED_CHANGE. Therefore workspace-write is NOT accepted.
- bypass micro-trial in isolated clean git lab: PREFLIGHT_PASS; Codex created exactly proof.txt with CODEX_BRIDGE_RUN_PASS; VALIDATOR_PASS; allowed_changes=[proof.txt]; unexpected_changes=[]; no commit.
- Proof run: H:\bridge\codex_runner_runs\codex_runner_v0_1-20260807-163545-3e965c53\report.json

CAPABILITY BOUNDARY:
- codex.run = LAB_PROVEN_BYPASS_ONLY, not general LIVE acceptance.
- codex.report = available as runner report for each run.
- codex.cancel = partial via outer managed-run stop/kill.
- codex.resume = not implemented as canonical Bridge capability.
- IRON_RECOVERY_PASS remains NOT_PROVEN.

NEW-CHAT RULE:
Use the capability registry. Do not rediscover Codex paths/profile from chat history. For Codex mutation, require repo context proof + runner PREFLIGHT_PASS + allowed outputs + validator. Do not use workspace-write under SYSTEM until separately repaired and revalidated.
