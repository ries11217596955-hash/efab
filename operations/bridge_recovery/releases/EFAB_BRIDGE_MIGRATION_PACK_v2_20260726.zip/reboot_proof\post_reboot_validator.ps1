﻿$ErrorActionPreference='SilentlyContinue'
$Root='C:\ProgramData\EFAB-Reboot-Proof'
$Proof=Join-Path $Root 'latest_reboot_proof.json'
$Start=(Get-Date)
$Boot=(Get-CimInstance Win32_OperatingSystem).LastBootUpTime
$result=[ordered]@{started_at=$Start.ToUniversalTime().ToString('o');boot_time=$Boot.ToUniversalTime().ToString('o');status='NOT_PROVEN';elapsed_seconds=$null;checks=$null;attempts=@()}
for($i=0;$i -lt 60;$i++){
  Start-Sleep 5
  $checks=[ordered]@{}
  $checks.tailscale_service=((Get-Service Tailscale -ErrorAction SilentlyContinue).Status -eq 'Running')
  foreach($port in 18787,18788,18789,4040){$checks["port_$port"]=[bool](Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue)}
  try{$bt=(Get-Content 'H:\bridge\recovery_gateway_v1\bridge_token.txt' -Raw).Trim();$checks.health_18787=[bool](Invoke-RestMethod 'http://127.0.0.1:18787/health' -Headers @{'X-Bridge-Token'=$bt} -TimeoutSec 4).ok}catch{$checks.health_18787=$false}
  try{$checks.health_18788=[bool](Invoke-RestMethod 'http://127.0.0.1:18788/health' -Headers @{'X-Bridge-Token'=$bt} -TimeoutSec 4).ok}catch{$checks.health_18788=$false}
  try{$rt=(Get-Content 'C:\ProgramData\EFAB-Rescue\rescue_token.txt' -Raw).Trim();$checks.health_18789=[bool](Invoke-RestMethod 'http://127.0.0.1:18789/health' -Headers @{Authorization="Bearer $rt"} -TimeoutSec 4).ok}catch{$checks.health_18789=$false}
  try{$checks.public_ngrok=((Invoke-WebRequest 'https://scabbed-corner-gap.ngrok-free.dev/health' -UseBasicParsing -TimeoutSec 8).StatusCode -eq 200)}catch{$checks.public_ngrok=$false}
  try{$checks.public_rescue=[bool](Invoke-RestMethod 'https://desktop-mqdqol3.tail9ebe04.ts.net/health' -Headers @{Authorization="Bearer $rt"} -TimeoutSec 8).ok}catch{$checks.public_rescue=$false}
  $result.attempts+=,[ordered]@{at=(Get-Date).ToUniversalTime().ToString('o');checks=$checks}
  $all=$true;foreach($v in $checks.Values){if(-not [bool]$v){$all=$false;break}}
  if($all){$result.status='PROVEN_LIVE_FULL_REBOOT_RECOVERY';$result.checks=$checks;break}
}
if($result.status -ne 'PROVEN_LIVE_FULL_REBOOT_RECOVERY'){$result.status='FAIL';$result.checks=$checks}
$result.elapsed_seconds=[int]((Get-Date)-$Start).TotalSeconds
$result|ConvertTo-Json -Depth 12|Set-Content -Encoding UTF8 $Proof
