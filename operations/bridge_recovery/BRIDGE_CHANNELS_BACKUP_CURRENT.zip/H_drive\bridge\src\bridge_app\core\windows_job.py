from __future__ import annotations

import ctypes
import subprocess
from ctypes import wintypes

JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x00002000
JOB_OBJECT_EXTENDED_LIMIT_INFORMATION = 9
JOB_OBJECT_BASIC_ACCOUNTING_INFORMATION = 1

class IO_COUNTERS(ctypes.Structure):
    _fields_ = [("ReadOperationCount", ctypes.c_ulonglong),("WriteOperationCount", ctypes.c_ulonglong),("OtherOperationCount", ctypes.c_ulonglong),("ReadTransferCount", ctypes.c_ulonglong),("WriteTransferCount", ctypes.c_ulonglong),("OtherTransferCount", ctypes.c_ulonglong)]

class BASIC_LIMIT(ctypes.Structure):
    _fields_ = [("PerProcessUserTimeLimit", ctypes.c_longlong),("PerJobUserTimeLimit", ctypes.c_longlong),("LimitFlags", wintypes.DWORD),("MinimumWorkingSetSize", ctypes.c_size_t),("MaximumWorkingSetSize", ctypes.c_size_t),("ActiveProcessLimit", wintypes.DWORD),("Affinity", ctypes.c_size_t),("PriorityClass", wintypes.DWORD),("SchedulingClass", wintypes.DWORD)]

class EXTENDED_LIMIT(ctypes.Structure):
    _fields_ = [("BasicLimitInformation", BASIC_LIMIT),("IoInfo", IO_COUNTERS),("ProcessMemoryLimit", ctypes.c_size_t),("JobMemoryLimit", ctypes.c_size_t),("PeakProcessMemoryUsed", ctypes.c_size_t),("PeakJobMemoryUsed", ctypes.c_size_t)]

class BASIC_ACCOUNTING(ctypes.Structure):
    _fields_ = [("TotalUserTime", ctypes.c_longlong),("TotalKernelTime", ctypes.c_longlong),("ThisPeriodTotalUserTime", ctypes.c_longlong),("ThisPeriodTotalKernelTime", ctypes.c_longlong),("TotalPageFaultCount", wintypes.DWORD),("TotalProcesses", wintypes.DWORD),("ActiveProcesses", wintypes.DWORD),("TotalTerminatedProcesses", wintypes.DWORD)]

_kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
_kernel32.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
_kernel32.CreateJobObjectW.restype = wintypes.HANDLE
_kernel32.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
_kernel32.SetInformationJobObject.restype = wintypes.BOOL
_kernel32.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
_kernel32.AssignProcessToJobObject.restype = wintypes.BOOL
_kernel32.QueryInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD, ctypes.c_void_p]
_kernel32.QueryInformationJobObject.restype = wintypes.BOOL
_kernel32.TerminateJobObject.argtypes = [wintypes.HANDLE, wintypes.UINT]
_kernel32.TerminateJobObject.restype = wintypes.BOOL
_kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
_kernel32.CloseHandle.restype = wintypes.BOOL

def _check(ok: object, label: str) -> None:
    if not ok:
        raise OSError(ctypes.get_last_error(), label)

class WindowsJob:
    def __init__(self, handle: int) -> None:
        self.handle = handle
        self.closed = False

    @classmethod
    def create(cls) -> "WindowsJob":
        handle = _kernel32.CreateJobObjectW(None, None)
        _check(handle, "CreateJobObjectW")
        job = cls(handle)
        limits = EXTENDED_LIMIT()
        limits.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        try:
            _check(_kernel32.SetInformationJobObject(handle, JOB_OBJECT_EXTENDED_LIMIT_INFORMATION, ctypes.byref(limits), ctypes.sizeof(limits)), "SetInformationJobObject")
        except Exception:
            job.close()
            raise
        return job

    def assign_process_handle(self, process_handle: int) -> None:
        _check(_kernel32.AssignProcessToJobObject(self.handle, wintypes.HANDLE(process_handle)), "AssignProcessToJobObject")

    def active_processes(self) -> int:
        if self.closed:
            return 0
        info = BASIC_ACCOUNTING()
        _check(_kernel32.QueryInformationJobObject(self.handle, JOB_OBJECT_BASIC_ACCOUNTING_INFORMATION, ctypes.byref(info), ctypes.sizeof(info), None), "QueryInformationJobObject")
        return int(info.ActiveProcesses)

    def terminate(self, exit_code: int = 1) -> None:
        if not self.closed:
            _check(_kernel32.TerminateJobObject(self.handle, exit_code), "TerminateJobObject")

    def close(self) -> None:
        if not self.closed:
            _kernel32.CloseHandle(self.handle)
            self.closed = True

CREATE_SUSPENDED = getattr(subprocess, "CREATE_SUSPENDED", 0x00000004)
PROCESS_SUSPEND_RESUME = 0x0800

_kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
_kernel32.OpenProcess.restype = wintypes.HANDLE
_kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
_kernel32.CloseHandle.restype = wintypes.BOOL
_ntdll = ctypes.WinDLL("ntdll", use_last_error=True)
_ntdll.NtResumeProcess.argtypes = [wintypes.HANDLE]
_ntdll.NtResumeProcess.restype = ctypes.c_long

def resume_process(pid: int) -> None:
    handle = _kernel32.OpenProcess(PROCESS_SUSPEND_RESUME, False, pid)
    _check(handle, "OpenProcess(PROCESS_SUSPEND_RESUME)")
    try:
        status = _ntdll.NtResumeProcess(handle)
        if status != 0:
            raise OSError(int(status), "NtResumeProcess")
    finally:
        _kernel32.CloseHandle(handle)
