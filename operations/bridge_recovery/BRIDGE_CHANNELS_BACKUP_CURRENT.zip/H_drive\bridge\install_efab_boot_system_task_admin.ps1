﻿$ErrorActionPreference = "Continue"
$Bridge = "H:\bridge"
$LogDir = Join-Path $Bridge "boot_task_logs"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$Log = Join-Path $LogDir ("install_boot_task_" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".log")
function Log([string]$m) { Add-Content -Encoding UTF8 -Path $Log -Value "$(Get-Date -Format o) $m" }
Log "BEGIN install EFAB Bridge Boot SYSTEM task"
try {
  $identity=[Security.Principal.WindowsIdentity]::GetCurrent()
  $principal=New-Object Security.Principal.WindowsPrincipal($identity)
  $isAdmin=$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
  Log "IDENTITY=$($identity.Name) IS_ADMIN=$isAdmin"
  $BootScript = "H:\bridge\efab_bridge_boot_start.ps1"
  $TaskName = "EFAB Bridge Boot SYSTEM"
  $Tr = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$BootScript`""
  schtasks.exe /Create /TN $TaskName /SC ONSTART /RU SYSTEM /RL HIGHEST /TR $Tr /F | ForEach-Object { Log "SCHTASKS_CREATE: $_" }
  schtasks.exe /Query /TN $TaskName /V /FO LIST | ForEach-Object { Log "SCHTASKS_QUERY: $_" }
  powercfg.exe /change standby-timeout-ac 0 | ForEach-Object { Log "POWERCFG_STANDBY_AC: $_" }
  powercfg.exe /change hibernate-timeout-ac 0 | ForEach-Object { Log "POWERCFG_HIBERNATE_AC: $_" }
  powercfg.exe /change monitor-timeout-ac 0 | ForEach-Object { Log "POWERCFG_MONITOR_AC: $_" }
  Log "END OK"
} catch {
  Log "ERROR=$($_.Exception.Message)"
}
Start-Process notepad.exe $Log
