﻿$ErrorActionPreference = "Continue"
$BridgeRoot = "H:\bridge"
$StartScript = Join-Path $BridgeRoot "start_gpt_action_bridge_dev.ps1"
$LogDir = Join-Path $BridgeRoot "watchdog_logs"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$Log = Join-Path $LogDir "efab_bridge_watchdog-$Stamp.log"
$HealthUrl = "http://127.0.0.1:18787/health"
$FailureCount = 0
$LastRestartUtc = [datetime]::MinValue
$MinRestartGapSeconds = 90
$SleepSeconds = 30

function Log([string]$m) {
    $line = "$(Get-Date -Format o) $m"
    Add-Content -Encoding UTF8 -Path $Log -Value $line
}

function BridgeHealthy {
    try {
        $r = Invoke-RestMethod -Uri $HealthUrl -TimeoutSec 5
        return ($r.ok -eq $true -and $r.status -eq "ok")
    } catch {
        Log "HEALTH_FAIL=$($_.Exception.Message)"
        return $false
    }
}

function StartBridge {
    if (-not (Test-Path -LiteralPath $StartScript)) {
        Log "START_SCRIPT_MISSING=$StartScript"
        return
    }
    $now = (Get-Date).ToUniversalTime()
    if (($now - $LastRestartUtc).TotalSeconds -lt $MinRestartGapSeconds) {
        Log "RESTART_SKIPPED_COOLDOWN"
        return
    }
    $LastRestartUtc = $now
    Log "RESTART_BEGIN"
    try {
        Start-Process -FilePath "powershell.exe" -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File",$StartScript) -WindowStyle Minimized
        Log "RESTART_LAUNCHED"
    } catch {
        Log "RESTART_FAILED=$($_.Exception.Message)"
    }
}

Log "WATCHDOG_BEGIN pid=$PID"
while ($true) {
    if (BridgeHealthy) {
        if ($FailureCount -ne 0) { Log "HEALTH_RECOVERED previous_failures=$FailureCount" }
        $FailureCount = 0
    } else {
        $FailureCount += 1
        Log "FAILURE_COUNT=$FailureCount"
        if ($FailureCount -ge 3) {
            StartBridge
            $FailureCount = 0
        }
    }
    Start-Sleep -Seconds $SleepSeconds
}

