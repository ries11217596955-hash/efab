﻿param(
  [ValidateSet('Audit','Delete')][string]$Mode='Audit',
  [int]$Days=5
)
$ErrorActionPreference='Stop'
$root='H:\bridge'
$runs=Join-Path $root 'runs'
$reports=Join-Path $root 'reports'
$proofDir=Join-Path $reports 'retention_proofs'
$lock=Join-Path $proofDir 'retention_v1.lock'
New-Item -ItemType Directory -Path $proofDir -Force|Out-Null
if(Test-Path $lock){$age=((Get-Date)-(Get-Item $lock).LastWriteTime).TotalMinutes;if($age -lt 120){throw 'RETENTION_LOCK_ACTIVE'}else{Remove-Item $lock -Force}}
Set-Content $lock ((Get-Date).ToUniversalTime().ToString('o')) -Encoding ascii
try {
  $cut=(Get-Date).AddDays(-$Days)
  $critical='proof|recovery|activation|rollback|checkpoint|salvage|corrupt|before_|legacy|index\.|retention_proofs'
  $active=@{}
  Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | ForEach-Object { if($_.CommandLine -match 'managed_run-\d{8}-\d{6}-[0-9a-f]+'){ $active[$Matches[0]]=$true } }
  $runCandidates=@()
  Get-ChildItem $runs -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    $id=$_.Name
    if($_.LastWriteTime -lt $cut -and -not $active.ContainsKey($id) -and $_.FullName -notmatch $critical){
      $size=(Get-ChildItem $_.FullName -Recurse -File -ErrorAction SilentlyContinue|Measure-Object Length -Sum).Sum
      $runCandidates += [pscustomobject]@{type='run_dir';path=$_.FullName;bytes=[int64]($size|ForEach-Object{if($_){$_}else{0}})}
    }
  }
  $reportCandidates=@()
  Get-ChildItem $reports -Recurse -File -ErrorAction SilentlyContinue | Where-Object {
    $_.LastWriteTime -lt $cut -and $_.FullName -notmatch $critical -and $_.Name -ne 'index.json'
  } | ForEach-Object { $reportCandidates += [pscustomobject]@{type='report_file';path=$_.FullName;bytes=[int64]$_.Length} }
  $candidates=@($runCandidates)+@($reportCandidates)
  $deleted=@(); $errors=@()
  if($Mode -eq 'Delete'){
    foreach($c in $runCandidates){try{Remove-Item -LiteralPath $c.path -Recurse -Force;$deleted+=$c}catch{$errors+=[pscustomobject]@{path=$c.path;error=$_.Exception.Message}}}
    foreach($c in $reportCandidates){try{if(Test-Path -LiteralPath $c.path){Remove-Item -LiteralPath $c.path -Force;$deleted+=$c}}catch{$errors+=[pscustomobject]@{path=$c.path;error=$_.Exception.Message}}}
    Get-ChildItem $reports -Recurse -Directory -ErrorAction SilentlyContinue | Sort-Object FullName -Descending | ForEach-Object {if(-not(Get-ChildItem $_.FullName -Force -ErrorAction SilentlyContinue)){Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue}}
  }
  $proof=[ordered]@{schema='bridge_retention_v1';mode=$Mode;days=$Days;cutoff=$cut.ToUniversalTime().ToString('o');active_run_ids=@($active.Keys);candidate_count=@($candidates).Count;candidate_bytes=($candidates|Measure-Object bytes -Sum).Sum;deleted_count=@($deleted).Count;deleted_bytes=($deleted|Measure-Object bytes -Sum).Sum;error_count=@($errors).Count;errors=$errors;protected_pattern=$critical;timestamp=(Get-Date).ToUniversalTime().ToString('o')}
  $name='retention_v1_'+$Mode.ToLower()+'_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'.json'
  $path=Join-Path $proofDir $name
  $proof|ConvertTo-Json -Depth 6|Set-Content $path -Encoding UTF8
  $proof.proof_path=$path
  $proof|ConvertTo-Json -Depth 6 -Compress
  if($errors.Count -gt 0){exit 2}
}
finally{Remove-Item $lock -Force -ErrorAction SilentlyContinue}
