# Local Bridge GPT Action Setup Report

STATUS: GPT_ACTION_SETUP_PENDING_OWNER

BLOCKER: PUBLIC_HTTPS_URL_REQUIRED

This pass prepared files only. It did not install a GPT Action, connect ChatGPT to Bridge, launch Codex, automate VS Code, or create Codex handoff.

## Prepared Files

- `docs/gpt_action/bridge_action.openapi.json`
- `docs/gpt_action/ACTION_SETUP_REPORT.md`

## What Owner Must Provide

Public HTTPS is required before ChatGPT can call Bridge. Localhost and `H:\bridge` alone are not reachable from ChatGPT.

Owner must expose the running Bridge API through an approved HTTPS route, tunnel, or reverse proxy, then replace this placeholder in the schema:

```text
https://REPLACE_WITH_PUBLIC_BRIDGE_URL
```

## GPT Action Import Steps

1. Open the GPT editor.
2. Go to Actions.
3. Paste or import `docs/gpt_action/bridge_action.openapi.json`.
4. Replace the server URL placeholder with the approved public HTTPS Bridge URL.
5. Configure authentication as API key.
6. Set the header name to `X-Bridge-Token`.
7. Provide the Bridge token value through the GPT Action secret/config UI only.

Do not commit the token value into the repository.

## GPT Preview Smoke Tests

After the GPT Action is configured by Owner, test these in GPT Preview:

1. `GET /health`
2. `POST /context/check` with `expected_root`
3. `POST /terminal/run` with a harmless command and `expected_root`

## What This Does Not Prove

- GPT Action is not installed yet.
- ChatGPT cannot call Bridge until Owner configures a public HTTPS URL and imports the action schema.
- Codex integration is not implemented.
