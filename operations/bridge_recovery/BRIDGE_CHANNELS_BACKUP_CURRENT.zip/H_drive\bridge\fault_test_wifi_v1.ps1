﻿$ErrorActionPreference='SilentlyContinue'
$Root='H:\bridge'
$Profile='ALHN-B803'
$Out=Join-Path $Root ('resilience_state\fault_wifi_' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.json')
$start=Get-Date
$before=(netsh wlan show interfaces | Out-String)
Start-Sleep 5
netsh wlan disconnect | Out-Null
Start-Sleep 30
netsh wlan connect name="$Profile" | Out-Null
$connected=$false;$local=$false;$public=$false;$ssid=$null
for($i=0;$i -lt 48;$i++){
  Start-Sleep 5
  $w=(netsh wlan show interfaces | Out-String)
  $connected=($w -match 'State\s*:\s*connected')
  if($w -match 'SSID\s*:\s*([^\r\n]+)'){$ssid=$matches[1].Trim()}
  try{$h=Invoke-RestMethod 'http://127.0.0.1:18787/health' -TimeoutSec 4;$local=($h.ok -eq $true)}catch{$local=$false}
  try{$r=Invoke-WebRequest 'https://scabbed-corner-gap.ngrok-free.dev/health' -Headers @{'ngrok-skip-browser-warning'='true'} -UseBasicParsing -TimeoutSec 6;$public=($r.StatusCode -eq 200 -and $r.Content -match '"ok"\s*:\s*true')}catch{$public=$false}
  if($connected -and $local -and $public){break}
}
[ordered]@{test='wifi_disconnect_reconnect';started=$start.ToString('o');finished=(Get-Date).ToString('o');profile=$Profile;connected=$connected;ssid=$ssid;local=$local;public=$public;recovered=($connected -and $local -and $public);elapsed_seconds=[math]::Round(((Get-Date)-$start).TotalSeconds,1)} | ConvertTo-Json -Depth 5 | Set-Content $Out -Encoding UTF8
