﻿# NEXT CHAT START HERE — GPT Action Bridge dev route

Status as of 2026-06-25:

- Bridge repo/tooling root: H:\bridge
- Real working target repo: C:\Users\Azerbaijan\Downloads\e-factory-agent-builder
- Target repo last proven context:
  - branch: thin-control
  - head: 127057c
  - dirty: false
- GPT Action public route uses ngrok:
  - GPT Action auth type: API key / Custom
  - Header name: ngrok-skip-browser-warning
  - Header value: true
- Do NOT put X-Bridge-Token into GPT Action.
- Local ngrok process injects X-Bridge-Token upstream.

Recovery after PC restart:

```powershell
cd H:\bridge
.\start_gpt_action_bridge_dev.ps1
```

Stop route:

```powershell
cd H:\bridge
.\stop_gpt_action_bridge_dev.ps1
```

After start script prints:

- PublicUrl
- SchemaPath
- ReportPath
- Header name/value for GPT Action

If the ngrok public URL changed, copy the generated SchemaPath JSON into GPT Action schema.

Persistence boundary:

- PROVEN_LOCAL: recovery scripts exist in H:\bridge.
- PROVEN_LIVE on 2026-06-25: getHealth, checkContext, runTerminal worked through GPT Action.
- NOT_PROVEN_PERSISTENT: GPT editor showed "Ошибка при сохранении черновика"; after refresh/update the GPT settings may need retest.

Next-chat instruction for assistant:

1. Do not assume GPT Action still works.
2. First test getHealth.
3. If getHealth fails, ask Owner to run:
   cd H:\bridge
   .\start_gpt_action_bridge_dev.ps1
4. Then test checkContext for H:\bridge.
5. Then test target repo context:
   expected_root = C:\Users\Azerbaijan\Downloads\e-factory-agent-builder
   cwd = C:\Users\Azerbaijan\Downloads\e-factory-agent-builder
6. Do not mutate target repo until context is READY and Owner authorizes task scope.
