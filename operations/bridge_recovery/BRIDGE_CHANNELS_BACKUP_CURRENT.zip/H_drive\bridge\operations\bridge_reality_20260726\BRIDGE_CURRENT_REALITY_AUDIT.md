﻿# BRIDGE CURRENT REALITY AUDIT — 2026-07-26

Status: PROVEN_LIVE_FOR_OBSERVED_FACTS

## Observed live topology

- Primary Bridge: uvicorn `bridge_app.main:app`, localhost `127.0.0.1:18788`.
- Recovery Gateway: Python process on `127.0.0.1:18787`, upstream points to primary Bridge `127.0.0.1:18788`.
- ngrok publishes the Recovery Gateway and injects the same Bridge token.
- Emergency Channel: PowerShell process from `H:\bridge\emergency_channel_v1\emergency_gateway.ps1`.
- Scheduled tasks:
  - `EFAB Bridge Boot SYSTEM`: last result `1` (failure).
  - `EFAB Emergency Channel SYSTEM`: running.
  - `EFAB Recovery Gateway SYSTEM`: runs each minute, last result `0`.
- Tailscale listener observed on `127.0.0.1:18789` under PID 4.

## Root cause

The system has multiple recovery layers but not two independent control channels.

Primary Bridge, Recovery Gateway, Emergency Channel, scheduled tasks and their files all live on the same Windows host and mostly on `H:\bridge`. Failure of the host, disk, Windows task subsystem, shared token/config, network stack or common startup chain can remove every path at once.

Recovery Gateway is a proxy/supervisor around the primary Bridge, not an independent machine-control plane. Its upstream is the primary Bridge. Therefore it cannot guarantee control when the primary Bridge or its common dependencies are unavailable.

## Required architecture

Channel A — Primary Work Bridge:
- repo/files/terminal/process operations;
- normal GPT work;
- may evolve frequently.

Channel B — Independent Rescue Control Plane:
- separate process and codebase;
- separate port and external tunnel/account/route;
- separate token and minimal command set;
- installed outside `H:\bridge` (preferably `C:\ProgramData\EFAB-Rescue`);
- starts as Windows service under SYSTEM, not through the primary Bridge scripts;
- can query health, restart/start/stop primary Bridge, reboot PC, inspect last logs, rotate/recreate primary tunnel;
- never proxies through primary Bridge;
- immutable/minimal and updated rarely;
- heartbeat from outside the PC.

## Acceptance proof

PASS requires destructive fault drills:
1. Kill primary Bridge process; Channel B remains reachable and restarts it.
2. Break primary Bridge config/token; Channel B remains reachable and reports exact failure.
3. Disable primary scheduled task; Channel B restores service.
4. Kill primary ngrok tunnel; Channel B remains reachable through a different route.
5. Reboot Windows remotely through Channel B; Channel B returns after boot and then restores Channel A.
6. Archive/docs can reconstruct current topology without secrets.

## Immediate risk

`EFAB Bridge Boot SYSTEM` last result is `1`. Current primary Bridge is live only because another process chain started it. Boot recovery is therefore NOT_PROVEN.

## Boundary

This audit does not prove the rescue channel is independent or reboot-capable. It proves the current channels share failure domains and that boot task has a recorded failure.
