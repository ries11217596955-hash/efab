﻿You are running as a bounded Codex CLI canary from Bridge.
Create exactly one file in repo root named CODEX_CLI_CANARY_RESULT.md.
Do not edit any other files. Do not commit. Do not run long tests.
File content exactly:
STATUS: CODEX_CLI_CANARY_DONE
READ_TASK: YES
RESULT_CREATED_BY: CODEX_CLI
REPO_PATH: C:\Users\Azerbaijan\Downloads\e-factory-agent-builder
NOTE: Bridge controlled Codex through codex exec, not mouse UI.
