﻿$ErrorActionPreference='Stop'
$Root='H:\bridge'
$Dir=Join-Path $Root 'recovery_gateway_v1'
$backup=Join-Path $Dir ('pre_switch_processes_'+(Get-Date -Format yyyyMMdd_HHmmss)+'.json')
Get-CimInstance Win32_Process | Where-Object {$_.CommandLine -match 'bridge|ngrok|supervisor|watchdog'} | Select-Object Name,ProcessId,ParentProcessId,CommandLine | ConvertTo-Json -Depth 4 | Set-Content $backup -Encoding UTF8
$oldPatterns=@('efab_supervisor_keeper_v1\.ps1','efab_resilience_supervisor_v3\.ps1','efab_bridge_supervisor_v1\.ps1','efab_public_route_watchdog\.ps1','uvicorn bridge_app\.main:app.*--port 18787','ngrok\.exe.*127\.0\.0\.1:18787')
foreach($pattern in $oldPatterns){Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {$_.CommandLine -match $pattern -and $_.ProcessId -ne $PID} | ForEach-Object {Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue}}
Start-Sleep 3
powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Dir 'recovery_supervisor.ps1') -Once
if($LASTEXITCODE -ne 0){throw 'RECOVERY_SWITCH_START_FAILED'}
powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Dir 'install_task.ps1')
Start-ScheduledTask -TaskName 'EFAB Recovery Gateway SYSTEM'
Start-Sleep 5
$token=(Get-Content (Join-Path $Dir 'bridge_token.txt') -Raw).Trim();$h=@{'X-Bridge-Token'=$token}
$g=Invoke-RestMethod 'http://127.0.0.1:18787/health' -Headers $h -TimeoutSec 8
$p=Invoke-RestMethod 'http://127.0.0.1:18788/health' -Headers $h -TimeoutSec 8
[ordered]@{SWITCH_OK=$true;gateway_status=$g.status;primary_status=$p.status;task_state=(Get-ScheduledTask -TaskName 'EFAB Recovery Gateway SYSTEM').State;backup=$backup}|ConvertTo-Json -Depth 4
