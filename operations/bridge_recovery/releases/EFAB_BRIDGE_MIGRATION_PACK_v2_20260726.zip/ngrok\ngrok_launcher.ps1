﻿$ErrorActionPreference='Stop'
$Root='C:\ProgramData\EFAB-Ngrok'
$Ngrok='C:\Windows\ngrok.exe'
$Config=Join-Path $Root 'ngrok.yml'
$BridgeTokenPath='C:\ProgramData\EFAB\bridge_action_token.txt'
$Log=Join-Path $Root 'launcher.log'
$Mutex=New-Object Threading.Mutex($false,'Global\EFAB_NGROK_PRIMARY_SINGLETON')
if(-not $Mutex.WaitOne(0,$false)){
  Add-Content -Path $Log -Value (([ordered]@{ts=(Get-Date).ToUniversalTime().ToString('o');event='duplicate_launcher_exit';data=@{}})|ConvertTo-Json -Compress) -Encoding UTF8
  exit 0
}
function Log($event,$data){$row=[ordered]@{ts=(Get-Date).ToUniversalTime().ToString('o');event=$event;data=$data};Add-Content -Path $Log -Value ($row|ConvertTo-Json -Compress -Depth 5) -Encoding UTF8}
try{
  while($true){
    try{
      if(Get-Process ngrok -ErrorAction SilentlyContinue){Log 'ngrok_already_running' @{};Start-Sleep 10;continue}
      $token=(Get-Content $BridgeTokenPath -Raw).Trim()
      if([string]::IsNullOrWhiteSpace($token)){throw 'EMPTY_BRIDGE_TOKEN'}
      Log 'ngrok_start' @{}
      & $Ngrok http http://127.0.0.1:18787 --config $Config --log (Join-Path $Root 'ngrok.log') --log-format json --request-header-add "X-Bridge-Token:$token"
      Log 'ngrok_exit' @{exit_code=$LASTEXITCODE}
    }catch{Log 'launcher_error' @{error=$_.Exception.Message}}
    Start-Sleep 5
  }
}finally{$Mutex.ReleaseMutex();$Mutex.Dispose()}
