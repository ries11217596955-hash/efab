﻿$ErrorActionPreference='Continue'
Stop-ScheduledTask -TaskName 'EFAB Recovery Gateway SYSTEM' -ErrorAction SilentlyContinue
Unregister-ScheduledTask -TaskName 'EFAB Recovery Gateway SYSTEM' -Confirm:$false -ErrorAction SilentlyContinue
Get-CimInstance Win32_Process | Where-Object {$_.CommandLine -match 'recovery_gateway\.py|recovery_supervisor\.ps1|uvicorn bridge_app\.main:app.*--port 18788|ngrok\.exe.*127\.0\.0\.1:18787'} | ForEach-Object {if($_.ProcessId -ne $PID){Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue}}
Start-Sleep 3
powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'H:\bridge\start_gpt_action_bridge_dev.ps1'
