﻿param(
  [string]$Root = "H:\bridge",
  [int]$Port = 18787,
  [string]$TokenPath = "$env:USERPROFILE\.bridge\bridge_action_token.txt"
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Write-Step([string]$Message) { Write-Host "[bridge-dev] $Message" }

function Test-LocalBridgeHealth([int]$CheckPort, [int]$Retries = 1, [int]$SleepSeconds = 1) {
  for ($i = 0; $i -lt $Retries; $i++) {
    try {
      $r = Invoke-WebRequest "http://127.0.0.1:$CheckPort/health" -UseBasicParsing -TimeoutSec 10
      if ($r.StatusCode -eq 200 -and $r.Content -match "Local Bridge") {
        return [pscustomobject]@{ ok = $true; status_code = $r.StatusCode; error = $null }
      }
      $last = "unexpected local health response: status=$($r.StatusCode)"
    } catch { $last = $_.Exception.Message }
    if ($i -lt ($Retries - 1)) { Start-Sleep -Seconds $SleepSeconds }
  }
  return [pscustomobject]@{ ok = $false; status_code = $null; error = $last }
}

function Get-NgrokPublicUrl() {
  try {
    $t = Invoke-RestMethod "http://127.0.0.1:4040/api/tunnels" -TimeoutSec 5
    return ($t.tunnels | Where-Object { $_.public_url -like "https://*" } | Select-Object -First 1).public_url
  } catch { return $null }
}

function Test-PublicBridgeHealth([string]$Url) {
  if ([string]::IsNullOrWhiteSpace($Url)) {
    return [pscustomobject]@{ ok = $false; status_code = $null; error = "public url missing" }
  }
  try {
    $headers = @{ "ngrok-skip-browser-warning" = "true" }
    $r = Invoke-WebRequest "$Url/health" -UseBasicParsing -TimeoutSec 20 -Headers $headers
    if ($r.StatusCode -eq 200 -and $r.Content -match "Local Bridge") {
      return [pscustomobject]@{ ok = $true; status_code = $r.StatusCode; error = $null }
    }
    return [pscustomobject]@{ ok = $false; status_code = $r.StatusCode; error = "unexpected public health response" }
  } catch {
    return [pscustomobject]@{ ok = $false; status_code = $null; error = $_.Exception.Message }
  }
}

function Write-RouteReport([string]$ReportPath, [string]$Status, [string]$PublicUrl, [string]$SchemaPath, [string]$RunDir, $BridgeProc, $NgrokProc, $LocalHealth, $PublicHealth, [string]$InitialError) {
  $report = [ordered]@{
    status = $Status
    public_url = $PublicUrl
    schema_path = $SchemaPath
    run_dir = $RunDir
    bridge_pid = if ($BridgeProc) { $BridgeProc.Id } else { $null }
    ngrok_pid = if ($NgrokProc) { $NgrokProc.Id } else { $null }
    auth_type = "API key / Custom"
    gpt_action_header_name = "ngrok-skip-browser-warning"
    gpt_action_header_value = "true"
    bridge_token_injected_by_ngrok = $true
    token_value_written_to_report = $false
    local_health_ok = $LocalHealth.ok
    local_health_status = $LocalHealth.status_code
    public_health_ok = $PublicHealth.ok
    public_health_status = $PublicHealth.status_code
    initial_error = $InitialError
    exit_rule = "exit 0 when final local Bridge health is proven; public health is reported separately for watchdog recovery"
    patched_marker = "FINAL_HEALTH_EXIT_RULE_V1"
  }
  $report | ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 $ReportPath
}

if (-not (Test-Path $Root)) { throw "Root not found: $Root" }
if (-not (Test-Path $TokenPath)) { throw "Token file not found: $TokenPath" }

$Token = (Get-Content $TokenPath -Raw).Trim()
if ([string]::IsNullOrWhiteSpace($Token)) { throw "Token file is empty: $TokenPath" }

$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$RunDir = Join-Path $Root "reports\gpt_action_bridge_dev_$Stamp"
New-Item -ItemType Directory -Force -Path $RunDir | Out-Null

$BridgeOut = Join-Path $RunDir "bridge.out.txt"
$BridgeErr = Join-Path $RunDir "bridge.err.txt"
$NgrokOut = Join-Path $RunDir "ngrok.out.txt"
$NgrokErr = Join-Path $RunDir "ngrok.err.txt"
$BridgePs1 = Join-Path $RunDir "start_bridge_server.ps1"
$SchemaPath = Join-Path $RunDir "bridge_action.openapi.gpt_ngrok_inject_31.json"
$ReportPath = Join-Path $RunDir "route_report.json"

$BridgeProc = $null
$NgrokProc = $null
$PublicUrl = $null
$InitialError = $null

try {
  Write-Step "stopping old ngrok and port $Port owners"
  Stop-Process -Name ngrok -Force -ErrorAction SilentlyContinue
  Get-NetTCPConnection -LocalPort $Port -ErrorAction SilentlyContinue |
    Select-Object -ExpandProperty OwningProcess -Unique |
    Where-Object { $_ -ne 0 } |
    ForEach-Object { Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue }

  @"
Set-Location '$Root'
`$env:PYTHONPATH = '$Root\src'
`$env:BRIDGE_AUTH_TOKEN = (Get-Content '$TokenPath' -Raw).Trim()
python -m uvicorn bridge_app.main:app --host 127.0.0.1 --port $Port
"@ | Set-Content -Encoding UTF8 $BridgePs1

  Write-Step "starting Bridge on 127.0.0.1:$Port"
  $BridgeProc = Start-Process powershell -WindowStyle Hidden -ArgumentList "-NoProfile","-ExecutionPolicy","Bypass","-File",$BridgePs1 -RedirectStandardOutput $BridgeOut -RedirectStandardError $BridgeErr -PassThru

  $Local = Test-LocalBridgeHealth -CheckPort $Port -Retries 30 -SleepSeconds 1
  if (-not $Local.ok) { throw "Local Bridge health failed: $($Local.error)" }

  Write-Step "starting ngrok with local Bridge token injection"
  $NgrokProc = Start-Process ngrok -WindowStyle Hidden -ArgumentList "http","http://127.0.0.1:$Port","--log=stdout","--request-header-add","X-Bridge-Token:$Token" -RedirectStandardOutput $NgrokOut -RedirectStandardError $NgrokErr -PassThru

  for ($i = 0; $i -lt 60; $i++) {
    Start-Sleep -Seconds 1
    $PublicUrl = Get-NgrokPublicUrl
    if ($PublicUrl) { break }
  }
  if (-not $PublicUrl) { throw "ngrok public URL not found" }

  $PublicHealth = Test-PublicBridgeHealth -Url $PublicUrl
  if (-not $PublicHealth.ok) { throw "Public health failed: $($PublicHealth.error)" }

  $Headers = @{ "ngrok-skip-browser-warning" = "true" }
  $ContextBody = @{ expected_root = $Root; cwd = $Root } | ConvertTo-Json
  $Context = Invoke-WebRequest "$PublicUrl/context/check" -Method POST -UseBasicParsing -TimeoutSec 20 -Headers $Headers -ContentType "application/json" -Body $ContextBody
  if ($Context.StatusCode -ne 200 -or $Context.Content -notmatch "READY") { throw "Context check failed" }

  $Schema = @"
{
  "openapi": "3.1.0",
  "info": { "title": "Local Bridge GPT Action", "version": "0.7.3-dev" },
  "servers": [ { "url": "$PublicUrl" } ],
  "paths": {
    "/health": { "get": { "operationId": "getHealth", "summary": "Check Bridge health", "security": [ { "NgrokBypass": [] } ], "responses": { "200": { "description": "Bridge health" } } } },
    "/context/check": { "post": { "operationId": "checkContext", "summary": "Check Bridge context", "security": [ { "NgrokBypass": [] } ], "requestBody": { "required": true, "content": { "application/json": { "schema": { "type": "object", "required": ["expected_root"], "properties": { "expected_root": { "type": "string" }, "cwd": { "type": "string" } } } } } }, "responses": { "200": { "description": "Context check result" } } } },
    "/terminal/run": { "post": { "operationId": "runTerminal", "summary": "Run terminal command through Bridge", "security": [ { "NgrokBypass": [] } ], "requestBody": { "required": true, "content": { "application/json": { "schema": { "type": "object", "required": ["command", "expected_root"], "properties": { "command": { "type": "string" }, "expected_root": { "type": "string" }, "shell": { "type": "string", "enum": ["powershell", "pwsh", "cmd"] }, "cwd": { "type": "string" }, "wait_timeout_seconds": { "type": "integer" }, "runtime_limit_seconds": { "type": "integer" } } } } } }, "responses": { "200": { "description": "Terminal run result" }, "409": { "description": "Context mismatch" } } } }
  },
  "components": { "schemas": {}, "securitySchemes": { "NgrokBypass": { "type": "apiKey", "in": "header", "name": "ngrok-skip-browser-warning" } } }
}
"@
  $Schema | Set-Content -Encoding UTF8 $SchemaPath

  Write-RouteReport -ReportPath $ReportPath -Status "READY_PROVEN_LOCAL_AND_PUBLIC" -PublicUrl $PublicUrl -SchemaPath $SchemaPath -RunDir $RunDir -BridgeProc $BridgeProc -NgrokProc $NgrokProc -LocalHealth $Local -PublicHealth $PublicHealth -InitialError $null

  Write-Host ""
  Write-Host "BRIDGE_GPT_ACTION_DEV_ROUTE_READY_PROVEN"
  Write-Host "PublicUrl: $PublicUrl"
  Write-Host "SchemaPath: $SchemaPath"
  Write-Host "ReportPath: $ReportPath"
  Write-Host "GPTActionAuthType: API key / Custom"
  Write-Host "GPTActionHeaderName: ngrok-skip-browser-warning"
  Write-Host "GPTActionHeaderValue: true"
  Write-Host "BridgePid: $($BridgeProc.Id)"
  Write-Host "NgrokPid: $($NgrokProc.Id)"
  Write-Host "RunDir: $RunDir"
  Write-Host "PatchedExitRule: FINAL_HEALTH_EXIT_RULE_V1"
  Write-Host "NOTE: This is a dev route. Keep the public URL private."
  exit 0
} catch {
  $InitialError = $_.Exception.Message
  Write-Step "initial start path failed; checking final health before choosing exit code"
  Write-Step "initial error captured in report; token is not written to report"

  $Local = Test-LocalBridgeHealth -CheckPort $Port -Retries 10 -SleepSeconds 1
  $PublicUrl = Get-NgrokPublicUrl
  $PublicHealth = Test-PublicBridgeHealth -Url $PublicUrl

  if ($Local.ok) {
    $status = if ($PublicHealth.ok) { "READY_PROVEN_BY_FINAL_HEALTH_FALLBACK" } else { "LOCAL_READY_PUBLIC_PENDING" }
    Write-RouteReport -ReportPath $ReportPath -Status $status -PublicUrl $PublicUrl -SchemaPath $SchemaPath -RunDir $RunDir -BridgeProc $BridgeProc -NgrokProc $NgrokProc -LocalHealth $Local -PublicHealth $PublicHealth -InitialError $InitialError
    Write-Host "BRIDGE_START_FINAL_HEALTH_OK"
    Write-Host "Status: $status"
    Write-Host "ReportPath: $ReportPath"
    Write-Host "PatchedExitRule: FINAL_HEALTH_EXIT_RULE_V1"
    exit 0
  }

  Write-RouteReport -ReportPath $ReportPath -Status "FAILED_FINAL_HEALTH" -PublicUrl $PublicUrl -SchemaPath $SchemaPath -RunDir $RunDir -BridgeProc $BridgeProc -NgrokProc $NgrokProc -LocalHealth $Local -PublicHealth $PublicHealth -InitialError $InitialError
  Write-Host "BRIDGE_START_FINAL_HEALTH_FAILED"
  Write-Host "ReportPath: $ReportPath"
  Write-Host "PatchedExitRule: FINAL_HEALTH_EXIT_RULE_V1"
  exit 1
}
