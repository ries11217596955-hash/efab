from __future__ import annotations

import hashlib
import os
from pathlib import Path
from typing import Any

from bridge_app.core.errors import BridgeError


def resolve_path(root: Path, raw_path: str) -> Path:
    root = root.resolve()
    candidate = Path(raw_path)
    if not candidate.is_absolute():
        candidate = root / candidate
    candidate = candidate.resolve()
    try:
        candidate.relative_to(root)
    except ValueError as exc:
        raise BridgeError("PATH_OUTSIDE_ROOT", "Path is outside Bridge root.", 403, {"path": raw_path}) from exc
    return candidate


def checksum_file(path: Path, algorithm: str = "sha256") -> str:
    try:
        digest = hashlib.new(algorithm)
    except ValueError as exc:
        raise BridgeError("INVALID_CHECKSUM_ALGORITHM", "Unsupported checksum algorithm.", 400, {"algorithm": algorithm}) from exc
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def stat_path(root: Path, raw_path: str) -> dict[str, Any]:
    path = resolve_path(root, raw_path)
    if not path.exists():
        raise BridgeError("PATH_NOT_FOUND", "Path does not exist.", 404, {"path": raw_path})
    info = path.stat()
    return {
        "path": str(path),
        "relative_path": str(path.relative_to(root.resolve())),
        "exists": True,
        "is_file": path.is_file(),
        "is_dir": path.is_dir(),
        "size": info.st_size,
        "modified_ns": info.st_mtime_ns,
    }


def read_range(root: Path, raw_path: str, offset: int = 0, length: int = 65536) -> dict[str, Any]:
    if offset < 0 or length < 1 or length > 1024 * 1024:
        raise BridgeError("INVALID_RANGE", "offset must be >= 0 and length must be 1..1048576.", 400)
    path = resolve_path(root, raw_path)
    if not path.is_file():
        raise BridgeError("FILE_NOT_FOUND", "File does not exist.", 404, {"path": raw_path})
    size = path.stat().st_size
    with path.open("rb") as handle:
        handle.seek(offset)
        data = handle.read(length)
    end = offset + len(data)
    return {
        "path": str(path),
        "offset": offset,
        "length": len(data),
        "size": size,
        "eof": end >= size,
        "next_token": None if end >= size else str(end),
        "content": data.decode("utf-8", errors="replace"),
        "checksum_sha256": checksum_file(path),
    }


def write_file(root: Path, raw_path: str, content: str, expected_checksum: str | None = None) -> dict[str, Any]:
    path = resolve_path(root, raw_path)
    if path.exists() and path.is_dir():
        raise BridgeError("PATH_IS_DIRECTORY", "Cannot write a directory.", 400, {"path": raw_path})
    if expected_checksum is not None:
        if not path.exists():
            raise BridgeError("CHECKSUM_MISMATCH", "Expected existing file but path is absent.", 409)
        actual = checksum_file(path)
        if actual != expected_checksum:
            raise BridgeError("CHECKSUM_MISMATCH", "File changed since it was read.", 409, {"expected": expected_checksum, "actual": actual})
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".bridge-tmp")
    temp.write_text(content, encoding="utf-8", newline="")
    os.replace(temp, path)
    return stat_path(root, str(path)) | {"checksum_sha256": checksum_file(path)}


def apply_replacements(root: Path, raw_path: str, replacements: list[dict[str, str]], expected_checksum: str) -> dict[str, Any]:
    path = resolve_path(root, raw_path)
    if not path.is_file():
        raise BridgeError("FILE_NOT_FOUND", "File does not exist.", 404, {"path": raw_path})
    actual = checksum_file(path)
    if actual != expected_checksum:
        raise BridgeError("CHECKSUM_MISMATCH", "File changed since it was read.", 409, {"expected": expected_checksum, "actual": actual})
    text = path.read_text(encoding="utf-8")
    for index, item in enumerate(replacements):
        old = item.get("old", "")
        new = item.get("new", "")
        count = text.count(old)
        if not old or count != 1:
            raise BridgeError("PATCH_CONTEXT_MISMATCH", "Each patch context must match exactly once.", 409, {"index": index, "matches": count})
        text = text.replace(old, new, 1)
    return write_file(root, str(path), text, expected_checksum=actual)


def list_dir(root: Path, raw_path: str = ".", recursive: bool = False, limit: int = 1000) -> dict[str, Any]:
    path = resolve_path(root, raw_path)
    if not path.is_dir():
        raise BridgeError("DIRECTORY_NOT_FOUND", "Directory does not exist.", 404, {"path": raw_path})
    iterator = path.rglob("*") if recursive else path.iterdir()
    entries = []
    for item in iterator:
        entries.append({"path": str(item.relative_to(root.resolve())), "is_file": item.is_file(), "is_dir": item.is_dir(), "size": item.stat().st_size if item.is_file() else None})
        if len(entries) >= limit:
            break
    return {"path": str(path), "entries": entries, "truncated": len(entries) >= limit}


def search_text(root: Path, query: str, raw_path: str = ".", glob: str = "*", limit: int = 200) -> dict[str, Any]:
    base = resolve_path(root, raw_path)
    results = []
    files = [base] if base.is_file() else base.rglob(glob)
    for file in files:
        if not file.is_file():
            continue
        try:
            for line_number, line in enumerate(file.read_text(encoding="utf-8").splitlines(), 1):
                if query in line:
                    results.append({"path": str(file.relative_to(root.resolve())), "line": line_number, "text": line})
                    if len(results) >= limit:
                        return {"results": results, "truncated": True}
        except (UnicodeDecodeError, OSError):
            continue
    return {"results": results, "truncated": False}


def find_paths(root: Path, pattern: str, raw_path: str = ".", limit: int = 1000) -> dict[str, Any]:
    base = resolve_path(root, raw_path)
    results = []
    for item in base.rglob(pattern):
        results.append({"path": str(item.relative_to(root.resolve())), "is_file": item.is_file(), "is_dir": item.is_dir()})
        if len(results) >= limit:
            return {"results": results, "truncated": True}
    return {"results": results, "truncated": Fals}
