﻿param([switch]$Once)
$ErrorActionPreference='Continue'
$Root='H:\bridge'
$Dir=Join-Path $Root 'recovery_gateway_v1'
$LogDir=Join-Path $Dir 'logs'
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$Log=Join-Path $LogDir 'supervisor.log'
$Python='C:\Users\Azerbaijan\AppData\Local\Programs\Python\Python314\python.exe'
$GatewayPy=Join-Path $Dir 'recovery_gateway.py'
$TokenFile=Join-Path $Dir 'bridge_token.txt'
$GatewayLog=Join-Path $LogDir 'gateway.jsonl'
$PrimaryOut=Join-Path $LogDir 'primary.stdout.log'
$PrimaryErr=Join-Path $LogDir 'primary.stderr.log'
$GatewayOut=Join-Path $LogDir 'gateway.stdout.log'
$GatewayErr=Join-Path $LogDir 'gateway.stderr.log'
$NgrokOut=Join-Path $LogDir 'ngrok.stdout.log'
$NgrokErr=Join-Path $LogDir 'ngrok.stderr.log'
function RotateFile([string]$Path,[int64]$MaxBytes=5242880,[int]$Keep=5){
 if(-not (Test-Path $Path)){return}
 $item=Get-Item $Path -ErrorAction SilentlyContinue
 if(-not $item -or $item.Length -lt $MaxBytes){return}
 for($i=$Keep-1;$i -ge 1;$i--){
  $src="$Path.$i";$dst="$Path."+($i+1)
  if(Test-Path $src){Move-Item $src $dst -Force}
 }
 Move-Item $Path "$Path.1" -Force
}
function MaintainLogs(){
 foreach($p in @($Log,$GatewayLog,$PrimaryOut,$PrimaryErr,$GatewayOut,$GatewayErr,$NgrokOut,$NgrokErr)){
  RotateFile -Path $p -MaxBytes 5242880 -Keep 5
 }
}
function Log([string]$m){MaintainLogs;Add-Content -Path $Log -Encoding UTF8 -Value "$(Get-Date -Format o) $m"}
function PortOwner([int]$Port){@(Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique)}
function ProcMatch([string]$Pattern){@(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {$_.CommandLine -match $Pattern})}
function StopMatching([string]$Pattern){foreach($p in (ProcMatch $Pattern)){try{Stop-Process -Id $p.ProcessId -Force -ErrorAction Stop;Log "STOP pid=$($p.ProcessId) pattern=$Pattern"}catch{Log "STOP_FAIL pid=$($p.ProcessId) err=$($_.Exception.Message)"}}}
function TestHealth([int]$Port){try{$r=Invoke-RestMethod "http://127.0.0.1:$Port/health" -Headers @{'X-Bridge-Token'=(Get-Content $TokenFile -Raw).Trim()} -TimeoutSec 4;return [bool]$r.ok}catch{return $false}}
function StartPrimary(){
 StopMatching 'uvicorn bridge_app\.main:app.*--port 18788'
 Start-Process -FilePath $Python -WorkingDirectory $Root -ArgumentList @('-m','uvicorn','bridge_app.main:app','--host','127.0.0.1','--port','18788') -WindowStyle Hidden -RedirectStandardOutput $PrimaryOut -RedirectStandardError $PrimaryErr | Out-Null
 Log 'PRIMARY_START_REQUESTED port=18788'
}
function StartGateway(){
 foreach($processId in (PortOwner 18787)){try{Stop-Process -Id $processId -Force -ErrorAction Stop;Log "PORT18787_OWNER_STOP pid=$processId"}catch{}}
 StopMatching 'recovery_gateway\.py.*--port 18787'
 Start-Process -FilePath $Python -WorkingDirectory $Dir -ArgumentList @($GatewayPy,'--host','127.0.0.1','--port','18787','--upstream','http://127.0.0.1:18788','--root',$Root,'--allow-root','H:\efab','--token-file',$TokenFile,'--log',$GatewayLog) -WindowStyle Hidden -RedirectStandardOutput $GatewayOut -RedirectStandardError $GatewayErr | Out-Null
 Log 'GATEWAY_START_REQUESTED port=18787 upstream=18788'
}
function StartNgrok(){
 StopMatching 'ngrok\.exe.*127\.0\.0\.1:18787'
 $ngrok=(Get-Command ngrok.exe -ErrorAction SilentlyContinue).Source
 if(-not $ngrok){$ngrok=(Get-ChildItem "$env:LOCALAPPDATA\Microsoft\WinGet\Packages" -Recurse -Filter ngrok.exe -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName)}
 if(-not $ngrok){Log 'NGROK_NOT_FOUND';return}
 $token=(Get-Content $TokenFile -Raw).Trim()
 Start-Process -FilePath $ngrok -ArgumentList @('http','http://127.0.0.1:18787','--log=stdout') -WindowStyle Hidden -RedirectStandardOutput $NgrokOut -RedirectStandardError $NgrokErr | Out-Null
 Log 'NGROK_START_REQUESTED upstream=18787'
}
function EnsureAll(){
 if(-not (TestHealth 18788)){StartPrimary;Start-Sleep 5}
 if(-not (TestHealth 18787)){StartGateway;Start-Sleep 3}
 $ng=@(ProcMatch 'ngrok\.exe.*127\.0\.0\.1:18787')
 if($ng.Count -eq 0){StartNgrok;Start-Sleep 4}
 $p=TestHealth 18788;$g=TestHealth 18787
 Log "STATE primary=$p gateway=$g ngrok=$(@(ProcMatch 'ngrok\.exe.*127\.0\.0\.1:18787').Count)"
 return ($g -and (@(ProcMatch 'ngrok\.exe.*127\.0\.0\.1:18787').Count -ge 1))
}
Log "SUPERVISOR_START pid=$PID identity=$([Security.Principal.WindowsIdentity]::GetCurrent().Name)"
if($Once){if(EnsureAll){exit 0}else{exit 1}}
while($true){[void](EnsureAll);Start-Sleep -Seconds 5}


