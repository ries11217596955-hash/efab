﻿param(
  [int]$Port = 18789,
  [string]$Root = 'H:\bridge'
)

$ErrorActionPreference = 'Stop'
$token = [Environment]::GetEnvironmentVariable('BRIDGE_EMERGENCY_TOKEN','Machine')
if ([string]::IsNullOrWhiteSpace($token)) { throw 'BRIDGE_EMERGENCY_TOKEN is not configured at Machine scope.' }

$mutexName = "Global\EFAB_Emergency_Channel_$Port"
$createdNew = $false
$mutex = [Threading.Mutex]::new($true, $mutexName, [ref]$createdNew)
if (-not $createdNew) {
  $mutex.Dispose()
  throw "Emergency Channel instance already running for port $Port."
}

$listener = $null
$logDir = Join-Path $Root 'emergency_channel_v1\logs'
New-Item -ItemType Directory -Force $logDir | Out-Null
$log = Join-Path $logDir 'emergency_channel.jsonl'

function Write-Json($ctx, [int]$code, $obj) {
  $json = $obj | ConvertTo-Json -Compress -Depth 6
  $b = [Text.Encoding]::UTF8.GetBytes($json)
  $ctx.Response.StatusCode = $code
  $ctx.Response.ContentType = 'application/json'
  $ctx.Response.ContentLength64 = $b.Length
  $ctx.Response.OutputStream.Write($b, 0, $b.Length)
  $ctx.Response.Close()
}

function Authorized($req) {
  $v = $req.Headers['X-Recovery-Token']
  if ([string]::IsNullOrWhiteSpace($v)) { return $false }
  $a = [Text.Encoding]::UTF8.GetBytes($v)
  $b = [Text.Encoding]::UTF8.GetBytes($token)
  if ($a.Length -ne $b.Length) { return $false }
  $diff = 0
  for ($i = 0; $i -lt $a.Length; $i++) { $diff = $diff -bor ($a[$i] -bxor $b[$i]) }
  return ($diff -eq 0)
}

try {
  $listener = [System.Net.HttpListener]::new()
  $listener.Prefixes.Add("http://127.0.0.1:$Port/")
  $listener.Start()

  while ($listener.IsListening) {
    $ctx = $listener.GetContext()
    $req = $ctx.Request
    $path = $req.Url.AbsolutePath.ToLowerInvariant()
    $event = [ordered]@{
      ts = (Get-Date).ToUniversalTime().ToString('o')
      method = $req.HttpMethod
      path = $path
      remote = $req.RemoteEndPoint.Address.ToString()
      status = 'received'
    }

    try {
      if (-not (Authorized $req)) { $event.status='unauthorized'; Write-Json $ctx 401 @{ok=$false;error='UNAUTHORIZED'}; continue }
      if ($req.HttpMethod -eq 'GET' -and $path -eq '/health') { Write-Json $ctx 200 @{ok=$true;channel='emergency';root=$Root;pid=$PID;port=$Port}; $event.status='ok'; continue }
      if ($req.HttpMethod -eq 'GET' -and $path -eq '/status') {
        $ports = @(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object LocalPort -in 18787,18788,18789 | Select-Object LocalPort,OwningProcess)
        $task = Get-ScheduledTaskInfo -TaskName 'EFAB Recovery Gateway SYSTEM' -ErrorAction SilentlyContinue
        Write-Json $ctx 200 @{ok=$true;ports=$ports;recovery_task=if($task){@{last=$task.LastRunTime;result=$task.LastTaskResult;next=$task.NextRunTime}}else{$null}}
        $event.status='ok'
        continue
      }
      if ($req.HttpMethod -eq 'POST' -and $path -eq '/action/recover-bridge') {
        & powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File (Join-Path $Root 'recovery_gateway_v1\recovery_supervisor.ps1') -Once | Out-Null
        Write-Json $ctx 200 @{ok=$true;action='recover-bridge';accepted=$true}
        $event.status='ok'
        continue
      }
      if ($req.HttpMethod -eq 'POST' -and $path -eq '/action/reboot') {
        $reader = [IO.StreamReader]::new($req.InputStream, $req.ContentEncoding)
        $body = $reader.ReadToEnd()
        $reader.Close()
        if ($req.Headers['X-Recovery-Confirm'] -ne 'REBOOT' -or $body.Trim() -ne '{"confirm":"REBOOT"}') {
          Write-Json $ctx 409 @{ok=$false;error='CONFIRMATION_REQUIRED'}
          $event.status='confirmation_required'
          continue
        }
        Write-Json $ctx 202 @{ok=$true;action='reboot';accepted=$true}
        $event.status='accepted'
        Start-Process shutdown.exe -ArgumentList '/r /t 5 /d p:4:1 /c "Emergency Bridge recovery reboot"' -WindowStyle Hidden
        continue
      }
      Write-Json $ctx 404 @{ok=$false;error='NOT_FOUND'}
      $event.status='not_found'
    }
    catch {
      $event.status='error'
      $event.error=$_.Exception.Message
      try { Write-Json $ctx 500 @{ok=$false;error='INTERNAL_ERROR'} } catch {}
    }
    finally {
      ($event | ConvertTo-Json -Compress) | Add-Content -LiteralPath $log -Encoding UTF8
    }
  }
}
finally {
  if ($null -ne $listener) {
    try { if ($listener.IsListening) { $listener.Stop() } } catch {}
    try { $listener.Close() } catch {}
  }
  if ($null -ne $mutex) {
    try { $mutex.ReleaseMutex() } catch {}
    $mutex.Dispose()
  }
}
