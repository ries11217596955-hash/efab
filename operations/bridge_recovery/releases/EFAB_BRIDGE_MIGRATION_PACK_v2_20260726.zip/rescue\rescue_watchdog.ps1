﻿$ErrorActionPreference='SilentlyContinue'
$Root='C:\ProgramData\EFAB-Rescue'
$Task='EFAB Rescue Control SYSTEM'
$TokenPath=Join-Path $Root 'rescue_token.txt'
$Log=Join-Path $Root 'watchdog.log'
function WLog($event,$data){$row=[ordered]@{ts=(Get-Date).ToUniversalTime().ToString('o');event=$event;data=$data};Add-Content -Path $Log -Value ($row|ConvertTo-Json -Compress -Depth 4) -Encoding UTF8}
$healthy=$false
if(Test-Path $TokenPath){$token=(Get-Content $TokenPath -Raw).Trim();try{$r=Invoke-RestMethod -Uri 'http://127.0.0.1:18789/health' -Headers @{'X-Rescue-Token'=$token} -TimeoutSec 5;$healthy=[bool]$r.ok}catch{WLog 'health_failed' @{error=$_.Exception.Message}}}
if(-not $healthy){Stop-ScheduledTask -TaskName $Task -ErrorAction SilentlyContinue;Start-Sleep 1;Start-ScheduledTask -TaskName $Task -ErrorAction SilentlyContinue;Start-Sleep 3;try{$r=Invoke-RestMethod -Uri 'http://127.0.0.1:18789/health' -Headers @{'X-Rescue-Token'=$token} -TimeoutSec 5;WLog 'restart_result' @{ok=[bool]$r.ok}}catch{WLog 'restart_result' @{ok=$false;error=$_.Exception.Message}}}
