﻿$ErrorActionPreference='Stop'
$Root='H:\bridge'
$Dir='H:\bridge\recovery_gateway_v1'
$Python='C:\Users\Azerbaijan\AppData\Local\Programs\Python\Python314\python.exe'
$TokenFile=Join-Path $Dir 'bridge_token.txt'
if(-not (Test-Path $TokenFile)){ throw 'TOKEN_FILE_MISSING' }
$proc=Start-Process -FilePath $Python -ArgumentList @((Join-Path $Dir 'recovery_gateway.py'),'--port','18789','--upstream','http://127.0.0.1:18787','--root',$Root,'--token-file',$TokenFile,'--log',(Join-Path $Dir 'test_gateway.jsonl')) -PassThru -WindowStyle Hidden
try {
 Start-Sleep -Seconds 2
 $token=(Get-Content $TokenFile -Raw).Trim()
 $headers=@{'X-Bridge-Token'=$token}
 $health=Invoke-RestMethod -Uri 'http://127.0.0.1:18789/health' -Headers $headers -TimeoutSec 10
 $ctxBody=@{expected_root=$Root;cwd=$Root}|ConvertTo-Json
 $ctx=Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:18789/context/check' -Headers $headers -ContentType 'application/json' -Body $ctxBody -TimeoutSec 10
 $termBody=@{command='echo GATEWAY_PROXY_OK';expected_root=$Root;cwd=$Root;shell='cmd';wait_timeout_seconds=10;runtime_limit_seconds=10}|ConvertTo-Json
 $term=Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:18789/terminal/run' -Headers $headers -ContentType 'application/json' -Body $termBody -TimeoutSec 20
 [ordered]@{health_status=$health.status;context_status=$ctx.result.context_status;terminal_status=$term.result.status;terminal_exit=$term.result.exit_code;terminal_stdout=$term.result.stdout_tail}|ConvertTo-Json -Depth 6
} finally { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue }
