﻿$ErrorActionPreference='SilentlyContinue'
$Root='H:\bridge'
$Out=Join-Path $Root ('resilience_state\fault_long_network_' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.json')
$start=Get-Date
$beforeState=if(Test-Path (Join-Path $Root 'resilience_state\state_v3.json')){Get-Content (Join-Path $Root 'resilience_state\state_v3.json') -Raw|ConvertFrom-Json}else{$null}
Start-Sleep 5
netsh wlan disconnect | Out-Null
$connected=$false;$local=$false;$public=$false;$ssid=$null
for($i=0;$i -lt 60;$i++){
  Start-Sleep 5
  $w=(netsh wlan show interfaces | Out-String)
  $connected=($w -match 'State\s*:\s*connected')
  if($w -match 'SSID\s*:\s*([^\r\n]+)'){$ssid=$matches[1].Trim()}
  try{$h=Invoke-RestMethod 'http://127.0.0.1:18787/health' -TimeoutSec 3;$local=($h.ok -eq $true)}catch{$local=$false}
  try{$r=Invoke-WebRequest 'https://scabbed-corner-gap.ngrok-free.dev/health' -Headers @{'ngrok-skip-browser-warning'='true'} -UseBasicParsing -TimeoutSec 5;$public=($r.StatusCode -eq 200 -and $r.Content -match '"ok"\s*:\s*true')}catch{$public=$false}
  if($connected -and $local -and $public){break}
}
$afterState=if(Test-Path (Join-Path $Root 'resilience_state\state_v3.json')){Get-Content (Join-Path $Root 'resilience_state\state_v3.json') -Raw|ConvertFrom-Json}else{$null}
[ordered]@{test='long_network_loss_supervisor_reconnect';started=$start.ToString('o');finished=(Get-Date).ToString('o');ssid=$ssid;connected=$connected;local=$local;public=$public;recovered=($connected -and $local -and $public);elapsed_seconds=[math]::Round(((Get-Date)-$start).TotalSeconds,1);bridge_restarts_before=$beforeState.bridge_restarts;bridge_restarts_after=$afterState.bridge_restarts;ngrok_restarts_before=$beforeState.ngrok_restarts;ngrok_restarts_after=$afterState.ngrok_restarts} | ConvertTo-Json -Depth 5 | Set-Content $Out -Encoding UTF8
