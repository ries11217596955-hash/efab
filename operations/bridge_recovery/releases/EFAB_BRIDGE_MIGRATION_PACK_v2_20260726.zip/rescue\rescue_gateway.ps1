param([int]$Port=18789)
$ErrorActionPreference='Stop'
$Root='C:\ProgramData\EFAB-Rescue'
$TokenPath=Join-Path $Root 'rescue_token.txt'
$LogPath=Join-Path $Root 'rescue.log'
$PrimaryTask='EFAB Bridge Boot SYSTEM'
$PrimaryPort=18788
function Log([string]$event,[hashtable]$data=@{}) { $row=[ordered]@{ts=(Get-Date).ToUniversalTime().ToString('o');event=$event;data=$data}; Add-Content -Path $LogPath -Value ($row|ConvertTo-Json -Compress -Depth 5) -Encoding UTF8 }
function Json($ctx,[int]$status,$obj){$json=$obj|ConvertTo-Json -Compress -Depth 8;$bytes=[Text.Encoding]::UTF8.GetBytes($json);$ctx.Response.StatusCode=$status;$ctx.Response.ContentType='application/json';$ctx.Response.ContentEncoding=[Text.Encoding]::UTF8;$ctx.Response.ContentLength64=$bytes.Length;$ctx.Response.OutputStream.Write($bytes,0,$bytes.Length);$ctx.Response.Close()}
function ReadBody($req){$r=New-Object IO.StreamReader($req.InputStream,$req.ContentEncoding);$t=$r.ReadToEnd();$r.Dispose();if([string]::IsNullOrWhiteSpace($t)){return @{}};return ($t|ConvertFrom-Json)}
function SecureEquals([string]$a,[string]$b){if($null -eq $a -or $null -eq $b){return $false};$ab=[Text.Encoding]::UTF8.GetBytes($a);$bb=[Text.Encoding]::UTF8.GetBytes($b);if($ab.Length -ne $bb.Length){return $false};$diff=0;for($i=0;$i -lt $ab.Length;$i++){$diff=$diff -bor ($ab[$i] -bxor $bb[$i])};return $diff -eq 0}
function Authorized($req){
    if(-not (Test-Path $TokenPath)){ return $false }

    $expected = (Get-Content $TokenPath -Raw).Trim()
    $custom = $req.Headers['X-Rescue-Token']
    $authorization = $req.Headers['Authorization']
    $bearer = $null

    if(
        $authorization -and
        $authorization.StartsWith(
            'Bearer ',
            [StringComparison]::OrdinalIgnoreCase
        )
    ){
        $bearer = $authorization.Substring(7).Trim()
    }

    return (SecureEquals $expected $custom) -or
           (SecureEquals $expected $bearer)
}
function PrimaryProcesses(){@(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue|Where-Object{$_.CommandLine -match 'uvicorn bridge_app.main:app' -and $_.CommandLine -match 'H:\\bridge'}|Select-Object ProcessId,ParentProcessId,Name,CommandLine)}
function PrimaryListening(){[bool](Get-NetTCPConnection -State Listen -LocalPort $PrimaryPort -ErrorAction SilentlyContinue)}
function PrimaryState(){ $task=Get-ScheduledTask -TaskName $PrimaryTask -ErrorAction SilentlyContinue; $info=if($task){$task|Get-ScheduledTaskInfo}else{$null}; [ordered]@{listening=(PrimaryListening);processes=(PrimaryProcesses);task_exists=[bool]$task;task_state=if($task){[string]$task.State}else{$null};last_run=if($info){$info.LastRunTime.ToUniversalTime().ToString('o')}else{$null};last_result=if($info){$info.LastTaskResult}else{$null}} }
function StartPrimary(){Start-ScheduledTask -TaskName $PrimaryTask;Start-Sleep -Seconds 3;PrimaryState}
function StopPrimary(){foreach($p in PrimaryProcesses){Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue};Start-Sleep -Seconds 1;PrimaryState}
$listener=[Net.HttpListener]::new();$listener.Prefixes.Add("http://127.0.0.1:$Port/");$listener.Start();Log 'rescue_started' @{port=$Port;pid=$PID}
try{while($listener.IsListening){$ctx=$listener.GetContext();try{$path=$ctx.Request.Url.AbsolutePath.ToLowerInvariant();if(-not(Authorized $ctx.Request)){Log 'unauthorized' @{path=$path;remote=[string]$ctx.Request.RemoteEndPoint};Json $ctx 401 @{ok=$false;error=@{code='UNAUTHORIZED';message='Missing or invalid X-Rescue-Token.'}};continue};switch("$($ctx.Request.HttpMethod) $path"){
'GET /health' {Json $ctx 200 @{ok=$true;result=@{service='efab-rescue';version='1.0.0';pid=$PID;port=$Port;machine=$env:COMPUTERNAME;primary_listening=(PrimaryListening);timestamp=(Get-Date).ToUniversalTime().ToString('o')}}}
'GET /status' {Json $ctx 200 @{ok=$true;result=@{rescue=@{pid=$PID;port=$Port;root=$Root;task='EFAB Rescue Control SYSTEM'};primary=(PrimaryState);tailscale=(Get-Service Tailscale -ErrorAction SilentlyContinue|Select-Object Name,Status,StartType);uptime_seconds=[int]((Get-Date)-(Get-CimInstance Win32_OperatingSystem).LastBootUpTime).TotalSeconds}}}
'POST /primary/start' {$r=StartPrimary;Log 'primary_start' @{};Json $ctx 200 @{ok=$true;result=$r}}
'POST /primary/stop' {$r=StopPrimary;Log 'primary_stop' @{};Json $ctx 200 @{ok=$true;result=$r}}
'POST /primary/restart' {$null=StopPrimary;$r=StartPrimary;Log 'primary_restart' @{};Json $ctx 200 @{ok=$true;result=$r}}
'GET /logs/tail' {$lines=if(Test-Path $LogPath){@(Get-Content $LogPath -Tail 100)}else{@()};Json $ctx 200 @{ok=$true;result=@{lines=$lines}}}
'POST /machine/reboot' {$b=ReadBody $ctx.Request;if($b.confirm -ne 'REBOOT_EFAB_PC'){Json $ctx 409 @{ok=$false;error=@{code='CONFIRMATION_REQUIRED';message='Set confirm to REBOOT_EFAB_PC.'}}}else{Log 'machine_reboot_requested' @{};Json $ctx 202 @{ok=$true;result=@{accepted=$true;action='reboot'}};Start-Process shutdown.exe -ArgumentList '/r','/t','5','/f' -WindowStyle Hidden}}
default {Json $ctx 404 @{ok=$false;error=@{code='NOT_FOUND';message='Unknown rescue route.'}}}
}}catch{Log 'request_error' @{error=$_.Exception.Message};try{Json $ctx 500 @{ok=$false;error=@{code='RESCUE_ERROR';message=$_.Exception.Message}}}catch{}}}}
finally{$listener.Stop();$listener.Close();Log 'rescue_stopped' @{pid=$PID}}
