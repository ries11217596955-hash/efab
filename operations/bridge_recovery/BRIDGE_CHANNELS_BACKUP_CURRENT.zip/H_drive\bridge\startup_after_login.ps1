﻿$ErrorActionPreference = "Continue"
$BridgeRoot = "H:\bridge"
$TargetRepo = "C:\Users\Azerbaijan\Downloads\e-factory-agent-builder"
$CodeCmd = "C:\Users\Azerbaijan\AppData\Local\Programs\Microsoft VS Code\bin\code.cmd"
$CodexAppId = "OpenAI.Codex_2p2nqsd0c76g0!App"
$LogDir = "H:\bridge\startup_logs"
$HealthUrl = "http://127.0.0.1:18787/health"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$Log = Join-Path $LogDir "startup_after_login-$Stamp.log"

function Log([string]$m) {
    $line = "$(Get-Date -Format o) $m"
    Add-Content -Encoding UTF8 -Path $Log -Value $line
}

function BridgeHealthy {
    try {
        $r = Invoke-RestMethod -Uri $HealthUrl -TimeoutSec 5
        return ($r.ok -eq $true -and $r.status -eq "ok")
    } catch {
        Log "HEALTH_CHECK_FAILED=$($_.Exception.Message)"
        return $false
    }
}

Log "STARTUP_BEGIN"
Log "BridgeRoot=$BridgeRoot"
Log "TargetRepo=$TargetRepo"
Log "HealthUrl=$HealthUrl"
try {
    $PublicWatchdog = Join-Path $BridgeRoot "efab_public_route_watchdog.ps1"
    if (Test-Path -LiteralPath $PublicWatchdog) {
        $existing = @(Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match [regex]::Escape($PublicWatchdog) })
        if ($existing.Count -eq 0) {
            Log "START_PUBLIC_ROUTE_WATCHDOG"
            Start-Process -FilePath "powershell.exe" -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-WindowStyle","Minimized","-File",$PublicWatchdog) -WindowStyle Minimized
        } else {
            Log "PUBLIC_ROUTE_WATCHDOG_ALREADY_RUNNING count=$($existing.Count)"
        }
    }
} catch { Log "START_PUBLIC_ROUTE_WATCHDOG_FAILED=$($_.Exception.Message)" }

try {
    $Supervisor = Join-Path $BridgeRoot "efab_bridge_supervisor_v1.ps1"
    if (Test-Path -LiteralPath $Supervisor) {
        Log "START_BRIDGE_SUPERVISOR_V1 reason=LOGIN"
        Start-Process -FilePath "powershell.exe" -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File",$Supervisor,"-Root",$BridgeRoot,"-StartReason","LOGIN","-NetworkWaitSeconds","180","-Once") -WindowStyle Minimized
    } elseif (BridgeHealthy) {
        Log "BRIDGE_ALREADY_HEALTHY_SKIP_START"
    } else {
        Log "START_BRIDGE_FALLBACK_NO_SUPERVISOR"
        Start-Process -FilePath "powershell.exe" -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File", (Join-Path $BridgeRoot "start_gpt_action_bridge_dev.ps1")) -WindowStyle Minimized
    }
} catch { Log "START_BRIDGE_SUPERVISOR_OR_FALLBACK_FAILED=$($_.Exception.Message)" }

Start-Sleep -Seconds 8
try {
    Log "START_VSCODE"
    Start-Process -FilePath $CodeCmd -ArgumentList @($TargetRepo) -WindowStyle Normal
} catch { Log "START_VSCODE_FAILED=$($_.Exception.Message)" }

Start-Sleep -Seconds 8
try {
    Log "START_CODEX"
    Start-Process -FilePath "explorer.exe" -ArgumentList "shell:AppsFolder\$CodexAppId"
} catch { Log "START_CODEX_FAILED=$($_.Exception.Message)" }

Log "STARTUP_END"


