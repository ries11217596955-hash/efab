﻿param([switch]$Install)
$ErrorActionPreference='Stop'
$root='H:\bridge';$script=Join-Path $root 'emergency_channel_v1\emergency_gateway.ps1';$task='EFAB Emergency Channel SYSTEM'
if(-not(Test-Path $script)){throw "Missing $script"}
if(-not $Install){Write-Output 'PREFLIGHT_PASS';Write-Output 'No task or process changed. Re-run with -Install only after Owner approval and token/tunnel readiness.';exit 0}
$token=[Environment]::GetEnvironmentVariable('BRIDGE_EMERGENCY_TOKEN','Machine');if([string]::IsNullOrWhiteSpace($token)){throw 'Machine BRIDGE_EMERGENCY_TOKEN missing'}
$action=New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File `"$script`""
$trigger=New-ScheduledTaskTrigger -AtStartup
$principal=New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$settings=New-ScheduledTaskSettingsSet -RestartCount 99 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew
Register-ScheduledTask -TaskName $task -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
Write-Output 'TASK_INSTALLED_NOT_STARTED'
