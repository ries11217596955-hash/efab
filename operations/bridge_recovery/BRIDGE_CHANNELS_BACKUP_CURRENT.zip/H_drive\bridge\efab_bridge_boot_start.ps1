﻿$ErrorActionPreference = "Continue"
$Bridge = "H:\bridge"
$LogDir = Join-Path $Bridge "boot_task_logs"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$Log = Join-Path $LogDir ("efab_bridge_boot_start_" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".log")
function Log([string]$m) { Add-Content -Encoding UTF8 -Path $Log -Value "$(Get-Date -Format o) $m" }
Log "BOOT_START_BEGIN identity=$([Security.Principal.WindowsIdentity]::GetCurrent().Name)"
try {
  $PublicWatchdog = Join-Path $Bridge "efab_public_route_watchdog.ps1"
  if (Test-Path -LiteralPath $PublicWatchdog) {
    $existing = @(Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match [regex]::Escape($PublicWatchdog) })
    if ($existing.Count -eq 0) {
      Log "START_PUBLIC_ROUTE_WATCHDOG"
      Start-Process -FilePath "powershell.exe" -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-WindowStyle","Minimized","-File",$PublicWatchdog) -WindowStyle Minimized
    } else {
      Log "PUBLIC_ROUTE_WATCHDOG_ALREADY_RUNNING count=$($existing.Count)"
    }
  } else {
    Log "PUBLIC_ROUTE_WATCHDOG_MISSING=$PublicWatchdog"
  }
} catch {
  Log "START_PUBLIC_ROUTE_WATCHDOG_FAILED=$($_.Exception.Message)"
}
Start-Sleep -Seconds 20
try {
  Set-Location $Bridge
  Log "START_BRIDGE_SCRIPT_BEGIN"
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Bridge "start_gpt_action_bridge_dev.ps1") *> (Join-Path $LogDir ("start_gpt_action_bridge_dev_from_boot_" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".log"))
  Log "START_BRIDGE_SCRIPT_EXIT code=$LASTEXITCODE"
} catch {
  Log "START_BRIDGE_SCRIPT_ERROR=$($_.Exception.Message)"
}
try {
  $h = Invoke-RestMethod "http://127.0.0.1:18787/health" -TimeoutSec 10
  Log "HEALTH_AFTER_BOOT ok=$($h.ok) status=$($h.status)"
} catch {
  Log "HEALTH_AFTER_BOOT_FAIL=$($_.Exception.Message)"
}
Log "BOOT_START_END"

