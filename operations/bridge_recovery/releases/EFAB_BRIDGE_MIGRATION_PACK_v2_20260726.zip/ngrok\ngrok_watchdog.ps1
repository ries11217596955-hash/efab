﻿$ErrorActionPreference='SilentlyContinue'
$Root='C:\ProgramData\EFAB-Ngrok'
$Task='EFAB Ngrok Primary SYSTEM'
$Log=Join-Path $Root 'watchdog.log'
function Log($event,$data){$row=[ordered]@{ts=(Get-Date).ToUniversalTime().ToString('o');event=$event;data=$data};Add-Content -Path $Log -Value ($row|ConvertTo-Json -Compress -Depth 5) -Encoding UTF8}
$local=[bool](Get-NetTCPConnection -State Listen -LocalPort 18787 -ErrorAction SilentlyContinue)
$ngrokProc=[bool](Get-Process ngrok -ErrorAction SilentlyContinue)
$api=$false;try{$t=Invoke-RestMethod -Uri 'http://127.0.0.1:4040/api/tunnels' -TimeoutSec 5;$api=[bool]($t.tunnels|Where-Object{$_.public_url -eq 'https://scabbed-corner-gap.ngrok-free.dev'})}catch{}
if(-not($local -and $ngrokProc -and $api)){
  Log 'health_fail' @{local=$local;ngrok_process=$ngrokProc;api=$api}
  if(-not $ngrokProc){Start-ScheduledTask -TaskName $Task -ErrorAction SilentlyContinue;Start-Sleep 8}
}
