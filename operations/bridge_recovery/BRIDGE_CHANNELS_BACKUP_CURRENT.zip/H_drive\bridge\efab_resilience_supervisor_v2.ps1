﻿param(
  [int]$IntervalSeconds = 30,
  [int]$FailureThreshold = 2,
  [int]$NetworkWaitSeconds = 180
)
$ErrorActionPreference='Continue'
$Root='H:\bridge'
$StateDir=Join-Path $Root 'resilience_state'
$LogDir=Join-Path $Root 'resilience_logs'
$LockFile=Join-Path $StateDir 'supervisor.lock'
$StateFile=Join-Path $StateDir 'state.json'
$LogFile=Join-Path $LogDir ('supervisor-' + (Get-Date -Format 'yyyyMMdd') + '.log')
$StartScript=Join-Path $Root 'start_gpt_action_bridge_dev.ps1'
$LocalHealth='http://127.0.0.1:18787/health'
$PublicHealth='https://scabbed-corner-gap.ngrok-free.dev/health'
$NgrokApi='http://127.0.0.1:4040/api/tunnels'
New-Item -ItemType Directory -Force -Path $StateDir,$LogDir | Out-Null
function Log([string]$m){$line="$(Get-Date -Format o) $m";Add-Content -Path $LogFile -Encoding UTF8 -Value $line}
function Save-State($obj){$obj|ConvertTo-Json -Depth 6|Set-Content -Path $StateFile -Encoding UTF8}
function Test-Local{try{$r=Invoke-RestMethod $LocalHealth -TimeoutSec 5;return ($r.ok -eq $true -and $r.status -eq 'ok')}catch{return $false}}
function Test-Ngrok{try{$t=Invoke-RestMethod $NgrokApi -TimeoutSec 5;return (@($t.tunnels|Where-Object {$_.config.addr -match '127.0.0.1:18787'}).Count -gt 0)}catch{return $false}}
function Test-Public{try{$r=Invoke-WebRequest $PublicHealth -Headers @{'ngrok-skip-browser-warning'='true'} -UseBasicParsing -TimeoutSec 10;return ($r.StatusCode -eq 200 -and $r.Content -match '"ok"\s*:\s*true')}catch{return $false}}
function Get-RouteProcs{Get-CimInstance Win32_Process|Where-Object{$_.CommandLine -match 'local_bridge.py|start_gpt_action_bridge_dev.ps1|ngrok.exe'}}
function Start-Route([string]$reason){
  if(-not (Test-Path $StartScript)){Log "START_BLOCKED missing=$StartScript";return}
  $owners=@(Get-CimInstance Win32_Process|Where-Object{$_.CommandLine -match [regex]::Escape($StartScript)})
  if($owners.Count -gt 0){Log "START_SKIPPED already_running=$($owners.Count) reason=$reason";return}
  Log "START_ROUTE reason=$reason"
  Start-Process powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Minimized','-File',$StartScript) -WindowStyle Minimized
}
try{
  if(Test-Path $LockFile){
    $old=Get-Content $LockFile -ErrorAction SilentlyContinue|ConvertFrom-Json -ErrorAction SilentlyContinue
    if($old.pid -and (Get-Process -Id $old.pid -ErrorAction SilentlyContinue)){Log "DUPLICATE_EXIT existing_pid=$($old.pid)";exit 0}
  }
  @{pid=$PID;started=(Get-Date).ToString('o')}|ConvertTo-Json|Set-Content $LockFile -Encoding UTF8
  Log "SUPERVISOR_BEGIN pid=$PID user=$([Security.Principal.WindowsIdentity]::GetCurrent().Name)"
  $deadline=(Get-Date).AddSeconds($NetworkWaitSeconds)
  while((Get-Date)-lt $deadline){if(Test-NetConnection 1.1.1.1 -InformationLevel Quiet -WarningAction SilentlyContinue){break};Start-Sleep 5}
  $fail=0;$restartCount=0
  while($true){
    $local=Test-Local;$ngrok=Test-Ngrok;$public=$false
    if($local -and $ngrok){$public=Test-Public}
    if($local -and $ngrok -and $public){$fail=0;$status='OK'}else{$fail++;$status='DEGRADED'}
    $state=[ordered]@{timestamp=(Get-Date).ToString('o');status=$status;local=$local;ngrok=$ngrok;public=$public;failures=$fail;restart_count=$restartCount;pid=$PID}
    Save-State $state
    if($status -eq 'OK'){Log 'ROUTE_OK'}else{Log "ROUTE_FAIL n=$fail local=$local ngrok=$ngrok public=$public"}
    if($fail -ge $FailureThreshold){Start-Route "threshold local=$local ngrok=$ngrok public=$public";$restartCount++;$fail=0;Start-Sleep 20}
    Start-Sleep $IntervalSeconds
  }
}finally{Remove-Item $LockFile -Force -ErrorAction SilentlyContinue;Log 'SUPERVISOR_END'}
