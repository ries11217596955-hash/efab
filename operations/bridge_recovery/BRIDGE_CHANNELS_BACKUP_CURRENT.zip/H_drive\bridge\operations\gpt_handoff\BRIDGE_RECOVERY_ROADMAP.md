﻿# BRIDGE_RECOVERY_ROADMAP

Status: ACTIVE_ROADMAP
Updated: 2026-07-26
Root: H:\bridge

## Goal

Make ngrok -> Gateway :18787 -> Primary :18788 -> terminal -> reports recoverable and independently provable. Smoke tests do not equal maturity.

## Failure matrix

| Failure | Current recovery | Missing proof/guard | Acceptance proof |
|---|---|---|---|
| Primary exit | periodic health + StartPrimary | duplicate/race guard | one replacement PID + external terminal |
| Primary hang | Gateway timeout/fallback | bounded restart policy | continuity + replacement proof |
| Gateway exit | periodic health + StartGateway | outage bound/single listener | external recovery + one PID |
| ngrok exit | process count + StartNgrok | external tunnel probe | public URL restored + one PID |
| scheduled task failure | Task Scheduler restart/periodic trigger | secondary recovery owner | controlled task failure and repair |
| Windows reboot | boot + periodic tasks intended | untested | reboot proof pack, no manual action |
| token missing | env/file surfaces | bootstrap/diagnostic | safe simulation + rollback |
| token compromise | rotation deferred | atomic cutover absent | Owner-approved dual/atomic cutover |
| reports index corruption | historical manual repair | atomic writer/validator/repair absent | fixture repair preserving records |
| Python dependency loss | historical manual install | dependency preflight absent | isolated loss and deterministic restore |
| wrong port owner | supervisor can stop owner | ownership authority risk | unauthorized owner is not blindly killed |
| duplicate runtime | pattern checks | mutex/identity contract absent | repeated overlap test, one PID per role |
| log/disk growth | partial rotation | retention budget absent | bounded growth proof |

## Recovery layers

L0 observability: process identity, ports, task state, local/external health, report integrity, disk, compact proof JSON.

L1 local services: independent Primary/Gateway restart, mutex/PID identity, duplicate suppression, retry budget/backoff/quarantine.

L2 route: ngrok restart plus real external authenticated probe, not process count only.

L3 dependencies/config: deterministic Python preflight/bootstrap; token presence/permissions without disclosure; config backup restore.

L4 data integrity: atomic reports index writes, parser validation, last-known-good backup, bounded preservation repair.

L5 boot: startup plus periodic watchdog with overlap prevention and reboot acceptance.

## Stages

0. Read-only baseline: full process identity/duplicate audit; task XML and overlap policy; reports index size/hash/parser/count; log map/retention.
1. Safe observability: compact state proof, external probe, PID ownership; no stop logic changes.
2. Local hardening: supervisor mutex, role-specific budgets/backoff, authorized-process validation, rollback validators.
3. Data/dependency hardening: atomic index writer/repair; Python preflight; remove token from command-line/log exposure.
4. Controlled negative tests: one layer at a time; never stop Gateway, Primary and ngrok together.
5. Owner-authorized reboot acceptance: tasks/processes/ports/public health/context/terminal/no duplicates.
6. Owner-authorized token rotation: atomic/dual-token cutover and rollback.

## Acceptance criteria

For each failure mode:
- checkpoint and rollback exist;
- exact fault is reproduced;
- unaffected layers stay alive;
- recovery completes within declared bound;
- exactly one authorized process owns each role;
- local and external authenticated health pass;
- context root is H:\bridge;
- terminal command passes;
- proof JSON/log references exist;
- post-test state matches or improves baseline.

## Negative tests

Primary exit; Primary hang; Gateway exit; ngrok exit; wrong process on 18787/18788; overlapping task invocations; isolated missing typing_extensions; missing env/file token variants; malformed index fixture; unavailable/full log directory; reboot without interactive login.

## Rollback law

Before mutation: timestamped script copy, exported task XML, process/port snapshot, external URL without token, last-known-good proof.

Rollback: restore scripts/task XML; start only one Gateway, Primary and ngrok; verify local ports, public health, context and terminal; never print token.

## Proof set

Timestamp; task XML/hash/results; PID/parent/executable/sanitized command line; listener owners; local Gateway/Primary health; external health/context/terminal; supervisor/Gateway event excerpts; reports index size/hash/parser/count; duplicate count; rollback result.

## Current boundary

Fresh audit proves current operation, periodic SYSTEM checks and one real terminal fallback. It does not prove reboot recovery, all failure modes, race/duplicate absence, data/dependency repair or unattended maturity.
