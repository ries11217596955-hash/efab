﻿$ErrorActionPreference='SilentlyContinue'
Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class NtProc {
  [DllImport("ntdll.dll", SetLastError=true)] public static extern int NtSuspendProcess(IntPtr processHandle);
}
"@
$Root='H:\bridge'
$Out=Join-Path $Root ('resilience_state\fault_bridge_hang_' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.json')
$start=Get-Date
$before=@(Get-NetTCPConnection -LocalPort 18787 -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique)
Start-Sleep 5
foreach($pid0 in $before){$p=Get-Process -Id $pid0 -ErrorAction SilentlyContinue;if($p){[void][NtProc]::NtSuspendProcess($p.Handle)}}
$recovered=$false;$local=$false;$public=$false;$after=@()
for($i=0;$i -lt 60;$i++){
  Start-Sleep 5
  try{$h=Invoke-RestMethod 'http://127.0.0.1:18787/health' -TimeoutSec 3;$local=($h.ok -eq $true)}catch{$local=$false}
  try{$r=Invoke-WebRequest 'https://scabbed-corner-gap.ngrok-free.dev/health' -Headers @{'ngrok-skip-browser-warning'='true'} -UseBasicParsing -TimeoutSec 5;$public=($r.StatusCode -eq 200 -and $r.Content -match '"ok"\s*:\s*true')}catch{$public=$false}
  $after=@(Get-NetTCPConnection -LocalPort 18787 -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique)
  if($local -and $public -and $after.Count -gt 0 -and (@($after|Where-Object{$_ -notin $before}).Count -gt 0)){$recovered=$true;break}
}
[ordered]@{test='suspend_bridge_process';started=$start.ToString('o');finished=(Get-Date).ToString('o');before_pids=$before;after_pids=$after;local=$local;public=$public;recovered=$recovered;elapsed_seconds=[math]::Round(((Get-Date)-$start).TotalSeconds,1)} | ConvertTo-Json -Depth 5 | Set-Content $Out -Encoding UTF8
